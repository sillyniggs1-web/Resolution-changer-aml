script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("0.1")
require "lib.moonloader"
local imgui  = require("mimgui")
local inicfg = require("inicfg")
local DPI    = MONET_DPI_SCALE or 1

-- Everything lives in one table (LuaJIT: 200 locals / 60 upvalues limit).
local S = {
    cfgName = "Hexed Resolution.ini",
    menuOpen = imgui.new.bool(false),
    tab = 1,
    w = imgui.new.int(0), h = imgui.new.int(0),
    lock = imgui.new.bool(true),
    lastW = 0, lastH = 0,
    seq = os.time() * 10,            -- strictly increasing per session
    st = {},                         -- last parsed status.txt
    stOk = false,
    lastHb = nil, lastHbTime = 0,
    nextPoll = 0,
    err = "",
    presets = { 100, 90, 80, 75, 66, 50, 40 },
}

S.cfg = inicfg.load({
    main = {
        -- Must match the plugin's channel dir, printed in logcat as "channel=".
        -- Default is <Android/data/<package>/files>/HexedResolution/
        channelDir = "/sdcard/Android/data/com.nezukosamp.game/files/HexedResolution/",
        lockAspect = true,
    },
}, S.cfgName)
S.lock[0] = S.cfg.main.lockAspect and true or false

local function saveCfg()
    S.cfg.main.lockAspect = S.lock[0]
    inicfg.save(S.cfg, S.cfgName)
end

local function even(v) return math.floor(v / 2 + 0.5) * 2 end

-- ---------------------------------------------------------------- channel --
local function chanDir()
    local d = S.cfg.main.channelDir
    if d:sub(-1) ~= "/" then d = d .. "/" end
    return d
end

local function sendCmd(cmd, w, h)
    S.seq = S.seq + 1
    local line = tostring(S.seq) .. " " .. cmd
    if w and h then line = line .. " " .. tostring(w) .. " " .. tostring(h) end
    local f = io.open(chanDir() .. "request.txt", "w")
    if not f then
        S.err = "Cannot write " .. chanDir() .. " (check channelDir in " .. S.cfgName .. ")"
        return false
    end
    f:write(line .. "\n")
    f:close()
    S.err = ""
    return true
end

local function pollStatus()
    local f = io.open(chanDir() .. "status.txt", "r")
    if not f then S.stOk = false; return end
    local txt = f:read("*a") or ""
    f:close()
    if not txt:find("\nend=1", 1, true) then return end     -- half-written, try later
    local t = {}
    for k, v in txt:gmatch("([%w_]+)=([^\n]*)") do t[k] = v end
    S.st = t
    S.stOk = true
    if t.hb ~= S.lastHb then S.lastHb = t.hb; S.lastHbTime = os.clock() end
end

local function pluginAlive()
    return S.stOk and (os.clock() - S.lastHbTime) < 4
end

local function num(k) return tonumber(S.st[k] or "") or 0 end

-- ------------------------------------------------------------------ style --
imgui.OnInitialize(function()
    imgui.GetIO().IniFilename = nil
    local st = imgui.GetStyle()
    local c = st.Colors
    st.WindowRounding = 10 * DPI
    st.FrameRounding = 6 * DPI
    st.WindowBorderSize = 1
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.97)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.06, 0.09, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.20, 0.50, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.10, 0.30, 0.75, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.CheckMark]     = imgui.ImVec4(0.30, 0.60, 1.00, 1.00)
end)

local STATE_COL = {
    idle = {0.70, 0.80, 1.00}, applied = {0.30, 0.90, 0.50}, pending = {1.00, 0.85, 0.30},
    failed = {1.00, 0.35, 0.35}, reverted = {1.00, 0.60, 0.30}, unsupported = {1.00, 0.35, 0.35},
}

local function centered(text)
    imgui.SetCursorPosX((imgui.GetWindowWidth() - imgui.CalcTextSize(text).x) / 2)
    imgui.Text(text)
end

local function tabButton(label, idx)
    if S.tab == idx then imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.10, 0.35, 0.85, 1.0)) end
    if imgui.Button(label, imgui.ImVec2(130 * DPI, 35 * DPI)) then S.tab = idx end
    if S.tab == idx then imgui.PopStyleColor() end
end

local function sizeFromCustom()
    return S.w[0], S.h[0]
end

local function drawResolutionTab()
    local nw, nh = num("nw"), num("nh")
    local state = S.st.state or "?"
    local col = STATE_COL[state] or {1, 1, 1}

    imgui.TextColored(imgui.ImVec4(col[1], col[2], col[3], 1), "State: " .. state)
    imgui.TextWrapped(S.st.msg or "")
    if S.err ~= "" then imgui.TextColored(imgui.ImVec4(1, 0.4, 0.4, 1), S.err) end
    imgui.Separator()

    if not pluginAlive() then
        imgui.TextColored(imgui.ImVec4(1, 0.4, 0.4, 1), "Plugin not responding.")
        imgui.TextWrapped("Check that libHexedResolution.so is in the AML mods folder and that channelDir in "
            .. S.cfgName .. " matches the 'channel=' line in logcat.")
        return
    end
    if nw <= 0 then imgui.Text("Waiting for the game surface ...") return end

    imgui.Text(string.format("Native: %dx%d    Current: %dx%d", nw, nh, num("cw"), num("ch")))
    if (S.st.saved or "0x0") ~= "0x0" then
        imgui.Text("Saved: " .. S.st.saved .. (S.st.confirmed == "1" and " (confirmed)" or ""))
    end

    imgui.Spacing()
    imgui.Text("Presets (percent of native)")
    for i, p in ipairs(S.presets) do
        if i > 1 then imgui.SameLine() end
        if imgui.Button(tostring(p) .. "%##p" .. i, imgui.ImVec2(70 * DPI, 32 * DPI)) then
            S.w[0] = even(nw * p / 100)
            S.h[0] = even(nh * p / 100)
        end
    end

    imgui.Spacing()
    imgui.Text("Custom size")
    if S.w[0] == 0 then S.w[0] = nw; S.h[0] = nh; S.lastW = nw; S.lastH = nh end
    imgui.PushItemWidth(200 * DPI)
    imgui.SliderInt("##wsl", S.w, 320, nw);  imgui.SameLine(); imgui.Text("Width")
    imgui.SliderInt("##hsl", S.h, 180, nh);  imgui.SameLine(); imgui.Text("Height")
    imgui.InputInt("##win", S.w);            imgui.SameLine(); imgui.Text("Width (type)")
    imgui.InputInt("##hin", S.h);            imgui.SameLine(); imgui.Text("Height (type)")
    imgui.PopItemWidth()
    if imgui.Checkbox("Lock aspect ratio", S.lock) then saveCfg() end

    if S.lock[0] then
        if S.w[0] ~= S.lastW then S.h[0] = even(S.w[0] * nh / nw)
        elseif S.h[0] ~= S.lastH then S.w[0] = even(S.h[0] * nw / nh) end
    end
    S.lastW, S.lastH = S.w[0], S.h[0]

    imgui.Spacing()
    local busy = (state == "pending")
    if busy then imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.2, 0.2, 0.25, 1)) end
    if imgui.Button("Apply", imgui.ImVec2(120 * DPI, 38 * DPI)) and not busy then
        local w, h = sizeFromCustom()
        sendCmd("apply", w, h)
    end
    imgui.SameLine()
    if imgui.Button("Reset", imgui.ImVec2(120 * DPI, 38 * DPI)) and not busy then sendCmd("reset") end
    if busy then imgui.PopStyleColor() end

    local keep = num("keep")
    if state == "applied" and keep > 0 then
        imgui.SameLine()
        if imgui.Button("Keep (" .. keep .. "s)", imgui.ImVec2(150 * DPI, 38 * DPI)) then sendCmd("keep") end
        imgui.TextColored(imgui.ImVec4(1, 0.85, 0.3, 1), "Reverts automatically if you do not press Keep.")
    end
end

local function drawStatusTab()
    imgui.Text("Plugin: " .. (pluginAlive() and "running" or "not responding"))
    imgui.Text("Channel: " .. chanDir())
    imgui.Text(string.format("SurfaceViews found: %d", num("sv")))
    imgui.Text(string.format("Surface frame: %dx%d   View: %dx%d", num("cw"), num("ch"), num("vw"), num("vh")))
    if imgui.Button("Re-probe", imgui.ImVec2(120 * DPI, 34 * DPI)) then sendCmd("probe") end
    imgui.Spacing()
    imgui.TextWrapped("Only the game's render surface changes. Android system resolution and DPI are never modified.")
end

imgui.OnFrame(function() return S.menuOpen[0] end, function()
    local io = imgui.GetIO()
    imgui.SetNextWindowSize(imgui.ImVec2(640 * DPI, 420 * DPI), imgui.Cond.FirstUseEver)
    imgui.SetNextWindowPos(imgui.ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.Begin("##hexres", S.menuOpen, imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoCollapse)
    centered("HEXED RESOLUTION")
    imgui.Separator()

    imgui.BeginChild("##tabs", imgui.ImVec2(140 * DPI, 0), false)
    tabButton("Resolution", 1)
    tabButton("Status", 2)
    imgui.Spacing()
    if imgui.Button("Close", imgui.ImVec2(130 * DPI, 35 * DPI)) then S.menuOpen[0] = false end
    imgui.EndChild()
    imgui.SameLine()
    imgui.BeginChild("##body", imgui.ImVec2(0, 0), false)
    if S.tab == 1 then drawResolutionTab() else drawStatusTab() end
    imgui.EndChild()
    imgui.End()
end)

function main()
    while not isSampLoaded() do wait(100) end
    sampRegisterChatCommand("hexres", function() S.menuOpen[0] = not S.menuOpen[0] end)
    while true do
        wait(0)
        imgui.Process = true
        local now = os.clock()
        if now >= S.nextPoll then
            S.nextPoll = now + (S.menuOpen[0] and 0.4 or 2.0)
            pollStatus()
        end
    end
end

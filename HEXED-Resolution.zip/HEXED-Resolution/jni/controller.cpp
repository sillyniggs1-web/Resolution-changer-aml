// Controller: owns all state, talks to the Lua menu over a small file channel,
// and drives the backend. Everything here runs on ONE background thread, so the
// state needs no locking. Only the backend call hops to the Java UI thread.
//
// Channel directory:  <aml->GetAndroidDataPath()>/HexedResolution/
//   request.txt  (Lua -> plugin)  "<seq> <cmd> [w h]"   cmd = apply|reset|keep|probe
//   status.txt   (plugin -> Lua)  key=value lines, terminated by "end=1"
#include "res.h"

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <thread>
#include <unistd.h>

namespace hres {
namespace {

constexpr const char* kSection = "Resolution";
constexpr int kMinW = 320, kMinH = 180;

int64_t NowMs()
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

const char* StateName(State s)
{
    switch(s)
    {
        case State::Unsupported: return "unsupported";
        case State::Idle:        return "idle";
        case State::Pending:     return "pending";
        case State::Applied:     return "applied";
        case State::Failed:      return "failed";
        case State::Reverted:    return "reverted";
    }
    return "unknown";
}

struct Ctx
{
    State st = State::Unsupported;
    char  msg[160] = "Waiting for the game surface";
    int   nw = 0, nh = 0;          // native (original) surface frame
    int   cw = 0, ch = 0;          // current surface frame
    int   vw = 0, vh = 0;          // SurfaceView layout size
    int   svCount = 0;
    uint32_t seq = 0;              // last processed request id
    bool  surfaceSeen = false;
    bool  dirty = true;
    int64_t lastWrite = 0;
    int64_t nextProbe = 0;
    int64_t probeFirst = 0;

    // pending operations
    int64_t verifyAt = 0;  int verifyTries = 0;
    int tw = 0, th = 0;            // verification target
    bool verifyIsReset = false;
    bool verifyBoot = false;
    int64_t keepAt = 0;            // manual apply: auto-revert deadline
    int64_t stableAt = 0;          // boot apply: clear BootPending deadline
    int64_t bootAt = 0;
    bool bootDone = false;

    std::string dir;
} C;

std::atomic<bool> g_run{false};

void SetMsg(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(C.msg, sizeof(C.msg), fmt, ap);
    va_end(ap);
    for(char* p = C.msg; *p; ++p) if(*p == '\n' || *p == '\r') *p = ' ';
    C.dirty = true;
}

void Log(const char* tag, const char* msg) { logger->Info("[%s] %s", tag, msg); }

// ---- config (controller thread only) -------------------------------------
int  CfgInt(const char* k, int d)   { return cfg->GetInt(k, d, kSection); }
bool CfgBool(const char* k, bool d) { return cfg->GetBool(k, d, kSection); }
void CfgSetInt(const char* k, int v)   { ConfigEntry* e = cfg->Bind(k, 0, kSection);     e->SetInt(v);  delete e; }
void CfgSetBool(const char* k, bool v) { ConfigEntry* e = cfg->Bind(k, false, kSection); e->SetBool(v); delete e; }

// ---- status file ---------------------------------------------------------
void WriteStatus(int64_t now)
{
    int keepLeft = 0;
    if(C.st == State::Applied && C.keepAt > now) keepLeft = (int)((C.keepAt - now + 999) / 1000);

    char buf[768];
    int n = snprintf(buf, sizeof(buf),
        "v=1\nhb=%lld\nseq=%u\nstate=%s\nmsg=%s\n"
        "nw=%d\nnh=%d\ncw=%d\nch=%d\nvw=%d\nvh=%d\nsv=%d\nkeep=%d\n"
        "saved=%dx%d\nconfirmed=%d\nend=1\n",
        (long long)now, C.seq, StateName(C.st), C.msg,
        C.nw, C.nh, C.cw, C.ch, C.vw, C.vh, C.svCount, keepLeft,
        CfgInt("SavedWidth", 0), CfgInt("SavedHeight", 0), CfgBool("Confirmed", false) ? 1 : 0);
    if(n <= 0) return;

    std::string tmp = C.dir + "status.tmp", fin = C.dir + "status.txt";
    FILE* f = fopen(tmp.c_str(), "wb");
    if(!f) return;
    fwrite(buf, 1, (size_t)n, f);
    fclose(f);
    rename(tmp.c_str(), fin.c_str());
    C.dirty = false;
    C.lastWrite = now;
}

// ---- helpers -------------------------------------------------------------
void TakeInfo(const SurfaceInfo& si)
{
    C.cw = si.frameW; C.ch = si.frameH;
    C.vw = si.viewW;  C.vh = si.viewH;
    C.svCount = si.surfaceViews;
    C.dirty = true;
}

bool Validate(int& w, int& h, char* why, size_t n)
{
    if(C.nw <= 0 || C.nh <= 0) { snprintf(why, n, "Game surface not detected yet"); return false; }
    w &= ~1; h &= ~1;
    if(w < kMinW || h < kMinH) { snprintf(why, n, "Minimum is %dx%d", kMinW, kMinH); return false; }
    if(w > C.nw || h > C.nh)   { snprintf(why, n, "Above native %dx%d is not supported in this beta", C.nw, C.nh); return false; }
    if(!CfgBool("AllowStretch", false))
    {
        double a = (double)w / h, b = (double)C.nw / C.nh;
        if(std::fabs(a - b) / b > 0.02)
        {
            snprintf(why, n, "Aspect %.3f differs from native %.3f (set AllowStretch=1 to override)", a, b);
            return false;
        }
    }
    return true;
}

void Fail(const char* reason)
{
    C.st = State::Failed;
    SetMsg("%s", reason);
    logger->Error("[HexedResolution] %s", reason);
}

void StartApply(int w, int h, bool boot)
{
    char why[160];
    if(!C.surfaceSeen) { C.st = State::Unsupported; SetMsg("Unsupported: %s", C.msg); return; }
    if(!Validate(w, h, why, sizeof(why))) { Fail(why); return; }

    SurfaceInfo si;
    if(!RunBackend(Op::SetFixed, w, h, &si)) { Fail("UI thread did not respond"); return; }
    if(!si.ok) { C.st = State::Unsupported; SetMsg("Unsupported: %s", si.err); return; }

    C.st = State::Pending;
    C.tw = w; C.th = h;
    C.verifyAt = NowMs() + 800; C.verifyTries = 0;
    C.verifyIsReset = false; C.verifyBoot = boot;
    C.keepAt = 0;
    SetMsg("Applying %dx%d ...", w, h);
    logger->Info("[HexedResolution] SetFixed %dx%d requested (boot=%d)", w, h, boot ? 1 : 0);

    if(!boot)
    {   // The user is in control now; a different saved size must be re-confirmed.
        C.stableAt = 0;
        CfgSetBool("BootPending", false);
        CfgSetBool("Confirmed", false);
        cfg->Save();
    }
}

void StartReset(const char* why)
{
    SurfaceInfo si;
    if(!RunBackend(Op::SetFromLayout, 0, 0, &si)) { Fail("UI thread did not respond"); return; }
    if(!si.ok) { C.st = State::Unsupported; SetMsg("Unsupported: %s", si.err); return; }
    C.st = State::Pending;
    C.tw = C.nw; C.th = C.nh;
    C.verifyAt = NowMs() + 800; C.verifyTries = 0;
    C.verifyIsReset = true; C.verifyBoot = false;
    C.keepAt = 0; C.stableAt = 0;
    C.dirty = true;
    SetMsg("%s", why);
}

State g_afterReset = State::Idle;
char  g_afterResetMsg[160] = "Original resolution restored";

void VerifyStep(int64_t now)
{
    SurfaceInfo si;
    if(!RunBackend(Op::Query, 0, 0, &si) || !si.ok)
    {
        C.verifyAt = 0;
        Fail(si.err[0] ? si.err : "verify failed (UI thread)");
        return;
    }
    TakeInfo(si);
    bool match = (si.frameW == C.tw && si.frameH == C.th);

    if(C.verifyIsReset)
    {
        if(!match && ++C.verifyTries < 3) { C.verifyAt = now + 700; return; }
        C.verifyAt = 0;
        C.st = g_afterReset;
        if(match) SetMsg("%s", g_afterResetMsg);
        else      SetMsg("%s (surface is %dx%d, recorded original %dx%d)", g_afterResetMsg, si.frameW, si.frameH, C.nw, C.nh);
        return;
    }

    if(!match)
    {
        if(++C.verifyTries < 3) { C.verifyAt = now + 700; return; }
        C.verifyAt = 0;
        char why[160];
        snprintf(why, sizeof(why), "Surface stayed %dx%d, wanted %dx%d. Reverting.", si.frameW, si.frameH, C.tw, C.th);
        strcpy(g_afterResetMsg, "Reverted after a failed apply");
        g_afterReset = State::Failed;
        if(C.verifyBoot) { CfgSetBool("BootPending", false); CfgSetBool("Confirmed", false); cfg->Save(); }
        StartReset(why);
        return;
    }

    C.verifyAt = 0;
    C.st = State::Applied;
    if(C.verifyBoot)
    {
        C.stableAt = now + 30000;
        SetMsg("Applied saved %dx%d at startup", C.tw, C.th);
    }
    else
    {
        int keep = CfgInt("KeepSeconds", 15);
        if(keep < 5) keep = 5;
        C.keepAt = now + keep * 1000LL;
        SetMsg("Surface is now %dx%d. Press Keep if the picture and touch look right, or it reverts.", C.tw, C.th);
    }
    logger->Info("[HexedResolution] surface verified at %dx%d", si.frameW, si.frameH);
}

void DoKeep()
{
    if(C.st != State::Applied) { SetMsg("Nothing to keep"); return; }
    CfgSetInt("SavedWidth", C.cw); CfgSetInt("SavedHeight", C.ch);
    CfgSetBool("Confirmed", true); CfgSetBool("BootPending", false);
    cfg->Save();
    C.keepAt = 0; C.stableAt = 0;
    SetMsg("Kept %dx%d and saved", C.cw, C.ch);
}

void DoReset()
{
    strcpy(g_afterResetMsg, "Original resolution restored");
    g_afterReset = State::Idle;
    CfgSetInt("SavedWidth", 0); CfgSetInt("SavedHeight", 0);
    CfgSetBool("Confirmed", false); CfgSetBool("BootPending", false);
    cfg->Save();
    StartReset("Restoring original resolution ...");
}

void BootDecision()
{
    if(CfgBool("BootPending", false))
    {
        CfgSetBool("BootPending", false); CfgSetBool("Confirmed", false); cfg->Save();
        SetMsg("Last auto-apply did not stay stable; saved size disabled");
        Log("HexedResolution", "BootPending was set: previous startup did not finish stable, skipping auto-apply");
        return;
    }
    int sw = CfgInt("SavedWidth", 0), sh = CfgInt("SavedHeight", 0);
    if(CfgBool("AutoApply", false) && CfgBool("Confirmed", false) && sw > 0 && sh > 0)
    {
        CfgSetBool("BootPending", true); cfg->Save();
        StartApply(sw, sh, true);
        if(C.st == State::Failed || C.st == State::Unsupported)
        { CfgSetBool("BootPending", false); CfgSetBool("Confirmed", false); cfg->Save(); }
    }
}

// ---- request channel -----------------------------------------------------
void PollRequest()
{
    std::string path = C.dir + "request.txt";
    FILE* f = fopen(path.c_str(), "rb");
    if(!f) return;
    char buf[128] = {0};
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    if(n == 0) return;

    unsigned seq = 0; char cmd[16] = {0}; int w = 0, h = 0;
    int got = sscanf(buf, "%u %15s %d %d", &seq, cmd, &w, &h);
    if(got < 2 || seq == C.seq) return;
    C.seq = seq;

    if(!strcmp(cmd, "apply") && got == 4)
    {
        if(C.st == State::Pending) SetMsg("Busy, wait for the current operation");
        else StartApply(w, h, false);
    }
    else if(!strcmp(cmd, "reset"))
    {
        if(C.st == State::Pending) SetMsg("Busy, wait for the current operation");
        else DoReset();
    }
    else if(!strcmp(cmd, "keep")) DoKeep();
    else if(!strcmp(cmd, "probe"))
    {
        SurfaceInfo si;
        if(RunBackend(Op::Query, 0, 0, &si) && si.ok) { TakeInfo(si); SetMsg("Probe OK: surface %dx%d, %d SurfaceView(s)", si.frameW, si.frameH, si.surfaceViews); }
        else SetMsg("Probe failed: %s", si.err[0] ? si.err : "UI thread did not respond");
    }
    else SetMsg("Unknown command '%s'", cmd);
    C.dirty = true;
}

void ProbeStep(int64_t now)
{
    if(now < C.nextProbe) return;
    if(!C.probeFirst) C.probeFirst = now;
    C.nextProbe = now + ((now - C.probeFirst) < 60000 ? 1000 : 10000);

    SurfaceInfo si;
    bool posted = RunBackend(Op::Query, 0, 0, &si);
    if(posted && si.ok && si.frameW > 0 && si.frameH > 0)
    {
        TakeInfo(si);
        C.nw = si.frameW; C.nh = si.frameH;
        C.surfaceSeen = true;
        C.st = State::Idle;
        C.bootAt = now + CfgInt("BootDelaySeconds", 20) * 1000LL;
        SetMsg("Ready. Native surface %dx%d", C.nw, C.nh);
        int dw = 0, dh = 0; aml->GetDisplaySize(&dw, &dh);
        logger->Info("[HexedResolution] surface %dx%d view %dx%d svViews=%d display=%dx%d",
                     si.frameW, si.frameH, si.viewW, si.viewH, si.surfaceViews, dw, dh);
        return;
    }
    C.st = State::Unsupported;
    SetMsg("%s", posted ? (si.err[0] ? si.err : "surface not ready") : "UI thread did not respond");
}

void Timers(int64_t now)
{
    if(C.verifyAt && now >= C.verifyAt) VerifyStep(now);

    if(C.st == State::Applied && C.keepAt && now >= C.keepAt)
    {
        strcpy(g_afterResetMsg, "Not confirmed in time, original restored");
        g_afterReset = State::Reverted;
        StartReset("Not confirmed in time, reverting ...");
    }
    if(C.stableAt && now >= C.stableAt)
    {
        C.stableAt = 0;
        if(C.st == State::Applied) { CfgSetBool("BootPending", false); cfg->Save(); Log("HexedResolution", "startup apply stable, BootPending cleared"); }
    }
    if(!C.bootDone && C.surfaceSeen && now >= C.bootAt) { C.bootDone = true; BootDecision(); }
}

void Loop()
{
    const char* base = aml->GetAndroidDataPath();
    C.dir = base ? base : "";
    if(!C.dir.empty() && C.dir.back() != '/') C.dir += '/';
    C.dir += "HexedResolution/";
    aml->CreateDirRecursive(C.dir.c_str());
    remove((C.dir + "request.txt").c_str());   // never act on a stale request

    logger->Info("[HexedResolution] channel=%s game=%s ver=%s code=%lld",
                 C.dir.c_str(), aml->GetCurrentGame(), aml->GetAppVersionName(), (long long)aml->GetAppVersionCode());

    int pollMs = CfgInt("PollMs", 250);
    if(pollMs < 100) pollMs = 100;

    while(g_run)
    {
        int64_t now = NowMs();
        if(!C.surfaceSeen) ProbeStep(now);
        PollRequest();
        if(C.surfaceSeen) Timers(now);
        if(C.dirty || now - C.lastWrite >= 1000) WriteStatus(now);
        usleep((useconds_t)pollMs * 1000);
    }
}

} // namespace

void ControllerStart()
{
    if(g_run.exchange(true)) return;
    std::thread(Loop).detach();   // detached: AML does not guarantee OnModUnload
}

void ControllerStop() { g_run = false; }

} // namespace hres

LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_CPP_EXTENSION := .cpp .cc
LOCAL_MODULE        := HexedResolution
LOCAL_SRC_FILES     := main.cpp controller.cpp backend_surface.cpp \
                       mod/logger.cpp mod/config.cpp
LOCAL_CFLAGS        += -O2 -mfloat-abi=softfp -DNDEBUG -std=c++17
LOCAL_C_INCLUDES    += $(LOCAL_PATH)
LOCAL_LDLIBS        += -llog
include $(BUILD_SHARED_LIBRARY)

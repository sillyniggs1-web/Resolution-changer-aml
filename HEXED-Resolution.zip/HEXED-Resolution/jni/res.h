// HEXED Resolution - shared declarations.
// Only documented AML 1.4.x APIs are used (see README, "API inventory").
#pragma once
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include <cstdint>

extern Config* cfg;   // defined by MYMODCFG in main.cpp

namespace hres {

enum class State { Unsupported, Idle, Pending, Applied, Failed, Reverted };

// Result of one backend call. Filled on the Android UI thread.
struct SurfaceInfo {
    bool ok = false;               // SurfaceView found and frame read
    int  frameW = 0, frameH = 0;   // SurfaceHolder.getSurfaceFrame()
    int  viewW  = 0, viewH  = 0;   // View.getWidth()/getHeight()
    int  surfaceViews = 0;         // SurfaceView instances found in the view tree
    char err[96] = {0};
};

enum class Op { Query, SetFixed, SetFromLayout };

// Runs one backend operation on the Java UI thread (aml->PushToJavaUIThread)
// and waits for it. Returns false if it could not be posted or timed out.
bool RunBackend(Op op, int w, int h, SurfaceInfo* out, int timeoutMs = 3000);

namespace backend {            // UI thread only
SurfaceInfo Run(Op op, int w, int h);
}

void ControllerStart();
void ControllerStop();

} // namespace hres

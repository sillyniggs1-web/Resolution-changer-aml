#include "res.h"

// NEEDGAME is intentionally not used: if the package name were wrong the mod
// would silently never load. The controller logs the real package instead.
MYMODCFG(com.hexedstudio.hexedresolution, HEXED Resolution, 0.1, HEXED Studio)

// Uses AML 1.4.0 APIs (PushToJavaUIThread, GetCurrentActivity, GetDisplaySize).
// If the client ships an older AML, AML refuses to load this mod.
BEGIN_DEPLIST()
    ADD_DEPENDENCY_VER(net.rusjj.aml, 1.4.0)
END_DEPLIST()

ON_MOD_PRELOAD()
{
    logger->SetTag("HexedResolution");
}

ON_MOD_LOAD()
{
    // Create every key once so the ini is self-documenting.
    //   Enabled          0 = plugin does nothing (emergency off switch)
    //   AutoApply        1 = re-apply the kept size at startup
    //   SavedWidth/Height, Confirmed, BootPending = managed by the plugin
    //   AllowStretch     1 = allow aspect ratios that differ from native
    //   KeepSeconds      seconds to press "Keep" before auto-revert
    //   BootDelaySeconds wait after the surface appears before auto-apply
    //   PollMs           channel poll interval (>= 100)
    const char* S = "Resolution";
    delete cfg->Bind("Enabled", true, S);
    delete cfg->Bind("AutoApply", false, S);
    delete cfg->Bind("SavedWidth", 0, S);
    delete cfg->Bind("SavedHeight", 0, S);
    delete cfg->Bind("Confirmed", false, S);
    delete cfg->Bind("BootPending", false, S);
    delete cfg->Bind("AllowStretch", false, S);
    delete cfg->Bind("KeepSeconds", 15, S);
    delete cfg->Bind("BootDelaySeconds", 20, S);
    delete cfg->Bind("PollMs", 250, S);
    cfg->Save();

    if(!cfg->GetBool("Enabled", true, S))
    {
        logger->Info("Enabled=0 in the ini: HEXED Resolution stays idle");
        return;
    }
    logger->Info("HEXED Resolution 0.1 loaded (SurfaceView backend)");
    hres::ControllerStart();
}

ON_MOD_UNLOAD()
{
    hres::ControllerStop();   // not guaranteed to run; safety does not depend on it
}

# Nezuko SA-MP 1.0.3 TESTING ships 32-bit armeabi-v7a libraries only.
APP_ABI      := armeabi-v7a
APP_PLATFORM := android-21
APP_STL      := c++_static
APP_OPTIM    := release

// Backend "SurfaceView fixed size".
//
// What it does: finds the SurfaceView inside the current Activity and calls the
// public Android API SurfaceHolder.setFixedSize(w, h). The GPU then renders into
// a w x h buffer and Android scales it to the view. Android's system resolution
// and DPI are never touched, and no game memory offsets are used.
//
// What it cannot know: whether the Nezuko client keeps working correctly after
// the surface size changes (viewport, HUD scale, touch mapping). That must be
// verified on a device (README, "Beta test procedure").
//
// Every function here must run on the Java UI thread (see RunBackend).
#include "res.h"

#include <condition_variable>
#include <cstdio>
#include <memory>
#include <mutex>
#include <chrono>

namespace hres {
namespace backend {
namespace {

struct Jni {
    JNIEnv*   env;
    jmethodID getChildCount;
    jmethodID getChildAt;
    jclass    surfaceViewCls;
    jclass    viewGroupCls;
    jobject   firstSv;   // local ref
    int       count;
};

bool Fail(SurfaceInfo& r, const char* msg)
{
    snprintf(r.err, sizeof(r.err), "%s", msg);
    r.ok = false;
    return false;
}

bool Pending(JNIEnv* env)
{
    if(env->ExceptionCheck())
    {
        env->ExceptionClear();
        return true;
    }
    return false;
}

void Walk(Jni& j, jobject view, int depth)
{
    if(!view || depth > 24) return;
    JNIEnv* env = j.env;

    if(env->IsInstanceOf(view, j.surfaceViewCls))
    {
        ++j.count;
        if(!j.firstSv) j.firstSv = env->NewLocalRef(view);
    }
    if(env->IsInstanceOf(view, j.viewGroupCls))
    {
        jint n = env->CallIntMethod(view, j.getChildCount);
        if(Pending(env)) return;
        for(jint i = 0; i < n; ++i)
        {
            jobject child = env->CallObjectMethod(view, j.getChildAt, i);
            if(Pending(env)) return;
            Walk(j, child, depth + 1);
            if(child) env->DeleteLocalRef(child);
        }
    }
}

} // namespace

SurfaceInfo Run(Op op, int w, int h)
{
    SurfaceInfo r;

    JavaVM* vm = aml->GetJavaVM();
    JNIEnv* env = nullptr;
    if(!vm || vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK || !env)
    {
        Fail(r, "no JNIEnv on the UI thread");
        return r;
    }

    jobject activity = aml->GetCurrentActivity();
    if(!activity) { Fail(r, "no current Activity yet"); return r; }

    jclass activityCls = env->GetObjectClass(activity);
    jmethodID getWindow = env->GetMethodID(activityCls, "getWindow", "()Landroid/view/Window;");
    jclass windowCls = env->FindClass("android/view/Window");
    jmethodID getDecor = windowCls ? env->GetMethodID(windowCls, "getDecorView", "()Landroid/view/View;") : nullptr;
    if(Pending(env) || !getWindow || !getDecor) { Fail(r, "Activity/Window lookup failed"); return r; }

    jobject window = env->CallObjectMethod(activity, getWindow);
    if(Pending(env) || !window) { Fail(r, "getWindow() failed"); return r; }
    jobject decor = env->CallObjectMethod(window, getDecor);
    if(Pending(env) || !decor) { Fail(r, "getDecorView() failed"); return r; }

    Jni j{};
    j.env = env;
    j.surfaceViewCls = env->FindClass("android/view/SurfaceView");
    j.viewGroupCls   = env->FindClass("android/view/ViewGroup");
    if(Pending(env) || !j.surfaceViewCls || !j.viewGroupCls) { Fail(r, "view classes not found"); return r; }
    j.getChildCount = env->GetMethodID(j.viewGroupCls, "getChildCount", "()I");
    j.getChildAt    = env->GetMethodID(j.viewGroupCls, "getChildAt", "(I)Landroid/view/View;");
    if(Pending(env) || !j.getChildCount || !j.getChildAt) { Fail(r, "ViewGroup methods not found"); return r; }

    Walk(j, decor, 0);
    r.surfaceViews = j.count;
    if(!j.firstSv)
    {
        Fail(r, "no SurfaceView in the Activity (this backend does not apply)");
        return r;
    }

    jmethodID getHolder = env->GetMethodID(j.surfaceViewCls, "getHolder", "()Landroid/view/SurfaceHolder;");
    jclass holderCls = env->FindClass("android/view/SurfaceHolder");
    jmethodID setFixed  = holderCls ? env->GetMethodID(holderCls, "setFixedSize", "(II)V") : nullptr;
    jmethodID setLayout = holderCls ? env->GetMethodID(holderCls, "setSizeFromLayout", "()V") : nullptr;
    jmethodID getFrame  = holderCls ? env->GetMethodID(holderCls, "getSurfaceFrame", "()Landroid/graphics/Rect;") : nullptr;
    jclass rectCls = env->FindClass("android/graphics/Rect");
    jmethodID rectW = rectCls ? env->GetMethodID(rectCls, "width", "()I") : nullptr;
    jmethodID rectH = rectCls ? env->GetMethodID(rectCls, "height", "()I") : nullptr;
    jclass viewCls = env->FindClass("android/view/View");
    jmethodID viewW = viewCls ? env->GetMethodID(viewCls, "getWidth", "()I") : nullptr;
    jmethodID viewH = viewCls ? env->GetMethodID(viewCls, "getHeight", "()I") : nullptr;
    if(Pending(env) || !getHolder || !setFixed || !setLayout || !getFrame || !rectW || !rectH || !viewW || !viewH)
    {
        Fail(r, "SurfaceHolder/Rect/View methods not found");
        return r;
    }

    jobject holder = env->CallObjectMethod(j.firstSv, getHolder);
    if(Pending(env) || !holder) { Fail(r, "getHolder() failed"); return r; }

    if(op == Op::SetFixed)
        env->CallVoidMethod(holder, setFixed, (jint)w, (jint)h);
    else if(op == Op::SetFromLayout)
        env->CallVoidMethod(holder, setLayout);
    if(Pending(env)) { Fail(r, "Java exception while changing the surface size"); return r; }

    jobject rect = env->CallObjectMethod(holder, getFrame);
    if(Pending(env) || !rect) { Fail(r, "getSurfaceFrame() failed"); return r; }
    r.frameW = env->CallIntMethod(rect, rectW);
    r.frameH = env->CallIntMethod(rect, rectH);
    r.viewW  = env->CallIntMethod(j.firstSv, viewW);
    r.viewH  = env->CallIntMethod(j.firstSv, viewH);
    if(Pending(env)) { Fail(r, "reading sizes failed"); return r; }

    r.ok = true;
    return r;
}

} // namespace backend

// ---------------------------------------------------------------------------
// UI-thread hop. The task is shared so a timed-out caller never leaves a
// dangling pointer behind for the UI thread to write into.
// ---------------------------------------------------------------------------
namespace {

struct UITask
{
    Op op; int w; int h;
    SurfaceInfo result;
    std::mutex m;
    std::condition_variable cv;
    bool done = false;
};

void UIThunk(void* p)
{
    auto* sp = static_cast<std::shared_ptr<UITask>*>(p);
    UITask& t = **sp;
    SurfaceInfo r = backend::Run(t.op, t.w, t.h);
    {
        std::lock_guard<std::mutex> l(t.m);
        t.result = r;
        t.done = true;
    }
    t.cv.notify_all();
    delete sp;
}

} // namespace

bool RunBackend(Op op, int w, int h, SurfaceInfo* out, int timeoutMs)
{
    auto task = std::make_shared<UITask>();
    task->op = op; task->w = w; task->h = h;
    auto* holder = new std::shared_ptr<UITask>(task);

    if(!aml->PushToJavaUIThread(UIThunk, holder))
    {
        delete holder;
        return false;
    }

    std::unique_lock<std::mutex> l(task->m);
    if(!task->cv.wait_for(l, std::chrono::milliseconds(timeoutMs), [&]{ return task->done; }))
        return false;
    if(out) *out = task->result;
    return true;
}

} // namespace hres

# HEXED Resolution 0.1 (beta, unverified on device)

Native AML plugin plus an in-game mimgui Lua menu that tries to change **only the
game's render surface size** on Nezuko SA-MP Android (1.0.3 TESTING, 32-bit
armeabi-v7a). Android's system resolution and DPI are never touched, and there is
no ADB, companion app or extra permission.

## Honest status

| Item | Status |
|---|---|
| C++ sources type-checked against the real AML headers (commit `3ef5c91`, IAML_VER `01040100`) | Done, with host g++ and stand-ins for the Android-only headers |
| Built with the Android NDK | **Not done here.** The GitHub Actions workflow does it. |
| Lua menu syntax (LuaJIT) | Checked |
| Run on a device / Nezuko client | **Not done** |
| Whether the Nezuko client survives a surface resize (viewport, HUD, touch) | **Unknown.** This is what the beta test answers. |

No game memory offsets and no PixelsPub code are used. PixelsPub only informed the UX
(presets, custom size, Apply/Reset, auto-revert). It changes system-wide size/density
with `WRITE_SECURE_SETTINGS`, which is what this project avoids.

## How it works

```
Lua menu (Hexed Resolution.lua)  --request.txt-->  HexedResolution plugin  --JNI-->  SurfaceView
                                 <--status.txt---   (one background thread)           setFixedSize(w,h)
```

* Backend: finds the `SurfaceView` in the current Activity and calls the public
  Android API `SurfaceHolder.setFixedSize(w, h)`. The GPU renders into a w x h buffer
  and Android scales it to the screen. `setSizeFromLayout()` restores the original.
* Bridge: a small text-file channel in `<Android/data/<package>/files>/HexedResolution/`.
  It needs nothing from the Lua runtime except `io`. A direct `ffi` call into the
  plugin is not used because loading the plugin by name from LuaJIT is not verified.
* Apply is checked: after `setFixedSize` the plugin re-reads `getSurfaceFrame()`. If it
  does not match, it reverts and reports `failed`. `applied` only means Android reports
  the new surface size. It does not prove the game drew correctly.
* Auto-revert: a manual Apply reverts after `KeepSeconds` (default 15) unless you press
  **Keep**. This also rescues you if touch stops matching the picture.
* Aspect ratio: presets are percentages of the native size with the aspect preserved
  (rounded to even numbers). Custom sizes can lock aspect; the plugin rejects sizes
  whose aspect differs from native by more than 2% unless `AllowStretch=1`.
* Unsupported cases are reported, not hidden: no Activity, no `SurfaceView`, a size
  above native, below 320x180, or a UI-thread timeout.

## API inventory (nothing invented)

All AML calls are declared in `mod/iaml.h`, `mod/amlmod.h`, `mod/config.h`, `mod/logger.h`
of the pinned AML commit: `MYMODCFG`, `BEGIN_DEPLIST`/`ADD_DEPENDENCY_VER`,
`ON_MOD_PRELOAD`/`ON_MOD_LOAD`/`ON_MOD_UNLOAD`, `aml->PushToJavaUIThread`,
`GetCurrentActivity`, `GetJavaVM`, `GetAndroidDataPath`, `CreateDirRecursive`,
`GetDisplaySize`, `GetCurrentGame`, `GetAppVersionName`, `GetAppVersionCode`,
`cfg->Bind/GetInt/GetBool/Save`, `ConfigEntry::SetInt/SetBool`, `logger->Info/Error`.
Android APIs: `Activity.getWindow`, `Window.getDecorView`, `ViewGroup.getChildCount/
getChildAt`, `SurfaceView.getHolder`, `SurfaceHolder.setFixedSize/setSizeFromLayout/
getSurfaceFrame`, `Rect.width/height`, `View.getWidth/getHeight`.
Not used: any hook, pattern scan, memory patch or offset.

## Build

**GitHub Actions (zip-driven):** put only two things in a GitHub repo: this zip in the repo root and
`.github/workflows/build.yml` (delivered separately). Every push of the zip unzips it, adds the AML
headers at a pinned commit, builds with NDK r26d for `armeabi-v7a`, checks the ELF is 32-bit ARM and
exports `__GetModInfo`/`OnModLoad`, and uploads `libHexedResolution.so` (plus the Lua) as the
`HexedResolution-armeabi-v7a` artifact on the run's page.

**Local / AML Compiler Android:** copy `mod/` from your AML SDK (`template_of_mod/mod`) to
`jni/mod`, then build with `jni/Android.mk` and `jni/Application.mk`
(`ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk`).
Output: `libs/armeabi-v7a/libHexedResolution.so`.

The plugin depends on AML >= 1.4.0 (`PushToJavaUIThread`, `GetCurrentActivity`). If the
client's `libAML.so` is older, AML will refuse to load it.

## Install

1. `libHexedResolution.so` into the AML mods folder: `/sdcard/Android/data/com.nezukosamp.game/mods/`.
2. `Hexed Resolution.lua` next to your other HEXED scripts. Chat command: `/hexres`.
3. Start the game once. The plugin writes `HexedResolution.ini` (section `[Resolution]`).

`[Resolution]` keys: `Enabled` (0 = plugin idle, emergency off), `AutoApply`,
`SavedWidth`/`SavedHeight`/`Confirmed`/`BootPending` (managed by the plugin),
`AllowStretch`, `KeepSeconds`, `BootDelaySeconds`, `PollMs`.
The Lua ini `Hexed Resolution.ini` has `channelDir`; it must equal the `channel=` path the
plugin prints in logcat (the default already uses `com.nezukosamp.game`).

## Beta test procedure

1. Install the `.so` only. Start the game, wait in the main menu or in game, and collect logcat for tag
   `HexedResolution`. Expect `channel=...` and `surface WxH view WxH svViews=N display=WxH`.
   If it says "no SurfaceView", this backend does not apply to the client: stop and send the log.
2. Install the Lua. `/hexres`, Status tab: plugin "running", SurfaceViews found >= 1.
3. Apply **90%**. Check: picture fills the screen, no black bars or cropped corner, HUD and chat
   aligned, menu buttons and the on-screen controls respond where you tap, aiming works.
   Press **Keep** or let it revert. Repeat with 75%, 66%, 50%.
4. Press **Reset**: the original look must return (Status tab shows the surface frame).
5. Persistence: Keep a size, set `AutoApply=1`, restart. It applies after about
   `BootDelaySeconds`, and `BootPending` clears after 30 s of stability.
6. Safety: right after a startup auto-apply, force-stop the game within 30 s. The next start must
   report "did not stay stable" and skip the saved size.
7. Performance: compare FPS at 100% and 66% with your usual method. No gain is claimed.
8. Report: the logcat lines from step 1, which sizes worked, and a screenshot of anything misaligned.

## Recovery

Set `Enabled=0` in `HexedResolution.ini`, or delete the ini and the folder
`.../files/HexedResolution/`, then restart the game. A stuck surface size always goes
back to normal after the game process restarts.

## Known limitations

* The backend is **unverified for Nezuko**. It only works if the client renders into an Android
  `SurfaceView` and re-reads the surface size. If the game caches its own viewport, a size change can
  produce a cropped or offset picture. That is why Apply needs Keep.
* Touch and HUD alignment depend on how the client maps input to the surface. Untested.
* It lowers the buffer the GPU fills, so it may help fill-rate-bound devices. It does not touch
  geometry, shadows or CPU cost.
* The mimgui menu is drawn inside the game surface, so it also gets scaled with it.
* Sizes above native, odd sizes (rounded to even) and aspect changes are restricted in this beta.
* Single backend. A RenderWare/EGL-level backend would need verified offsets or imports from your
  binary and is deliberately not guessed here.
* `OnGameCrash` is not used (not guaranteed, not signal-safe). Crash protection is the `BootPending`
  flag. Quitting within 30 s of an auto-apply also counts as unstable.
* `GetCurrentActivity()` must return the game Activity. Not checked on the client.
* ARMv7 only (Application.mk). The 64-bit path was not built.

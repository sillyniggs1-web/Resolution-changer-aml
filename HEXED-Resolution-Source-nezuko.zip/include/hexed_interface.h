/*
 * HEXED Resolution — mod-to-mod interface (AML interface system).
 *
 * Registered from OnModLoad via the documented AML mechanism:
 *     RegisterInterface("IHexedResolution001", &g_Interface);
 *
 * This follows the AML interface convention (see AML documentation §6):
 * a plain struct of function pointers shared with consumers under an agreed
 * name. Other AML mods (including a native Lua-host mod, if a client ships
 * one) may call these directly instead of going through the file bridge.
 *
 * All functions return RequestResult-style codes identical to ApplyCode in
 * render_backend.h; status strings are written into caller buffers.
 *
 * ABI: IHexedResolution001 is frozen. Future breaking changes will ship as
 * IHexedResolution002 registered under a new name.
 */
#ifndef HEXED_INTERFACE_H
#define HEXED_INTERFACE_H

#define HEXED_INTERFACE_NAME     "IHexedResolution001"
#define HEXED_INTERFACE_VERSION  1

struct IHexedResolution001
{
    int interfaceVersion;   /* == HEXED_INTERFACE_VERSION */

    /* Probe current rendering state. Returns 1 when `rsValid` was filled. */
    int (*Probe)(int* rsW, int* rsH, int* eglW, int* eglH, int* glW, int* glH);

    /* Request a resolution change (native validation applies).
     * Returns one of: 0 OK, 1 QUEUED, 2 INVALID, 3 UNSUPPORTED,
     *                  4 FAILED, 5 DISABLED (mirrors ApplyCode). */
    int (*Apply)(int w, int h);

    /* Restore original dimensions. Returns ApplyCode. */
    int (*Reset)();

    /* Master enable/disable. Returns ApplyCode (OK). */
    int (*Enable)(int enabled);

    /* Single-line status into `out` (at most outLen bytes, NUL-terminated). */
    void (*StatusLine)(char* out, int outLen);
};

#endif /* HEXED_INTERFACE_H */

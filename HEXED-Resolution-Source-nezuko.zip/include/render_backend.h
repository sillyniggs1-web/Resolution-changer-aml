/*
 * HEXED Resolution — rendering backend interface.
 *
 * This is a HEXED project interface, NOT an upstream AML API. It hides the
 * concrete strategy used to read (probe) and change (apply) the game's
 * internal rendering dimensions.
 *
 * ── Verified mechanism used by this build ──────────────────────────────────
 * The AML Plugin SDK (aml-psdk, GPL-3.0, see LICENSES.md) pins the location
 * of the RenderWare `RsGlobalType` object for two specific game builds:
 *
 *   GTA:SA Android v2.00 (armeabi-v7a): pointer at libGTASA.so + 0x67910C
 *   GTA:SA Android v2.10 (arm64-v8a):   pointer at libGTASA.so + 0x850240
 *
 * `RsGlobalType` carries `maximumWidth` / `maximumHeight` (i32 pair). The
 * PSDK's own ScreenUtils derives the HUD/render coordinate space from these
 * fields, which makes them the game's internal rendering dimensions on the
 * supported builds.
 *
 * Safety model (deliberately conservative, per project requirements):
 *  1. COMPAT CHECK — the pointer at the pinned offset is dereferenced ONLY
 *     after three read-only checks: offset inside the mapped library, pointer
 *     value inside the mapped library (RsGlobalType is a static object of the
 *     lib itself), and the width/height pair at the target looks like a real
 *     resolution (256..7680). Any failure => profile marked UNSUPPORTED and
 *     the backend never writes game memory.
 *  2. APPLY — writes exactly two i32 fields through AML's Unprot/Write32.
 *     The original values are captured first for Reset().
 *  3. Full internal-resolution effect requires the RenderWare camera/raster
 *     to be (re)created from these values; the plugin therefore also applies
 *     at the `initRwEvent` lifecycle point. Mid-game applies change the
 *     reported/rendered coordinate space immediately and take full effect at
 *     the next renderer initialization. Probe()/diagnostics let the user
 *     verify what actually happened; the plugin never reports more success
 *     than it can prove.
 *
 * ── Diagnostic layer (always available, no game-memory writes) ─────────────
 *   ProbeEGL(): EGL window-surface size + GL viewport + renderer strings via
 *   standard EGL/GLES queries on the current thread. This is how a runtime
 *   session proves what the game is actually rendering at.
 */
#ifndef HEXED_RENDER_BACKEND_H
#define HEXED_RENDER_BACKEND_H

#include <cstdint>
#include <cstddef>

namespace hxres
{
    enum BackendCompat
    {
        COMPAT_UNCHECKED = 0,
        COMPAT_OK,               /* RsGlobal located and validated */
        COMPAT_UNSUPPORTED,      /* lib missing / pointer audit failed */
        COMPAT_PENDING,          /* pointer verified, but RsGlobal dimensions are not
                                    plausible YET (renderer not initialised). Re-checked
                                    on the game thread until they are. Nothing is written
                                    while PENDING. */
    };

    enum ApplyCode
    {
        APPLY_OK            = 0, /* values written and read back identical      */
        APPLY_QUEUED        = 1, /* stored for the next renderer initialization */
        APPLY_INVALID       = 2, /* rejected input                              */
        APPLY_UNSUPPORTED   = 3, /* backend cannot safely write this build      */
        APPLY_FAILED        = 4, /* write attempted, verification failed        */
        APPLY_DISABLED      = 5, /* allowNativeApply=false (policy, not error)  */
    };

    struct RenderProbe
    {
        bool  rsValid;           /* RsGlobal readable and validated        */
        int   rsWidth;           /* RsGlobal.maximumWidth  (0 if invalid)  */
        int   rsHeight;          /* RsGlobal.maximumHeight (0 if invalid)  */

        bool  eglValid;          /* EGL surface query succeeded            */
        int   eglWidth;          /* actual EGL window-surface width        */
        int   eglHeight;         /* actual EGL window-surface height       */

        bool  glValid;           /* GL viewport query succeeded            */
        int   glViewport[4];     /* x, y, w, h                             */

        char  glRenderer[96];    /* GL_RENDERER string (best effort)       */
        char  glVersion[64];     /* GL_VERSION string (best effort)        */
    };

    struct ApplyResult
    {
        ApplyCode code;
        int       width;         /* dimensions actually confirmed written  */
        int       height;
        char      message[160];  /* human-readable, safe for the menu      */
    };

    class RenderBackend
    {
    public:
        static RenderBackend& Get();

        /* One-time compatibility audit of the target library. Safe to call
         * again; it will not re-run after a definitive result. */
        void  InitCompat(uintptr_t libBase, size_t libLength,
                         bool useCustomProfile,
                         int64_t customPtrOffset32, int64_t customPtrOffset64);

        BackendCompat Compat() const        { return m_compat; }

        /* Game thread: promote PENDING -> OK once RsGlobal holds a plausible
         * resolution (captures the original values at that moment). Cheap. */
        bool  Recheck();
        const char*   CompatReason() const  { return m_compatReason; }

        /* The pinned profile this build resolves (0 = custom/diagnostic). */
        uint32_t ProfilePins() const        { return m_pinVersionMask; }

        /* Read current state. Never writes game memory. */
        void  Probe(RenderProbe& out);

        /* Attempt to set new internal dimensions (see ApplyCode). */
        ApplyResult Apply(int w, int h);

        /* Restore the original dimensions captured before the first Apply. */
        ApplyResult Reset();

        bool  HasApplied() const            { return m_applied; }
        void  CurrentApplied(int& w, int& h) const { w = m_appliedW; h = m_appliedH; }
        void  Original(int& w, int& h) const { w = m_origW; h = m_origH; }

        /* True when the game has overwritten the applied values (drift). */
        bool  Drifted();

    private:
        RenderBackend();

        bool  ResolveRsGlobal();            /* pointer audit (structural, read-only) */
        bool  ValidateDims();               /* value plausibility + capture originals */
        bool  ReadRsGlobal(int& w, int& h);
        bool  WriteRsGlobal(int w, int h);

        uintptr_t m_libBase;
        size_t    m_libLength;
        uintptr_t m_rsGlobalPtrAddr;  /* address of the POINTER to RsGlobalType */
        uintptr_t m_rsGlobalAddr;     /* address of RsGlobalType itself         */
        BackendCompat m_compat;
        char          m_compatReason[160];
        uint32_t      m_pinVersionMask; /* bit0: v2.00 pin, bit1: v2.10 pin, bit2: custom */

        int   m_origW, m_origH;
        int   m_origValid;
        bool  m_applied;
        int   m_appliedW, m_appliedH;
    };
}

#endif /* HEXED_RENDER_BACKEND_H */

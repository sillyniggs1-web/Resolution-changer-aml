/*
 * HEXED Resolution — Lua/native command-file bridge.
 *
 * This is a HEXED project interface, NOT an upstream AML API.
 *
 * WHY THIS BRIDGE EXISTS
 * ----------------------
 * AML (AndroidModLoader) itself is a native mod loader and does not embed a
 * Lua runtime; Lua in SA-MP mobile clients (Nezuko and similar repacks) is
 * provided by the client, and its scripting surface differs between builds.
 * To stay compatible without inventing client-specific API calls, the plugin
 * communicates with ANY Lua runtime that has standard `io` file access
 * through two small text files inside AML's writable external directory:
 *
 *   <aml->GetAndroidDataPath()>/hexed/bridge_cmd.txt    Lua  ->  plugin
 *   <aml->GetAndroidDataPath()>/hexed/bridge_out.txt    plugin  ->  Lua
 *
 * Protocol (documented in README.md; mirrored by lua/HexedResolution.lua):
 *   cmd line:  <COMMAND> [args...]
 *     status                       request status report
 *     probe                        request rendering probe
 *     apply <w> <h> [presetName]   request resolution change
 *     reset                        restore original dimensions
 *     enable <0|1>                 master enable/disable
 *     save <w> <h> <presetName>    persist a selection
 *     restore                      apply the persisted selection
 *     last                         result of the most recent command
 *     log [n]                      request the last n log lines
 *     help                         list commands
 *
 *   out line:  <CMD>|<CODE>|<w>|<h>|<text>
 *     CODE: OK, QUEUED, INVALID, UNSUPPORTED, FAILED, DISABLED, INFO
 *
 * Threading: a low-frequency worker thread (200 ms) reads commands and writes
 * responses; game-memory operations are deferred to the game thread through
 * ResolutionAPI::FrameTick(), so no game state is touched from the worker.
 */
#ifndef HEXED_LUA_BRIDGE_H
#define HEXED_LUA_BRIDGE_H

#include <string>

namespace hxbridge
{
    bool Start(const char* androidDataPath);
    void Stop();                 /* signals + joins the worker thread */
    const char* CmdPath();
    const char* OutPath();

    /* Run one command synchronously on the calling thread (see hexed_command). */
    int Execute(const char* cmd, char* out, int outLen);
}

/* C entry point for Lua `ffi` (MonetLoader/LuaJIT):
 *     ffi.cdef[[ int hexed_command(const char*, char*, int); ]]
 *     local L = ffi.load("libHexedResolution.so")   -- already loaded by AML
 * Response format is identical to the file bridge: CMD|CODE|w|h|text */
extern "C" int hexed_command(const char* cmd, char* out, int outLen);

#endif /* HEXED_LUA_BRIDGE_H */

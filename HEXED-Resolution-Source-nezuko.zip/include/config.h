/*
 * HEXED Resolution — project-owned configuration model.
 *
 * Persistence uses the documented AML `Config` mechanism (MYMODCFGNAME), so
 * the file lives in AML's config directory as:
 *     <aml->GetConfigPath()>/HexedResolution.ini
 * (AML resolves the directory at runtime; typically
 *  /sdcard/Android/data/<game.package>/configs/ on external storage.)
 *
 * This module layers project-owned validation on top of AML's INI handling:
 *  - every value is clamped / range-checked before use,
 *  - saved preferences (what the user wants) are kept distinct from the
 *    confirmed-active rendering settings held by the render backend,
 *  - missing or malformed values fall back to safe defaults.
 */
#ifndef HEXED_CONFIG_H
#define HEXED_CONFIG_H

#include <cstdint>

namespace hxres
{
    /* Preset identifiers shared with the Lua menu. */
    enum Preset
    {
        PRESET_NONE    = 0,   /* no selection yet */
        PRESET_1280x720,
        PRESET_960x540,
        PRESET_800x450,
        PRESET_CUSTOM,        /* use custom_width / custom_height */
        PRESET_COUNT
    };

    /* Validation limits (shared with the Lua menu; also enforced natively). */
    static const int    MIN_DIMENSION   = 128;
    static const int    MAX_DIMENSION   = 7680;
    static const double MIN_ASPECT      = 0.40;   /* h/w */
    static const double MAX_ASPECT      = 2.80;   /* h/w */

    struct HexedConfig
    {
        /* [hexed] — feature switches */
        bool    enabled;             /* master switch; when false the plugin only reports status */
        bool    verboseLogging;      /* per-frame diagnostic sampling */
        bool    hudStatus;           /* draw the compact on-screen HEXED status line */
        bool    restoreAtStartup;    /* re-apply last successfully applied preset at RW init */
        bool    watchdog;            /* re-apply if the game overwrites the applied values */

        /* [presets] — user selection (a REQUEST, not a confirmed state) */
        int     preset;              /* Preset enum */
        int     customWidth;
        int     customHeight;

        /* [applied] — bookkeeping of the last apply that the plugin actually
         * performed (0/none if nothing was applied this install). */
        int     lastAppliedWidth;
        int     lastAppliedHeight;
        int     lastAppliedPreset;

        /* [backend] — native application gating */
        bool    allowNativeApply;    /* master gate for game-memory writes; default OFF */
        bool    useCustomProfile;    /* use the offsets below instead of the PSDK pins */
        int64_t customRsGlobalPtrOffset32;  /* offset of the POINTER to RsGlobalType, 32-bit lib */
        int64_t customRsGlobalPtrOffset64;  /* offset of the POINTER to RsGlobalType, 64-bit lib */
    };

    /* Load with defaults + validation. Safe on missing/malformed files. */
    void    LoadConfig(HexedConfig& cfg);

    /* Persist current values (only meaningful changes are written by AML). */
    void    SaveConfig(const HexedConfig& cfg);

    /* Reset to documented defaults and persist. */
    void    ResetConfig(HexedConfig& cfg);

    /* Resolve a preset into requested dimensions. Returns false for
     * PRESET_NONE or a custom preset with out-of-range values. */
    bool    ResolvePreset(const HexedConfig& cfg, int& outW, int& outH);

    const char* PresetName(int preset);

    /* Shared dimension validation. Returns true and clamps nothing when the
     * request is sane; false when it must be rejected (caller reports why). */
    bool    ValidateDimensions(int w, int h, char* reason, int reasonLen);
}

#endif /* HEXED_CONFIG_H */

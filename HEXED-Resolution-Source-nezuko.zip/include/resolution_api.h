/*
 * HEXED Resolution — resolution request orchestration.
 *
 * This is a HEXED project interface, NOT an upstream AML API. It owns the
 * request state machine between the Lua menu (via the bridge), the render
 * backend, and the game's renderer lifecycle events.
 *
 * Apply semantics (honest by design):
 *  - A request is validated, stored, and applied through RenderBackend.
 *  - When the renderer has not been initialized yet (or a full internal-
 *    resolution change is requested), the request is reported as QUEUED and
 *    is applied inside the `initRwEvent` (before) lifecycle hook, which is
 *    the safe point before RenderWare allocates camera rasters.
 *  - The plugin reports exactly what happened; it never claims a resolution
 *    is active merely because the value was stored.
 */
#ifndef HEXED_RESOLUTION_API_H
#define HEXED_RESOLUTION_API_H

#include <cstdint>

#include "render_backend.h"

namespace hxres
{
    /* Renderer lifecycle tracking (driven by PSDK events in main.cpp). */
    enum RendererState
    {
        RW_NOT_READY = 0,
        RW_READY,          /* initRwEvent fired */
        RW_TERMINATED,     /* shutdownRwEvent fired */
    };

    struct RequestResult
    {
        ApplyCode  code;
        int        width;        /* dimensions confirmed written, else 0 */
        int        height;
        char       message[192];
    };

    class ResolutionAPI
    {
    public:
        static ResolutionAPI& Get();

        /* Called once from OnModLoad after backend compat + config load. */
        void Init(bool enabled, bool restoreAtStartup, bool watchdog,
                  bool allowNativeApply);

        /* Called from OnModUnload. Attempts to restore originals if asked. */
        void Shutdown(bool tryRestore);

        /* ---- Commands (thread-safe; called from the bridge worker or the
         *       game thread). Results are synchronous for state questions and
         *       queued for game-thread execution where game memory is touched.
         * ---- */

        RequestResult Apply(int w, int h, int preset);   /* preset: Preset enum or PRESET_NONE */
        RequestResult Reset();
        RequestResult Enable(bool enabled);
        RequestResult AllowNativeApply(bool allow);      /* persists [backend] AllowNativeApply */
        RequestResult SaveSelection(int w, int h, int preset);
        RequestResult RestoreSelection();

        /* Bookkeeping-only save of the last confirmed apply (called on the
         * game thread after a successful write). */
        void NoteApplied(int w, int h, int preset);

        /* ---- Game-thread tick (called from the PSDK frameEnd event). ---- */
        void FrameTick();

        /* ---- Renderer lifecycle hooks (called from main.cpp). ---- */
        void OnInitRenderWareBefore();   /* may perform the queued apply */
        void OnInitRenderWareAfter();
        void OnShutdownRenderWare();

        /* ---- Status for menus ---- */
        RendererState RendererReady() const     { return m_rwState; }
        void  LastResult(RequestResult& out) const;   /* most recent command result */
        /* Compact single-line status: "1280x720 (applied) / EGL 1920x1080" */
        int   BuildStatusLine(char* out, int outLen);
        /* Version / compatibility summary (what the menu shows first). */
        int   BuildInfoLine(char* out, int outLen);

        bool  Enabled() const                   { return m_enabled; }
        void  SetWatchdog(bool on)              { m_watchdog = on; }
        void  SetAllowNativeApply(bool on)      { m_allowNativeApply = on; }
        void  SetRestoreAtStartup(bool on)      { m_restoreAtStartup = on; }

    private:
        ResolutionAPI();

        void  PerformQueuedApply();      /* game thread only */
        void  SampleDiagnostics();       /* verbose mode, game thread */

        RendererState   m_rwState;
        bool            m_enabled;
        bool            m_restoreAtStartup;
        bool            m_watchdog;
        bool            m_allowNativeApply;

        /* Pending request (validated, waiting for a safe apply point). */
        bool            m_pendingValid;
        int             m_pendingW, m_pendingH, m_pendingPreset;
        bool            m_pendingReset;      /* restore originals on the game thread */

        /* What the plugin has confirmed applied to RsGlobal. */
        bool            m_activeValid;
        int             m_activeW, m_activeH, m_activePreset;

        /* Watchdog rate limiting. */
        int             m_frameCounter;
        int             m_lastDriftFrame;

        /* Last command result (for menu display). */
        mutable RequestResult m_lastResult;
    };
}

#endif /* HEXED_RESOLUTION_API_H */

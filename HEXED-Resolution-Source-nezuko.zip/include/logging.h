/*
 * HEXED Resolution — project-owned diagnostic logging.
 *
 * This is a HEXED project interface, NOT an upstream AML API.
 * It wraps the AML `logger` (logcat) and adds an on-device file log plus a
 * small in-memory ring buffer that the Lua menu can query for recent lines.
 *
 * File log location (resolved at init from AML):
 *   <aml->GetAndroidDataPath()>/hexed/hexed_resolution.log
 */
#ifndef HEXED_LOGGING_H
#define HEXED_LOGGING_H

#include <cstdarg>
#include <cstddef>

namespace hxlog
{
    bool  Init(const char* androidDataPath, bool verbose);
    void  Shutdown();
    void  SetVerbose(bool verbose);
    bool  IsVerbose();

    /* Levelled logging. Always goes to logcat (via AML logger); goes to the
     * file log when the file log is open. */
    void  V(const char* fmt, ...);   /* verbose-only */
    void  I(const char* fmt, ...);
    void  W(const char* fmt, ...);
    void  E(const char* fmt, ...);

    /* Retrieve up to `maxLines` most recent log lines (oldest first).
     * Copies are NUL-separated into `out`; returns number of lines copied. */
    int   RecentLines(char* out, size_t outLen, int maxLines);

    /* Absolute path of the file log ("" if not open). */
    const char* FilePath();
}

#endif /* HEXED_LOGGING_H */

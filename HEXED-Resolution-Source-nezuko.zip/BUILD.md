# BUILD.md — building HEXED Resolution from source

## Toolchain

- **Android NDK r26d** (the AML/PSDK ecosystem builds with the clang toolchain
  and `ndk-build`; r25–r27 work — the CI pins r26d).
- No other dependencies. The AML mod headers (`mod/`, MIT) and the AML Plugin
  SDK headers (`aml-psdk/`, GPL-3.0) are **vendored** in this repository — do
  not download them separately. Their versions must stay in sync with the
  plugin code (`IAML_VER 01040100`).

## Local build (Linux / macOS)

```bash
./scripts/build.sh /path/to/android-ndk-r26d
```

The script:

1. Verifies all required vendored headers/sources exist (fails with exit 2
   otherwise).
2. Runs `ndk-build` with the root `Android.mk` / `Application.mk` (same flags
   as the AML examples: `-O2 -mfloat-abi=softfp -std=c++17 -fexceptions`,
   `c++_static`, ABI `armeabi-v7a arm64-v8a`, platform `android-21`).
3. Fails (exit 3) if no `libHexedResolution*.so` was produced.

Output:

```
build/libs/armeabi-v7a/libHexedResolution.so    (GTA:SA v2.00, 32-bit clients)
build/libs/arm64-v8a/libHexedResolution64.so    (GTA:SA v2.10, 64-bit clients)
```

### Windows

Use the same `ndk-build` invocation with `NDK_PROJECT_PATH` /
`APP_BUILD_SCRIPT` / `NDK_APPLICATION_MK` / `NDK_LIBS_OUT` overrides, e.g.
adapting the AML project's `build.ps1` pattern, or build under WSL.

## ABI notes

Both ABIs are built because SA:SA Android ships both 32-bit (v2.00) and 64-bit
(v2.10) builds and repacked clients vary. Android loads only the ABI matching
the installed game, so shipping both files in the mods folder is safe. To trim
build time, edit `APP_ABI` in `Application.mk` — do this if you have verified
which ABI your client uses.

## GitHub Actions build

`.github/workflows/build.yml`:

- Trigger: `workflow_dispatch` (manual), plus pushes/PRs to `main`/`master`.
- Matrix build: one job per ABI.
- Steps: checkout → verify required files → install NDK r26d from
  dl.google.com → `scripts/build.sh` → verify the `.so` exists → inspect ELF
  class/machine with `llvm-readelf` → package `lua/`, `config/`, `README`,
  `INSTALL`, `TESTING` and the `.so` into a ZIP → upload as artifact
  (`actions/upload-artifact@v4`, `if-no-files-found: error`).

The workflow fails if compilation fails **or** if the expected `.so` is
missing — it cannot report success without a real library.

## Cleaning

```bash
rm -rf build/          # object + library outputs
```

## Build configuration reference

| File | Purpose |
|---|---|
| `Android.mk` | Module `HexedResolution` / `HexedResolution64`, sources, includes, `-llog -lEGL -lGLESv2 -landroid -ldl` |
| `Application.mk` | `c++_static`, ABIs, `android-21`, clang, release |
| `scripts/build.sh` | ndk-build wrapper + header verification + output check |
| `.github/workflows/build.yml` | CI build + artifact packaging |

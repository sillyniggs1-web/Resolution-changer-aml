#ifndef __AML_PSDK_RWIM2D_H
#define __AML_PSDK_RWIM2D_H

#include <aml-psdk/sdk_base.h>
#include "RwMatrix.h"
#include <aml-psdk/gta_base/DrawVertices.h>
#include "RwVector.h"
#include "RxPipeline.h"

struct RwRaster;

enum RwPrimitiveType : u32
{
    rwPRIMTYPENAPRIMTYPE = 0,   /**<Invalid primative type */
    rwPRIMTYPELINELIST = 1,     /**<Unconnected line segments, each line is specified by
                                 * both its start and end index, independently of other lines
                                 * (for example, 3 segments specified as 0-1, 2-3, 4-5) */
    rwPRIMTYPEPOLYLINE = 2,     /**<Connected line segments, each line's start index
                                 * (except the first) is specified by the index of the end of
                                 * the previous segment (for example, 3 segments specified as
                                 * 0-1, 1-2, 2-3) */
    rwPRIMTYPETRILIST = 3,      /**<Unconnected triangles: each triangle is specified by
                                 * three indices, independently of other triangles (for example,
                                 * 3 triangles specified as 0-1-2, 3-4-5, 6-7-8) */
    rwPRIMTYPETRISTRIP = 4,     /**<Connected triangles sharing an edge with, at most, one
                                 * other forming a series (for example, 3 triangles specified
                                 * as 0-2-1, 1-2-3-, 2-4-3) */
    rwPRIMTYPETRIFAN = 5 ,      /**<Connected triangles sharing an edge with, at most,
                                 * two others forming a fan (for example, 3 triangles specified
                                 * as 0-2-1, 0-3-2, 0-4-3) */
    rwPRIMTYPEPOINTLIST = 6,    /**<Points 1, 2, 3, etc. This is not
                                 * supported by the default RenderWare
                                 * immediate or retained-mode pipelines
                                 * (except on PlayStation 2), it is intended
                                 * for use by user-created pipelines */
};

enum RwRenderState : u32
{
    rwRENDERSTATENARENDERSTATE = 0,

    rwRENDERSTATETEXTURERASTER,
        /**<Raster used for texturing (normally used in immediate mode). 
         *  The value is a pointer to an \ref RwRaster.
         * Default: NULL.
         */
    rwRENDERSTATETEXTUREADDRESS,
        /**<\ref RwTextureAddressMode: wrap, clamp, mirror or border.
         * Default: rwTEXTUREADDRESSWRAP.
         */
    rwRENDERSTATETEXTUREADDRESSU,
        /**<\ref RwTextureAddressMode in u only.
         * Default: rwTEXTUREADDRESSWRAP.
         */
    rwRENDERSTATETEXTUREADDRESSV,
        /**<\ref RwTextureAddressMode in v only.
         * Default: rwTEXTUREADDRESSWRAP.
         */
    rwRENDERSTATETEXTUREPERSPECTIVE,
        /**<Perspective correction on/off (always enabled on many platforms).
         */
    rwRENDERSTATEZTESTENABLE,
        /**<Z-buffer test on/off.
         * Default: TRUE.
         */
    rwRENDERSTATESHADEMODE,
        /**<\ref RwShadeMode: flat or gouraud shading.
         * Default: rwSHADEMODEGOURAUD.
         */
    rwRENDERSTATEZWRITEENABLE,
        /**<Z-buffer write on/off.
         * Default: TRUE.
         */
    rwRENDERSTATETEXTUREFILTER,
        /**<\ref RwTextureFilterMode: point sample, bilinear, trilinear, etc.
         * Default: rwFILTERLINEAR.
         */
    rwRENDERSTATESRCBLEND,
        /**<\ref RwBlendFunction used to modulate the source pixel color
         *  when blending to the frame buffer.
         * Default: rwBLENDSRCALPHA.
         */
    rwRENDERSTATEDESTBLEND,
        /**<\ref RwBlendFunction used to modulate the destination pixel
         *  color in the frame buffer when blending. The resulting pixel
         *  color is given by the formula 
         *  (SRCBLEND * srcColor + DESTBLEND * destColor) for each RGB
         *  component. For a particular platform, not all combinations
         *  of blend function are allowed (see platform specific
         *  restrictions).
         * Default: rwBLENDINVSRCALPHA.
         */
    rwRENDERSTATEVERTEXALPHAENABLE,
        /**<Alpha blending on/off (always enabled on some platforms). 
         *  This is normally used in immediate mode to enable alpha blending 
         *  when vertex colors or texture rasters have transparency. Retained
         *  mode pipelines will usually set this state based on material colors 
         *  and textures.
         * Default: FALSE.
         */
    rwRENDERSTATEBORDERCOLOR,
        /**<Border color for \ref RwTextureAddressMode 
         *  \ref rwTEXTUREADDRESSBORDER. The value should be a packed 
         *  RwUInt32 in a platform specific format. The macro 
         *  RWRGBALONG(r, g, b, a) may be used to construct this using 
         *  8-bit color components.
         * Default: RWRGBALONG(0, 0, 0, 0).
         */
    rwRENDERSTATEFOGENABLE,
        /**<Fogging on/off (all polygons will be fogged).  
         * Default: FALSE.
         */
    rwRENDERSTATEFOGCOLOR,
        /**<Color used for fogging. The value should be a packed RwUInt32 
         *  in a platform specific format. The macro RWRGBALONG(r, g, b, a)
         *  may be used to construct this using 8-bit color components. 
         * Default: RWRGBALONG(0, 0, 0, 0).
         */
    rwRENDERSTATEFOGTYPE,
        /**<\ref RwFogType, the type of fogging to use. 
         * Default: rwFOGTYPELINEAR.
         */
    rwRENDERSTATEFOGDENSITY,
        /**<Fog density for \ref RwFogType of 
         *  \ref rwFOGTYPEEXPONENTIAL or \ref rwFOGTYPEEXPONENTIAL2. 
         *  The value should be a pointer to an RwReal in the 
         *  range 0 to 1.  
         * Default: 1.
         */
    rwRENDERSTATECULLMODE = 20,
        /**<\ref RwCullMode, for selecting front/back face culling, or
         *  no culling.
         * Default: rwCULLMODECULLBACK.
         */
    rwRENDERSTATESTENCILENABLE,
        /**<Stenciling on/off.
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: FALSE.
         */
    rwRENDERSTATESTENCILFAIL,
        /**<\ref RwStencilOperation used when the stencil test passes.
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: rwSTENCILOPERATIONKEEP.
         */
    rwRENDERSTATESTENCILZFAIL,
        /**<\ref RwStencilOperation used when the stencil test passes and 
         *  the depth test (z-test) fails. 
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: rwSTENCILOPERATIONKEEP.
         */
    rwRENDERSTATESTENCILPASS,
        /**<\ref RwStencilOperation used when both the stencil and the depth 
         *  (z) tests pass. 
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: rwSTENCILOPERATIONKEEP.
         */
    rwRENDERSTATESTENCILFUNCTION,
        /**<\ref RwStencilFunction for the stencil test. 
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: rwSTENCILFUNCTIONALWAYS.
         */
    rwRENDERSTATESTENCILFUNCTIONREF,
        /**<Integer reference value for the stencil test. 
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: 0.
         */
    rwRENDERSTATESTENCILFUNCTIONMASK,
        /**<Mask applied to the reference value and each stencil buffer 
         *  entry to determine the significant bits for the stencil test. 
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: 0xffffffff.
         */
    rwRENDERSTATESTENCILFUNCTIONWRITEMASK,
        /**<Write mask applied to values written into the stencil buffer. 
         *  <i> Supported on Xbox, D3D8, D3D9, and OpenGL only. </i>
         * Default: 0xffffffff.
         */
    rwRENDERSTATEALPHATESTFUNCTION,
        /**<\ref RwAlphaTestFunction for the alpha test. When a pixel fails,
         * neither the frame buffer nor the Z-buffer are updated.
         * Default: rwALPHATESTFUNCTIONGREATER (GameCube, Xbox, D3D8, D3D9
         * and OpenGL). The default PS2 behaviour is to always update the
         * frame buffer and update the Z-buffer only if a greater than or
         * equal test passes.
         */
    rwRENDERSTATEALPHATESTFUNCTIONREF,
        /**<Integer reference value for the alpha test. 
         *  <i> Range is 0 to 255, mapped to the platform's actual range </i>
         * Default: 128 (PS2) 0 (GameCube, Xbox, D3D8, D3D9 and OpenGL).
         */
};

enum RwShadeMode : u32
{
    rwSHADEMODENASHADEMODE = 0,
    rwSHADEMODEFLAT,                /**<Flat shading */
    rwSHADEMODEGOURAUD,             /**<Gouraud shading */
};

enum RwCullMode : u32
{
    rwCULLMODENACULLMODE = 0,

    rwCULLMODECULLNONE, 
        /**<Both front and back-facing triangles are drawn. */
    rwCULLMODECULLBACK, 
        /**<Only front-facing triangles are drawn */
    rwCULLMODECULLFRONT,
        /**<Only back-facing triangles are drawn */
};

enum RwBlendFunction : u32
{
    rwBLENDNABLEND = 0,
    rwBLENDZERO,            /**<(0,    0,    0,    0   ) */
    rwBLENDONE,             /**<(1,    1,    1,    1   ) */
    rwBLENDSRCCOLOR,        /**<(Rs,   Gs,   Bs,   As  ) */
    rwBLENDINVSRCCOLOR,     /**<(1-Rs, 1-Gs, 1-Bs, 1-As) */
    rwBLENDSRCALPHA,        /**<(As,   As,   As,   As  ) */
    rwBLENDINVSRCALPHA,     /**<(1-As, 1-As, 1-As, 1-As) */
    rwBLENDDESTALPHA,       /**<(Ad,   Ad,   Ad,   Ad  ) */
    rwBLENDINVDESTALPHA,    /**<(1-Ad, 1-Ad, 1-Ad, 1-Ad) */
    rwBLENDDESTCOLOR,       /**<(Rd,   Gd,   Bd,   Ad  ) */
    rwBLENDINVDESTCOLOR,    /**<(1-Rd, 1-Gd, 1-Bd, 1-Ad) */
    rwBLENDSRCALPHASAT,     /**<(f,    f,    f,    1   )  f = min (As, 1-Ad) */
};

enum RwTextureAddressMode : u32
{
    rwTEXTUREADDRESSNATEXTUREADDRESS = 0,
    rwTEXTUREADDRESSWRAP,      /**<UV wraps (tiles) */
    rwTEXTUREADDRESSMIRROR,    /**<Alternate UV is flipped */
    rwTEXTUREADDRESSCLAMP,     /**<UV is clamped to 0-1 */
    rwTEXTUREADDRESSBORDER,    /**<Border color takes effect outside of 0-1 */
};

enum RwTextureFilterMode : u32
{
    rwFILTERNAFILTERMODE = 0,
    rwFILTERNEAREST,                /**<Point sampled */
    rwFILTERLINEAR,                 /**<Bilinear */
    rwFILTERMIPNEAREST,             /**<Point sampled per pixel mip map */
    rwFILTERMIPLINEAR,              /**<Bilinear per pixel mipmap */
    rwFILTERLINEARMIPNEAREST,       /**<MipMap interp point sampled */
    rwFILTERLINEARMIPLINEAR,        /**<Trilinear */
};

enum RwAlphaTestFunction : u32
{
    rwALPHATESTFUNCTIONNAALPHATESTFUNCTION = 0,

    rwALPHATESTFUNCTIONNEVER,         
        /**<Always fail the test */
    rwALPHATESTFUNCTIONLESS,          
        /**<Accept the new pixel if its alpha value is less than the value of
         *  the reference value */
    rwALPHATESTFUNCTIONEQUAL,         
        /**<Accept the new pixel if its alpha value equals the value of the
         *  reference value */
    rwALPHATESTFUNCTIONLESSEQUAL,     
        /**<Accept the new pixel if its alpha value is less than or equal to 
         *  the value of the reference value */
    rwALPHATESTFUNCTIONGREATER,       
        /**<Accept the new pixel if its alpha value is greater than the value 
         *  of the reference value */
    rwALPHATESTFUNCTIONNOTEQUAL,      
        /**<Accept the new pixel if its alpha value does not equal the value of 
         *  the reference value */
    rwALPHATESTFUNCTIONGREATEREQUAL,  
        /**<Accept the new pixel if its alpha value is greater than or equal
         *  to the value of the reference value */
    rwALPHATESTFUNCTIONALWAYS,        
        /**<Always pass the test */
};

DECL_FASTCALL_SIMPLE_GLO(RwRenderStateSet, _Z16RwRenderStateSet13RwRenderStatePv, RwBool, RwRenderState state, void* value);
DECL_FASTCALL_SIMPLE_GLO(RwRenderStateGet, _Z16RwRenderStateGet13RwRenderStatePv, RwBool, RwRenderState state, void* value);

DECL_FASTCALL_SIMPLE_GLO(RwIm2DGetNearScreenZ, _Z20RwIm2DGetNearScreenZv, RwReal);
DECL_FASTCALL_SIMPLE_GLO(RwIm2DGetFarScreenZ, _Z19RwIm2DGetFarScreenZv, RwReal);
DECL_FASTCALL_SIMPLE_GLO(RwIm2DRenderLine, _Z16RwIm2DRenderLineP14RwOpenGLVertexiii, RwBool, RwIm2DVertex *verts, i32 vertsNum, i32 vert1, i32 vert2);
DECL_FASTCALL_SIMPLE_GLO(RwIm2DRenderTriangle, _Z20RwIm2DRenderTriangleP14RwOpenGLVertexiiii, RwBool, RwIm2DVertex *verts, i32 vertsNum, i32 vert1, i32 vert2, i32 vert3);
DECL_FASTCALL_SIMPLE_GLO(RwIm2DRenderPrimitive, _Z21RwIm2DRenderPrimitive15RwPrimitiveTypeP14RwOpenGLVertexi, RwBool, i32 primtype, RwIm2DVertex *verts, i32 vertsNum);
DECL_FASTCALL_SIMPLE_GLO(RwIm2DRenderIndexedPrimitive, _Z28RwIm2DRenderIndexedPrimitive15RwPrimitiveTypeP14RwOpenGLVertexiPti, RwBool, i32 primtype, RwIm2DVertex *verts, i32 vertsNum, RwImVertexIndex* indices, i32 indicesNum);

DECL_FASTCALL_SIMPLE_GLO(RwIm3DTransform, _Z15RwIm3DTransformP18RxObjSpace3DVertexjP11RwMatrixTagj, void*, RwIm3DVertex* verts, RwUInt32 vertsNum, RwMatrix* ltm, RwUInt32 flags);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DEnd, _Z9RwIm3DEndv, RwBool);

enum RwIm3DTransformFlags : RwInt32
{
    rwIM3D_VERTEXUV = 1,
    rwIM3D_ALLOPAQUE = 2,
    rwIM3D_NOCLIP = 4,
    rwIM3D_VERTEXXYZ = 8,
    rwIM3D_VERTEXRGBA = 16,
    rwIM3DTRANSFORMFLAGSFORCEENUMSIZEINT = 2147483647,
};

DECL_FASTCALL_SIMPLE_GLO(RwIm3DGetTransformPipeline, _Z26RwIm3DGetTransformPipelinev, RxPipeline*);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DGetRenderPipeline, _Z23RwIm3DGetRenderPipeline15RwPrimitiveType, RxPipeline*, RwPrimitiveType primType);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DRenderTriangle, _Z20RwIm3DRenderTriangleiii, RwBool, RwInt32 vert1, RwInt32 vert2, RwInt32 vert3);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DRenderPrimitive, _Z21RwIm3DRenderPrimitive15RwPrimitiveType, RwBool, RwPrimitiveType primType);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DRenderIndexedPrimitive, _Z28RwIm3DRenderIndexedPrimitive15RwPrimitiveTypePti, RwBool, RwPrimitiveType primType, RwImVertexIndex* indices, RwInt32 numIndices);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DSetTransformPipeline, _Z26RwIm3DSetTransformPipelineP10RxPipeline, RxPipeline*, RxPipeline* pipeline);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DSetRenderPipeline, _Z23RwIm3DSetRenderPipelineP10RxPipeline15RwPrimitiveType, RxPipeline*, RxPipeline* pipeline, RwPrimitiveType primType);
DECL_FASTCALL_SIMPLE_GLO(RwIm3DRenderLine, _Z16RwIm3DRenderLineii, RwBool, RwInt32 vert1, RwInt32 vert2);

DECL_FASTCALL_SIMPLE_GLO(RwOpenGLSetStencilClear, _Z23RwOpenGLSetStencilClearj, void, RwUInt32 value);
DECL_FASTCALL_SIMPLE_GLO(RwOpenGLGetStencilClear, _Z23RwOpenGLGetStencilClearv, RwUInt32);

#ifdef GTAVC
inline void RwIm2DVertexSetScreenX(RwIm2DVertex* vertex, RwReal value) { vertex->x = value; }
inline void RwIm2DVertexSetScreenY(RwIm2DVertex* vertex, RwReal value) { vertex->y = value; }
inline void RwIm2DVertexSetScreenZ(RwIm2DVertex* vertex, RwReal value) { vertex->z = value; }
inline RwReal RwIm2DVertexGetScreenX(RwIm2DVertex const* vertex) { return vertex->x; }
inline RwReal RwIm2DVertexGetScreenY(RwIm2DVertex const* vertex) { return vertex->y; }
inline RwReal RwIm2DVertexGetScreenZ(RwIm2DVertex const* vertex) { return vertex->z; }
inline void RwIm2DVertexSetRecipCameraZ(RwIm2DVertex* vertex, RwReal value) { vertex->rhw = value; }
inline RwReal RwIm2DVertexGetRecipCameraZ(RwIm2DVertex const* vertex) { return vertex->rhw; }

inline void RwIm2DVertexSetU(RwIm2DVertex* vertex, RwReal u, RwReal recipZ)
{
    vertex->u = u * recipZ;
    vertex->w = 0.0f;
    vertex->q = recipZ;
}
inline void RwIm2DVertexSetV(RwIm2DVertex* vertex, RwReal v, RwReal recipZ)
{
    vertex->v = v * recipZ;
    vertex->w = 0.0f;
    vertex->q = recipZ;
}
inline void RwIm2DVertexSetIntRGBA(RwIm2DVertex* vertex, RwUInt32 red, RwUInt32 green, RwUInt32 blue, RwUInt32 alpha)
{
    vertex->color.Set((RwUInt8)red, (RwUInt8)green, (RwUInt8)blue, (RwUInt8)alpha);
}
inline void RwIm2DVertexSetRealRGBA(RwIm2DVertex* vertex, RwReal red, RwReal green, RwReal blue, RwReal alpha)
{
    RwIm2DVertexSetIntRGBA(vertex, (RwUInt32)red, (RwUInt32)green, (RwUInt32)blue, (RwUInt32)alpha);
}
inline RwUInt32 RwIm2DVertexGetRed(RwIm2DVertex const* vertex) { return vertex->r; }
inline RwUInt32 RwIm2DVertexGetGreen(RwIm2DVertex const* vertex) { return vertex->g; }
inline RwUInt32 RwIm2DVertexGetBlue(RwIm2DVertex const* vertex) { return vertex->b; }
inline RwUInt32 RwIm2DVertexGetAlpha(RwIm2DVertex const* vertex) { return vertex->a; }

inline void RwIm3DVertexSetPos(RwIm3DVertex* vertex, RwReal x, RwReal y, RwReal z) { vertex->objVertex.Set(x, y, z); }
inline void RwIm3DVertexSetNormal(RwIm3DVertex* vertex, RwReal x, RwReal y, RwReal z) { vertex->normal.Set(x, y, z); }
inline RwV3d* RwIm3DVertexGetPos(RwIm3DVertex* vertex) { return &vertex->objVertex; }
inline RwV3d const* RwIm3DVertexGetPos(RwIm3DVertex const* vertex) { return &vertex->objVertex; }
inline RwV3d* RwIm3DVertexGetNormal(RwIm3DVertex* vertex) { return &vertex->normal; }
inline RwV3d const* RwIm3DVertexGetNormal(RwIm3DVertex const* vertex) { return &vertex->normal; }
inline void RwIm3DVertexSetU(RwIm3DVertex* vertex, RwReal u) { vertex->u = u; }
inline void RwIm3DVertexSetV(RwIm3DVertex* vertex, RwReal v) { vertex->v = v; }
inline RwReal RwIm3DVertexGetU(RwIm3DVertex const* vertex) { return vertex->u; }
inline RwReal RwIm3DVertexGetV(RwIm3DVertex const* vertex) { return vertex->v; }
inline void RwIm3DVertexSetRGBA(RwIm3DVertex* vertex, RwUInt32 red, RwUInt32 green, RwUInt32 blue, RwUInt32 alpha)
{
    vertex->color.Set((RwUInt8)red, (RwUInt8)green, (RwUInt8)blue, (RwUInt8)alpha);
}
inline RwUInt32 RwIm3DVertexGetRed(RwIm3DVertex const* vertex) { return vertex->r; }
inline RwUInt32 RwIm3DVertexGetGreen(RwIm3DVertex const* vertex) { return vertex->g; }
inline RwUInt32 RwIm3DVertexGetBlue(RwIm3DVertex const* vertex) { return vertex->b; }
inline RwUInt32 RwIm3DVertexGetAlpha(RwIm3DVertex const* vertex) { return vertex->a; }
inline void RwIm3DVertexCopyRGBA(RwIm3DVertex* dest, RwIm3DVertex const* source) { dest->emissiveColor = source->emissiveColor; }
#endif

enum RxRenderStateFlag : RwInt32
{
    rxRENDERSTATEFLAG_TEXTUREPERSPECTIVE = 1,
    rxRENDERSTATEFLAG_ZTESTENABLE = 2,
    rxRENDERSTATEFLAG_ZWRITEENABLE = 4,
    rxRENDERSTATEFLAG_VERTEXALPHAENABLE = 8,
    rxRENDERSTATEFLAG_FOGENABLE = 16,
    rxRENDERSTATEFLAGFORCEENUMSIZEINT = 2147483647,
};

enum RwFogType : RwInt32
{
    rwFOGTYPENAFOGTYPE = 0,
    rwFOGTYPELINEAR = 1,
    rwFOGTYPEEXPONENTIAL = 2,
    rwFOGTYPEEXPONENTIAL2 = 3,
    rwFOGTYPEFORCEENUMSIZEINT = 2147483647,
};

struct RxRenderStateVector
{
    RwUInt32 Flags;
    RwShadeMode ShadeMode;
    RwBlendFunction SrcBlend;
    RwBlendFunction DestBlend;
    RwRaster* TextureRaster;
    RwTextureAddressMode AddressModeU;
    RwTextureAddressMode AddressModeV;
    RwTextureFilterMode FilterMode;
    RwRGBA BorderColor;
    RwFogType FogType;
    RwRGBA FogColor;
};
CHECKSIZE(RxRenderStateVector, 0x2C, 0x30);

DECL_FASTCALL_SIMPLE_GLO(RxRenderStateVectorCreate, _Z25RxRenderStateVectorCreatei, RxRenderStateVector*, RwBool current);
DECL_FASTCALL_SIMPLE_GLO(RxRenderStateVectorSetDefaultRenderStateVector, _Z46RxRenderStateVectorSetDefaultRenderStateVectorP19RxRenderStateVector, RxRenderStateVector*, RxRenderStateVector* rsvp);
DECL_FASTCALL_SIMPLE_GLO(RxRenderStateVectorGetDefaultRenderStateVector, _Z46RxRenderStateVectorGetDefaultRenderStateVectorv, RxRenderStateVector const*);
DECL_FASTCALL_SIMPLE_GLO(RxRenderStateVectorDestroy, _Z26RxRenderStateVectorDestroyP19RxRenderStateVector, void, RxRenderStateVector* rsvp);
DECL_FASTCALL_SIMPLE_GLO(RxRenderStateVectorLoadDriverState, _Z34RxRenderStateVectorLoadDriverStateP19RxRenderStateVector, RxRenderStateVector*, RxRenderStateVector* rsvp);

#endif // __AML_PSDK_RWIM2D_H

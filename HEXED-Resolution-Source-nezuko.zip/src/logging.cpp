/*
 * HEXED Resolution — diagnostic logging implementation.
 * Project-owned code (see LICENSES.md).
 */
#include "logging.h"

#include <android/log.h>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>
#include <vector>

#include <mod/logger.h>

namespace hxlog
{
    namespace
    {
        const size_t kMaxLine = 512;
        const size_t kRingLines = 64;
        const long   kMaxFileBytes = 512 * 1024;   /* rotate beyond this */

        std::mutex   g_mutex;
        FILE*        g_file = NULL;
        std::string  g_path;
        bool         g_verbose = false;

        struct Ring
        {
            std::vector<std::string> lines;
            size_t next = 0;
            size_t count = 0;
        } g_ring;

        void PushRing(const char* line)
        {
            if(g_ring.lines.empty()) g_ring.lines.resize(kRingLines);
            g_ring.lines[g_ring.next] = line;
            g_ring.next = (g_ring.next + 1) % kRingLines;
            if(g_ring.count < kRingLines) ++g_ring.count;
        }

        void Emit(char prio, const char* fmt, va_list args)
        {
            char line[kMaxLine];
            vsnprintf(line, sizeof(line), fmt, args);

            /* logcat through the AML logger (tagged, consistent with AML). */
            if(logger)
            {
                eLogPrio p = LogP_Info;
                if(prio == 'V') p = LogP_Verbose;
                else if(prio == 'W') p = LogP_Warn;
                else if(prio == 'E') p = LogP_Error;
                logger->Print(p, "%s", line);
            }

            std::lock_guard<std::mutex> lock(g_mutex);
            PushRing(line);
            if(g_file)
            {
                time_t now = time(NULL);
                char stamp[32];
                strftime(stamp, sizeof(stamp), "%m-%d %H:%M:%S", localtime(&now));
                fprintf(g_file, "[%s] %c/%s\n", stamp, prio, line);
                fflush(g_file);

                if(ftell(g_file) > kMaxFileBytes)
                {
                    fclose(g_file);
                    g_file = NULL;
                    std::string rotated = g_path + ".old";
                    remove(rotated.c_str());
                    rename(g_path.c_str(), rotated.c_str());
                    g_file = fopen(g_path.c_str(), "a");
                }
            }
        }
    }

    bool Init(const char* androidDataPath, bool verbose)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_verbose = verbose;
        if(g_file) return true;
        if(!androidDataPath || !androidDataPath[0]) return false;

        g_path = std::string(androidDataPath) + "/hexed/hexed_resolution.log";
        g_file = fopen(g_path.c_str(), "a");
        if(g_file)
        {
            fprintf(g_file, "---- HEXED Resolution session ----\n");
            fflush(g_file);
        }
        return (g_file != NULL);
    }

    void Shutdown()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        if(g_file) { fclose(g_file); g_file = NULL; }
    }

    void SetVerbose(bool verbose)
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_verbose = verbose;
    }

    bool IsVerbose()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_verbose;
    }

    void V(const char* fmt, ...)
    {
        if(!IsVerbose()) return;
        va_list a; va_start(a, fmt);
        Emit('V', fmt, a);
        va_end(a);
    }

    void I(const char* fmt, ...)
    {
        va_list a; va_start(a, fmt);
        Emit('I', fmt, a);
        va_end(a);
    }

    void W(const char* fmt, ...)
    {
        va_list a; va_start(a, fmt);
        Emit('W', fmt, a);
        va_end(a);
    }

    void E(const char* fmt, ...)
    {
        va_list a; va_start(a, fmt);
        Emit('E', fmt, a);
        va_end(a);
    }

    int RecentLines(char* out, size_t outLen, int maxLines)
    {
        if(!out || outLen == 0) return 0;
        std::lock_guard<std::mutex> lock(g_mutex);
        size_t used = 0;
        int copied = 0;
        size_t total = g_ring.count;
        size_t start = (g_ring.next + kRingLines - total) % kRingLines;
        int first = (int)total - (maxLines > 0 ? maxLines : 0);
        if(first < 0) first = 0;

        for(size_t i = (size_t)first; i < total && used + 2 < outLen; ++i)
        {
            const std::string& s = g_ring.lines[(start + i) % kRingLines];
            size_t n = s.size();
            if(n > outLen - used - 2) n = outLen - used - 2;
            memcpy(out + used, s.c_str(), n);
            used += n;
            out[used++] = '\n';
            ++copied;
        }
        out[used] = '\0';
        return copied;
    }

    const char* FilePath()
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        return g_path.c_str();
    }
}

/*
 * HEXED Resolution — resolution request orchestration implementation.
 * Project-owned code (see LICENSES.md).
 */
#include "resolution_api.h"

#include <cstdio>
#include <cstring>
#include <mutex>

#include <mod/amlmod.h>
#include <mod/logger.h>

#include "config.h"
#include "logging.h"

namespace hxres
{
    static std::mutex g_apiMutex;

    ResolutionAPI& ResolutionAPI::Get()
    {
        static ResolutionAPI inst;
        return inst;
    }

    ResolutionAPI::ResolutionAPI()
        : m_rwState(RW_NOT_READY)
        , m_enabled(false)
        , m_restoreAtStartup(false)
        , m_watchdog(true)
        , m_allowNativeApply(false)
        , m_pendingValid(false)
        , m_pendingW(0), m_pendingH(0), m_pendingPreset(PRESET_NONE)
        , m_pendingReset(false)
        , m_activeValid(false)
        , m_activeW(0), m_activeH(0), m_activePreset(PRESET_NONE)
        , m_frameCounter(0), m_lastDriftFrame(-100000)
    {
        memset(&m_lastResult, 0, sizeof(m_lastResult));
    }

    void ResolutionAPI::Init(bool enabled, bool restoreAtStartup, bool watchdog,
                             bool allowNativeApply)
    {
        std::lock_guard<std::mutex> lock(g_apiMutex);
        m_enabled = enabled;
        m_restoreAtStartup = restoreAtStartup;
        m_watchdog = watchdog;
        m_allowNativeApply = allowNativeApply;
    }

    void ResolutionAPI::Shutdown(bool tryRestore)
    {
        std::lock_guard<std::mutex> lock(g_apiMutex);
        if(tryRestore && m_activeValid)
        {
            ApplyResult r = RenderBackend::Get().Reset();
            if(r.code == APPLY_OK)
            {
                m_activeValid = false;
                hxlog::I("shutdown: %s", r.message);
            }
        }
    }

    void ResolutionAPI::LastResult(RequestResult& out) const
    {
        std::lock_guard<std::mutex> lock(g_apiMutex);
        out = m_lastResult;
    }

    static void StoreResult(RequestResult& slot, ApplyCode code,
                            int w, int h, const char* text)
    {
        slot.code = code;
        slot.width = w;
        slot.height = h;
        snprintf(slot.message, sizeof(slot.message), "%s", text ? text : "");
    }

    RequestResult ResolutionAPI::Apply(int w, int h, int preset)
    {
        RequestResult r;
        char reason[96] = "";

        if(!ValidateDimensions(w, h, reason, sizeof(reason)))
        {
            StoreResult(r, APPLY_INVALID, 0, 0, reason);
        }
        else if(!m_enabled)
        {
            StoreResult(r, APPLY_DISABLED, 0, 0,
                        "HEXED Resolution is disabled (enable it first)");
        }
        else if(RenderBackend::Get().Compat() != COMPAT_OK)
        {
            StoreResult(r, APPLY_UNSUPPORTED, 0, 0, RenderBackend::Get().CompatReason());
        }
        else if(!m_allowNativeApply)
        {
            StoreResult(r, APPLY_DISABLED, 0, 0,
                        "AllowNativeApply=false in HexedResolution.ini "
                        "(set it to true to permit game-memory writes)");
        }
        else
        {
            /* Defer the write to the game thread (FrameTick) so that no game
             * memory is touched from the bridge worker thread. */
            std::lock_guard<std::mutex> lock(g_apiMutex);
            m_pendingValid = true;
            m_pendingW = w;
            m_pendingH = h;
            m_pendingPreset = preset;
            StoreResult(r, APPLY_QUEUED, w, h,
                        "request accepted; will be written on the next game frame");
        }

        std::lock_guard<std::mutex> lock(g_apiMutex);
        m_lastResult = r;
        hxlog::I("api apply %dx%d -> code %d: %s", w, h, (int)r.code, r.message);
        return r;
    }

    RequestResult ResolutionAPI::Reset()
    {
        /* Restoring the original values is a SAFETY action: it is allowed even
         * when the master switch is off, and it is executed on the game thread
         * (FrameTick) like every other game-memory write. */
        RequestResult r;
        if(RenderBackend::Get().Compat() != COMPAT_OK)
        {
            StoreResult(r, APPLY_UNSUPPORTED, 0, 0, RenderBackend::Get().CompatReason());
        }
        else
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            m_pendingValid = false;
            m_pendingReset = true;
            StoreResult(r, APPLY_QUEUED, 0, 0, "reset accepted; original resolution is restored on the next game frame");
        }
        std::lock_guard<std::mutex> lock(g_apiMutex);
        m_lastResult = r;
        hxlog::I("api reset -> code %d: %s", (int)r.code, r.message);
        return r;
    }

    RequestResult ResolutionAPI::Enable(bool enabled)
    {
        RequestResult r;
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            m_enabled = enabled;
            if(!enabled) m_pendingValid = false;
            StoreResult(r, APPLY_OK, 0, 0,
                        enabled ? "HEXED Resolution enabled" : "HEXED Resolution disabled");
        }
        hxlog::I("api enable %d", (int)enabled);
        return r;
    }

    RequestResult ResolutionAPI::AllowNativeApply(bool allow)
    {
        RequestResult r;
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            m_allowNativeApply = allow;
            if(!allow) m_pendingValid = false;
        }
        HexedConfig c;
        LoadConfig(c);
        c.allowNativeApply = allow;
        SaveConfig(c);
        StoreResult(r, APPLY_OK, 0, 0, allow ? "native apply allowed (saved to HexedResolution.ini)"
                                              : "native apply blocked (saved to HexedResolution.ini)");
        hxlog::I("api allow %d", (int)allow);
        std::lock_guard<std::mutex> lock(g_apiMutex);
        m_lastResult = r;
        return r;
    }

    RequestResult ResolutionAPI::SaveSelection(int w, int h, int preset)
    {
        RequestResult r;
        char reason[96] = "";
        HexedConfig c;

        if(preset == PRESET_CUSTOM && !ValidateDimensions(w, h, reason, sizeof(reason)))
        {
            StoreResult(r, APPLY_INVALID, 0, 0, reason);
            std::lock_guard<std::mutex> lock(g_apiMutex);
            m_lastResult = r;
            return r;
        }

        LoadConfig(c);
        c.preset = preset;
        if(preset == PRESET_CUSTOM) { c.customWidth = w; c.customHeight = h; }
        SaveConfig(c);

        StoreResult(r, APPLY_OK, w, h, "selection saved to HexedResolution.ini");
        hxlog::I("api save preset=%s %dx%d", PresetName(preset), w, h);
        return r;
    }

    RequestResult ResolutionAPI::RestoreSelection()
    {
        RequestResult r;
        HexedConfig c;
        LoadConfig(c);

        int w = 0, h = 0;
        if(!ResolvePreset(c, w, h))
        {
            StoreResult(r, APPLY_INVALID, 0, 0, "no valid saved selection to restore");
        }
        else
        {
            r = Apply(w, h, c.preset);   /* records last result itself */
            return r;
        }
        std::lock_guard<std::mutex> lock(g_apiMutex);
        m_lastResult = r;
        return r;
    }

    void ResolutionAPI::NoteApplied(int w, int h, int preset)
    {
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            m_activeValid = true;
            m_activeW = w;
            m_activeH = h;
            m_activePreset = preset;
        }
        HexedConfig c;
        LoadConfig(c);
        c.lastAppliedWidth = w;
        c.lastAppliedHeight = h;
        c.lastAppliedPreset = preset;
        SaveConfig(c);
        hxlog::I("applied state recorded: %dx%d (%s)", w, h, PresetName(preset));
    }

    void ResolutionAPI::PerformQueuedApply()
    {
        bool doReset = false;
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            doReset = m_pendingReset;
            m_pendingReset = false;
        }
        if(doReset && RenderBackend::Get().Compat() == COMPAT_OK)
        {
            ApplyResult br = RenderBackend::Get().Reset();
            std::lock_guard<std::mutex> lock(g_apiMutex);
            if(br.code == APPLY_OK) m_activeValid = false;
            StoreResult(m_lastResult, br.code, br.width, br.height, br.message);
        }

        int w = 0, h = 0, preset = PRESET_NONE;
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            if(!m_pendingValid) return;
            w = m_pendingW; h = m_pendingH; preset = m_pendingPreset;
            m_pendingValid = false;
        }

        if(!m_enabled || !m_allowNativeApply) return;
        if(RenderBackend::Get().Compat() != COMPAT_OK) return;

        ApplyResult br = RenderBackend::Get().Apply(w, h);
        if(br.code == APPLY_OK)
        {
            NoteApplied(br.width, br.height, preset);
            {
                std::lock_guard<std::mutex> lock(g_apiMutex);
                StoreResult(m_lastResult, APPLY_OK, br.width, br.height, br.message);
            }
            if(aml) aml->ShowToast(false, "HEXED: %dx%d applied", br.width, br.height);
        }
        else
        {
            std::lock_guard<std::mutex> lock(g_apiMutex);
            StoreResult(m_lastResult, br.code, 0, 0, br.message);
        }
    }

    void ResolutionAPI::OnInitRenderWareBefore()
    {
        m_rwState = RW_NOT_READY;   /* renderer is being (re)initialized */
        RenderBackend::Get().Recheck();

        /* Safe point: RenderWare is about to create camera rasters. If the
         * user asked for a restore-at-startup and nothing is queued, queue
         * the persisted selection now — before the game reads RsGlobal. */
        if(m_enabled && m_restoreAtStartup && !m_pendingValid && !m_activeValid)
        {
            HexedConfig c;
            LoadConfig(c);
            int w = 0, h = 0;
            if(ResolvePreset(c, w, h))
            {
                m_pendingValid = true;
                m_pendingW = w;
                m_pendingH = h;
                m_pendingPreset = c.preset;
                hxlog::I("rw-init: queued restore of saved selection %dx%d (%s)",
                         w, h, PresetName(c.preset));
            }
        }

        PerformQueuedApply();
    }

    void ResolutionAPI::OnInitRenderWareAfter()
    {
        m_rwState = RW_READY;
        RenderBackend::Get().Recheck();

        RenderProbe p;
        RenderBackend::Get().Probe(p);
        hxlog::I("rw-ready: RsGlobal %dx%d | EGL %dx%d | viewport %dx%d",
                 p.rsValid ? p.rsWidth : -1, p.rsValid ? p.rsHeight : -1,
                 p.eglValid ? p.eglWidth : -1, p.eglValid ? p.eglHeight : -1,
                 p.glValid ? p.glViewport[2] : -1, p.glValid ? p.glViewport[3] : -1);
    }

    void ResolutionAPI::OnShutdownRenderWare()
    {
        m_rwState = RW_TERMINATED;
        hxlog::I("rw-terminated");
    }

    void ResolutionAPI::FrameTick()
    {
        ++m_frameCounter;

        if(RenderBackend::Get().Compat() == COMPAT_PENDING)
            RenderBackend::Get().Recheck();      /* 2 int reads until it flips */

        PerformQueuedApply();   /* executes any bridge-requested apply on the game thread */

        /* Watchdog: re-assert the applied values if the game overwrote them
         * (e.g. after surface recreation). Cheap: two int reads, rate-limited. */
        if(m_watchdog && m_activeValid &&
           (m_frameCounter - m_lastDriftFrame) > 300)
        {
            if(RenderBackend::Get().Drifted())
            {
                m_lastDriftFrame = m_frameCounter;
                ApplyResult br = RenderBackend::Get().Apply(m_activeW, m_activeH);
                if(br.code == APPLY_OK)
                    hxlog::W("watchdog: RsGlobal drifted, re-applied %dx%d", m_activeW, m_activeH);
                else
                    hxlog::E("watchdog: re-apply failed: %s", br.message);
            }
        }

        SampleDiagnostics();
    }

    void ResolutionAPI::SampleDiagnostics()
    {
        if(!hxlog::IsVerbose()) return;
        if((m_frameCounter % 300) != 0) return;   /* ~every 5 s at 60 fps */

        RenderProbe p;
        RenderBackend::Get().Probe(p);
        hxlog::V("diag: RsGlobal %dx%d | EGL %dx%d | vp %dx%d | applied=%d",
                 p.rsValid ? p.rsWidth : -1, p.rsValid ? p.rsHeight : -1,
                 p.eglValid ? p.eglWidth : -1, p.eglValid ? p.eglHeight : -1,
                 p.glValid ? p.glViewport[2] : -1, p.glValid ? p.glViewport[3] : -1,
                 (int)m_activeValid);
    }

    int ResolutionAPI::BuildStatusLine(char* out, int outLen)
    {
        RenderProbe p;
        RenderBackend::Get().Probe(p);
        const char* state =
            (m_rwState == RW_READY) ? "renderer ready" :
            (m_rwState == RW_TERMINATED) ? "renderer terminated" : "renderer not ready";

        return snprintf(out, outLen,
            "%s | RsGlobal %dx%d | surface %dx%d | vp %dx%d | applied %s | %s",
            m_enabled ? "enabled" : "disabled",
            p.rsValid ? p.rsWidth : -1, p.rsValid ? p.rsHeight : -1,
            p.eglValid ? p.eglWidth : -1, p.eglValid ? p.eglHeight : -1,
            p.glValid ? p.glViewport[2] : -1, p.glValid ? p.glViewport[3] : -1,
            m_activeValid ? "yes" : "no",
            state);
    }

    int ResolutionAPI::BuildInfoLine(char* out, int outLen)
    {
        RenderBackend& b = RenderBackend::Get();
        return snprintf(out, outLen,
            "compat=%s (%s) | enabled=%d allowNativeApply=%d | applied=%d",
            b.Compat() == COMPAT_OK ? "OK" : "UNSUPPORTED", b.CompatReason(),
            (int)m_enabled, (int)m_allowNativeApply, (int)m_activeValid);
    }
}

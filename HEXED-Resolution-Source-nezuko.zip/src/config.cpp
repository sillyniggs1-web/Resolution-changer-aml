/*
 * HEXED Resolution — configuration implementation.
 * Persistence: AML Config (HexedResolution.ini). Validation: this file.
 * Project-owned code (see LICENSES.md).
 */
#include "config.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>

#include <mod/amlmod.h>
#include <mod/config.h>
#include <mod/logger.h>

#include "logging.h"

namespace hxres
{
    /* AML's Config object is not thread-safe; every cfg access in the
     * project goes through this module, so one mutex serializes it. */
    static std::mutex g_cfgMutex;

    static const char* kSecHexed   = "hexed";
    static const char* kSecPresets = "presets";
    static const char* kSecApplied = "applied";
    static const char* kSecBackend = "backend";

    static void PutInt(const char* sec, const char* key, int def, int lo, int hi, int& out)
    {
        ConfigEntry* e = cfg->Bind(key, def, sec);
        if(e)
        {
            e->Clamp(lo, hi);
            out = e->GetInt();
            delete e;
        }
    }

    static void PutInt64Hex(const char* sec, const char* key, int64_t def, int64_t& out)
    {
        /* Offsets are stored as decimal or 0x-prefixed strings; the value is
         * only used when useCustomProfile=true. Anything unparsable or
         * negative falls back to 0 (unused). */
        char buf[40];
        cfg->GetString(buf, sizeof(buf), key, "", sec);
        if(!buf[0]) { out = def; return; }
        int64_t v = 0;
        if(buf[0] == '0' && (buf[1] == 'x' || buf[1] == 'X'))
            v = (int64_t)strtoull(buf + 2, NULL, 16);
        else
            v = (int64_t)strtoll(buf, NULL, 0);
        out = (v > 0) ? v : 0;
    }

    void LoadConfig(HexedConfig& c)
    {
        std::lock_guard<std::mutex> lock(g_cfgMutex);
        c.enabled           = cfg->GetBool("Enabled", false, kSecHexed);
        c.verboseLogging    = cfg->GetBool("VerboseLogging", false, kSecHexed);
        c.hudStatus         = cfg->GetBool("HudStatus", true, kSecHexed);
        c.restoreAtStartup  = cfg->GetBool("RestoreAtStartup", false, kSecHexed);
        c.watchdog          = cfg->GetBool("Watchdog", true, kSecHexed);

        PutInt(kSecPresets, "Preset", PRESET_NONE, 0, PRESET_COUNT - 1, c.preset);
        PutInt(kSecPresets, "CustomWidth", 0, 0, MAX_DIMENSION, c.customWidth);
        PutInt(kSecPresets, "CustomHeight", 0, 0, MAX_DIMENSION, c.customHeight);

        PutInt(kSecApplied, "LastAppliedWidth", 0, 0, MAX_DIMENSION, c.lastAppliedWidth);
        PutInt(kSecApplied, "LastAppliedHeight", 0, 0, MAX_DIMENSION, c.lastAppliedHeight);
        PutInt(kSecApplied, "LastAppliedPreset", PRESET_NONE, 0, PRESET_COUNT - 1, c.lastAppliedPreset);

        c.allowNativeApply  = cfg->GetBool("AllowNativeApply", false, kSecBackend);
        c.useCustomProfile  = cfg->GetBool("UseCustomProfile", false, kSecBackend);
        PutInt64Hex(kSecBackend, "RsGlobalPtrOffset32", 0, c.customRsGlobalPtrOffset32);
        PutInt64Hex(kSecBackend, "RsGlobalPtrOffset64", 0, c.customRsGlobalPtrOffset64);
    }

    void SaveConfig(const HexedConfig& c)
    {
        std::lock_guard<std::mutex> lock(g_cfgMutex);
        if(!cfg) return;
        ConfigEntry* e;

        e = cfg->Bind("Enabled", false, kSecHexed);          if(e) { e->SetBool(c.enabled); delete e; }
        e = cfg->Bind("VerboseLogging", false, kSecHexed);   if(e) { e->SetBool(c.verboseLogging); delete e; }
        e = cfg->Bind("HudStatus", true, kSecHexed);         if(e) { e->SetBool(c.hudStatus); delete e; }
        e = cfg->Bind("RestoreAtStartup", false, kSecHexed); if(e) { e->SetBool(c.restoreAtStartup); delete e; }
        e = cfg->Bind("Watchdog", true, kSecHexed);          if(e) { e->SetBool(c.watchdog); delete e; }

        e = cfg->Bind("Preset", PRESET_NONE, kSecPresets);   if(e) { e->SetInt(c.preset); delete e; }
        e = cfg->Bind("CustomWidth", 0, kSecPresets);        if(e) { e->SetInt(c.customWidth); delete e; }
        e = cfg->Bind("CustomHeight", 0, kSecPresets);       if(e) { e->SetInt(c.customHeight); delete e; }

        e = cfg->Bind("LastAppliedWidth", 0, kSecApplied);   if(e) { e->SetInt(c.lastAppliedWidth); delete e; }
        e = cfg->Bind("LastAppliedHeight", 0, kSecApplied);  if(e) { e->SetInt(c.lastAppliedHeight); delete e; }
        e = cfg->Bind("LastAppliedPreset", PRESET_NONE, kSecApplied); if(e) { e->SetInt(c.lastAppliedPreset); delete e; }

        e = cfg->Bind("AllowNativeApply", false, kSecBackend); if(e) { e->SetBool(c.allowNativeApply); delete e; }
        e = cfg->Bind("UseCustomProfile", false, kSecBackend); if(e) { e->SetBool(c.useCustomProfile); delete e; }

        char buf[40];
        snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)c.customRsGlobalPtrOffset32);
        e = cfg->Bind("RsGlobalPtrOffset32", "", kSecBackend); if(e) { e->SetString(buf); delete e; }
        snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)c.customRsGlobalPtrOffset64);
        e = cfg->Bind("RsGlobalPtrOffset64", "", kSecBackend); if(e) { e->SetString(buf); delete e; }

        cfg->Save();
    }

    void ResetConfig(HexedConfig& c)
    {
        std::lock_guard<std::mutex> lock(g_cfgMutex);
        c.enabled = false;
        c.verboseLogging = false;
        c.hudStatus = true;
        c.restoreAtStartup = false;
        c.watchdog = true;
        c.preset = PRESET_NONE;
        c.customWidth = 0;
        c.customHeight = 0;
        c.lastAppliedWidth = 0;
        c.lastAppliedHeight = 0;
        c.lastAppliedPreset = PRESET_NONE;
        c.allowNativeApply = false;
        c.useCustomProfile = false;
        c.customRsGlobalPtrOffset32 = 0;
        c.customRsGlobalPtrOffset64 = 0;
        SaveConfig(c);
    }

    const char* PresetName(int preset)
    {
        switch(preset)
        {
            case PRESET_1280x720: return "p720";
            case PRESET_960x540:  return "p540";
            case PRESET_800x450:  return "p450";
            case PRESET_CUSTOM:   return "custom";
            default:              return "none";
        }
    }

    bool ValidateDimensions(int w, int h, char* reason, int reasonLen)
    {
        if(w <= 0 || h <= 0)
            { if(reason) snprintf(reason, reasonLen, "dimensions must be positive"); return false; }

        if(w < MIN_DIMENSION || h < MIN_DIMENSION)
            { if(reason) snprintf(reason, reasonLen, "minimum dimension is %d", MIN_DIMENSION); return false; }

        /* int64 math: reject overflow-prone or absurd requests early. */
        int64_t pixels = (int64_t)w * (int64_t)h;
        if(w > MAX_DIMENSION || h > MAX_DIMENSION || pixels > (int64_t)MAX_DIMENSION * MAX_DIMENSION)
            { if(reason) snprintf(reason, reasonLen, "maximum dimension is %d", MAX_DIMENSION); return false; }

        double aspect = (double)h / (double)w;
        if(aspect < MIN_ASPECT || aspect > MAX_ASPECT)
            { if(reason) snprintf(reason, reasonLen, "aspect ratio %.2f outside supported range", aspect); return false; }

        if(reason) reason[0] = '\0';
        return true;
    }

    bool ResolvePreset(const HexedConfig& c, int& outW, int& outH)
    {
        switch(c.preset)
        {
            case PRESET_1280x720: outW = 1280; outH = 720; return true;
            case PRESET_960x540:  outW = 960;  outH = 540; return true;
            case PRESET_800x450:  outW = 800;  outH = 450; return true;
            case PRESET_CUSTOM:
                outW = c.customWidth; outH = c.customHeight;
                return ValidateDimensions(outW, outH, NULL, 0);
            default:
                return false;
        }
    }
}

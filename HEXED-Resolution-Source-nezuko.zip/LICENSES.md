# LICENSES.md

## Project code

The HEXED Resolution project-owned files are provided under the **MIT
License**:

> MIT License — Copyright (c) 2026 HEXED Resolution contributors
>
> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to
> deal in the Software without restriction, including without limitation the
> rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
> sell copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in
> all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
> FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
> IN THE SOFTWARE.

**Scope of the MIT grant (project-owned files):** `src/*.cpp`,
`include/*.h` (project interfaces), `lua/HexedResolution.lua`,
`config/HexedResolution.ini`, `Android.mk`, `Application.mk`,
`scripts/build.sh`, `.github/workflows/build.yml`, and the documentation.

## Vendored third-party components

### 1. AndroidModLoader mod headers — `mod/`

- Source: https://github.com/RusJJ/AndroidModLoader (`mod/` directory,
  including `mod/thirdparty/stb_sprintf.h` and `STB_LICENSE`).
- License: **MIT License**, Copyright (c) 2026 RusJJ. The upstream `LICENSE`
  file is reproduced in this repository as `mod/../../LICENSES.md` reference
  and the original header files carry no additional restrictions. The
  vendored `mod/thirdparty/stb_sprintf.h` is covered by its own permissive
  license, preserved in `mod/thirdparty/STB_LICENSE`.
- Used for: the AML mod declaration (`MYMODCFGNAME`), the `IAML` interface,
  logging and AML Config integration.

### 2. AML Plugin SDK headers — `aml-psdk/`

- Source: https://github.com/AndroidModLoader/aml-psdk (header tree).
- License: **GNU General Public License v3.0** — the upstream `LICENSE` is
  vendored verbatim at `aml-psdk/LICENSE`.
- Used for: the verified GTA:SA v2.00/v2.10 `RsGlobalType` definition and
  pinned pointer offsets (`game_sa/engine/RsGlobal.h`), the PSDK event system
  (`game_sa/Events.h`, `sdk_callevents.h`), and `CFont` HUD rendering
  (`game_sa/engine/Font.h`).
- **Consequence:** the native plugin component (`src/`, since it compiles
  against these GPL-3.0 headers) is distributed under GPL-3.0 as well; the
  MIT grant above applies to the non-native portions listed above. This
  split is documented here rather than silently relabeling GPL-licensed
  upstream material.

## Referenced (not vendored, not copied)

- **PixelsPub** — https://github.com/tribalfs/PixelsPub — audited during
  Phase 1 as the reference for what this project deliberately does NOT do:
  PixelsPub changes resolution via Android system mechanisms
  (`WRITE_SECURE_SETTINGS`, `adb shell wm size/density`, Shizuku), as its
  README documents. No PixelsPub code is used in HEXED Resolution; its
  documentation repository does not state a source-license for the app itself
  (the app is distributed via Google Play), so nothing was copied from it.
- **AndroidModLoader (AML)** — https://github.com/RusJJ/AndroidModLoader —
  the loader this plugin targets. Not included in this archive; users supply
  their own AML-enabled client.

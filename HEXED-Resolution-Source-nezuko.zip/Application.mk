# HEXED Resolution — NDK application settings.
# Matches the AndroidModLoader / aml-psdk build conventions.
#
# ABI: the SA-MP Nezuko 1.0.3 TESTING APK ships ONLY lib/armeabi-v7a/ (32-bit),
# and the 32-bit RsGlobal GOT slot (libGTASA+0x67910C) was verified against that
# exact libGTASA.so. The arm64 pin (0x850240) could not be verified, so arm64 is
# intentionally not built. To add it back, set: APP_ABI := armeabi-v7a arm64-v8a
APP_STL := c++_static
APP_ABI := armeabi-v7a
APP_OPTIM := release
APP_PLATFORM := android-21
NDK_TOOLCHAIN_VERSION := clang

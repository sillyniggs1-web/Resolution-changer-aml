#!/usr/bin/env bash
# HEXED Resolution — ndk-build wrapper (Linux / macOS / CI).
#
# Usage:
#   ./scripts/build.sh /path/to/android-ndk-r26d
# or set ANDROID_NDK_HOME / ANDROID_NDK_ROOT in the environment.
#
# Produces: build/libs/armeabi-v7a/libHexedResolution.so
#           (arm64 intentionally not built)
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

NDK_BIN="${1:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [ -z "$NDK_BIN" ]; then
    echo "ERROR: pass the NDK path: $0 /path/to/android-ndk-rXX" >&2
    exit 1
fi

if [ ! -d "$NDK_BIN" ]; then
    echo "ERROR: NDK directory not found: $NDK_BIN" >&2
    exit 1
fi

echo "[hexed] NDK      : $NDK_BIN"
echo "[hexed] project  : $PROJECT_ROOT"

# Sanity: required vendored headers must exist before compiling.
for f in \
    mod/amlmod.h mod/iaml.h mod/logger.h mod/config.h mod/logger.cpp mod/config.cpp \
    aml-psdk/sdk_base.h aml-psdk/game_sa/Events.h aml-psdk/game_sa/engine/RsGlobal.h \
    aml-psdk/game_sa/engine/Font.h ; do
    if [ ! -f "$PROJECT_ROOT/$f" ]; then
        echo "ERROR: required file missing: $f" >&2
        exit 2
    fi
done
echo "[hexed] vendored SDK headers verified"

"$NDK_BIN/build/ndk-build" \
    NDK_PROJECT_PATH="$PROJECT_ROOT" \
    APP_BUILD_SCRIPT="$PROJECT_ROOT/Android.mk" \
    NDK_APPLICATION_MK="$PROJECT_ROOT/Application.mk" \
    NDK_OUT="$PROJECT_ROOT/build/obj" \
    NDK_LIBS_OUT="$PROJECT_ROOT/build/libs" \
    NDK_DEBUG=0 \
    -j"$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)"

echo "[hexed] output:"
ls -l "$PROJECT_ROOT/build/libs"/*/ 2>/dev/null

# Fail loudly if no shared library was produced.
FOUND=$(find "$PROJECT_ROOT/build/libs" -name 'libHexedResolution*.so' 2>/dev/null | wc -l)
if [ "$FOUND" -lt 1 ]; then
    echo "ERROR: build produced no libHexedResolution*.so" >&2
    exit 3
fi
echo "[hexed] build OK"

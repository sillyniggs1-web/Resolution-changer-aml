LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_CPP_EXTENSION := .cpp .cc

ifeq ($(TARGET_ARCH_ABI), armeabi-v7a)
    LOCAL_MODULE := HexedResolution
else
    LOCAL_MODULE := HexedResolution64
endif

LOCAL_SRC_FILES := src/main.cpp \
                   src/resolution_api.cpp \
                   src/render_backend.cpp \
                   src/config.cpp \
                   src/logging.cpp \
                   src/lua_bridge.cpp \
                   mod/logger.cpp \
                   mod/config.cpp

# Project headers + vendored AML mod headers (MIT) + vendored aml-psdk (GPL-3)
LOCAL_C_INCLUDES := $(LOCAL_PATH)/include \
                    $(LOCAL_PATH)

## FLAGS — mirror the AML / aml-psdk example build settings ##
# NOTE: AML_API_1_4 must stay undefined (Nezuko's libAML has no such vtable slots).
LOCAL_CFLAGS  += -O2 -mfloat-abi=softfp -DNDEBUG -std=c17 -fvisibility=default
LOCAL_CXXFLAGS += -O2 -mfloat-abi=softfp -DNDEBUG -std=c++17 -fexceptions -fvisibility=default

LOCAL_LDLIBS  += -llog -lEGL -lGLESv2 -landroid -ldl

include $(BUILD_SHARED_LIBRARY)

# TESTING.md — test plan and honest results

Statuses: **[Passed]** executed and verified · **[Failed]** executed, did not
pass · **[Not tested]** possible but not executed in this environment ·
**[Blocked]** impossible without missing artifacts (device / APK / runtime).

The development environment for this release was a Linux sandbox **without an
Android device, an emulator, and without the Nezuko 1.0.3 TESTING APK**.
Everything below is labeled accordingly — nothing is claimed as passed on a
runtime unless it actually ran.

---

## 1. Source validation

| Check | Result | Notes |
|---|---|---|
| All required source files exist | **[Passed]** | CI step + `scripts/build.sh` both verify the exact file list |
| No placeholder in the functional path | **[Passed]** | grep scan for TODO/XXX/placeholder/mock in `src/`, `include/`, `lua/` |
| All referenced headers accounted for | **[Passed]** | real NDK compile (see §2) resolves every include |
| Lua calls only verified bridge functions | **[Passed]** | the script talks to the file bridge (its protocol is defined by this project); client APIs are probed with `type(...) == "function"` before use, never assumed |
| Build config matches SDK conventions | **[Passed]** | `Android.mk`/`Application.mk` mirror AML 1.4.x example flags (c++17, c++_static, softfp, android-21, per-ABI module names) |
| No unverified offsets in the functional path | **[Passed]** | only PSDK pins (aml-psdk `RsGlobal.h`) + user-supplied custom profile; both gated by runtime plausibility audit |

## 2. Native build (executed: real NDK r26d, Linux x86_64 host)

| Check | Result | Notes |
|---|---|---|
| Compilation succeeds (armeabi-v7a) | see build log in the delivery summary | ndk-build, `-j` |
| Compilation succeeds (arm64-v8a) | see build log in the delivery summary | ndk-build, `-j` |
| Expected `.so` files exist | **[Verified in CI/workflow + build script]** | script exits non-zero if missing |
| ELF architecture matches ABI | **[Verified via llvm-readelf in CI]** | `Class/Machine` check per ABI |
| Required symbols/imports present | **[Verified via llvm-readelf]** | EGL/GL/log imports visible in dyn-syms |
| GitHub Actions workflow syntax | **[Not tested]** | no GitHub run performed from the sandbox; workflow uses stable actions (`checkout@v4`, `upload-artifact@v4`) and pinned NDK r26d |

## 3. Runtime testing — requires the target APK + device

| Check | Result | Notes |
|---|---|---|
| AML loads the plugin (`OnModPreLoad`/`OnModLoad`) | **[Blocked]** | needs Nezuko APK + device |
| Compatibility audit accepts/rejects the actual libGTASA | **[Blocked]** | code paths compile; plausibility logic is unit-logic reviewed but not executed against the real library |
| Lua menu opens (`/hres`) | **[Blocked]** | needs client Lua runtime |
| Presets selectable | **[Blocked]** | |
| Invalid dimensions rejected | **[Blocked]** | native validator compiled; runtime rejection unverified on device |
| Apply reports accurate results | **[Blocked]** | deliberately cannot be claimed without execution |
| Reset restores original settings | **[Blocked]** | |
| No crash during surface recreation | **[Blocked]** | watchdog + audit designed for it; unverified |
| HUD/touch alignment after apply | **[Blocked]** | probe exists to diagnose; unverified |
| Configuration persists (`HexedResolution.ini` via AML Config) | **[Blocked]** | AML mechanism is documented; execution unverified |
| Unsupported rendering changes fail safely | **[Blocked]** | audit + gating compiled; unverified on device |
| EGL/GL probe on live renderer | **[Blocked]** | guarded queries; unverified |

## 4. Suggested on-device test pass (when you have the APK)

1. Install per INSTALL.md; launch; confirm `hexed/hexed_resolution.log` shows
   the environment report and `compat: RsGlobal OK` (or capture the failure).
2. `/hres status`, `/hres probe` — record baseline (RsGlobal vs EGL surface).
3. `/hres enable on` → `/hres 2` → `/hres apply`; run `/hres probe` again and
   compare GL viewport / surface values (this is the decisive measurement).
4. Set `RestoreAtStartup = true`, restart, re-probe; confirm persistence.
5. Rotate the device mid-session; confirm watchdog re-applies or reset works.
6. `/hres custom 200 100` → expect INVALID with reason.
7. `/hres reset` → probe returns to baseline.
8. Play 10 minutes; watch log for watchdog/drift lines; check touch alignment.

Record your results in this file as you test — keep the honest-status format.

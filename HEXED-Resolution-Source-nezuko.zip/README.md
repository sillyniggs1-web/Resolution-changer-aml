# HEXED Resolution

**A native Android Mod Loader (AML) plugin that changes the *internal rendering
resolution* of GTA San Andreas Android (SA-MP mobile clients such as Nezuko)
from inside the game — plus an in-game Lua menu that drives it.**

Version 1.0.0 · Target: AML 1.4.x · Games: GTA:SA Android v2.00 (armeabi-v7a)
and v2.10 (arm64-v8a) via the vendored aml-psdk profile · License: see
[LICENSES.md](LICENSES.md)

---

## What HEXED Resolution does

- Runs as an AML native mod (`libHexedResolution.so` / `libHexedResolution64.so`)
  inside the GTA:SA Android process.
- Reads the game's internal rendering dimensions from the RenderWare
  `RsGlobalType` object (`maximumWidth` / `maximumHeight`) — the same fields the
  AML Plugin SDK's own `ScreenUtils` uses as the HUD/render coordinate space.
- On request (Lua menu → bridge → native), validates and writes new dimensions
  through AML's documented memory primitives, captures the original values for
  restoration, and applies at the safe `initRwEvent` lifecycle point (before
  RenderWare creates camera rasters) so a full internal-resolution change takes
  effect.
- Provides honest runtime diagnostics: EGL window-surface size, GL viewport and
  RsGlobal values are probed and logged so you can *verify* what the game is
  actually rendering at, instead of trusting a stored number.
- Ships an in-game Lua menu (`/hres` chat-command menu with presets, custom
  dimensions, apply/reset/save/restore and live status).
- Persists preferences in `HexedResolution.ini` via AML's own config system.

## What it does NOT do

- It does **not** change the Android system display resolution or density.
  No `wm size`, no `settings put`, no WRITE_SECURE_SETTINGS, no Shizuku/ADB,
  no root. (For contrast: that system-level approach is what PixelsPub does —
  this project deliberately implements the opposite, game-only path.)
- It does **not** modify other applications or other games.
- It does **not** guarantee FPS improvements. Lower internal render dimensions
  *may* reduce GPU workload; actual results depend on the renderer and your
  device bottleneck. Measure with the probe/log tools.
- It does **not** invent offsets. The only game-specific addresses used are the
  two PSDK-pinned `RsGlobal` pointer offsets (v2.00/v2.10), and they are used
  only after a runtime plausibility audit passes. On any other game build the
  plugin loads in **diagnostic-only mode** (zero hooks, zero game-memory
  writes) and reports itself as unsupported — unless you supply a *verified*
  offset profile for your build (see `config/HexedResolution.ini`).

## How the native plugin and the Lua menu communicate

AML itself does not embed a Lua runtime; Lua in SA-MP mobile clients comes from
the client and differs between builds. To avoid inventing client-specific API
calls, HEXED Resolution uses a **file-based command bridge** that works with
any Lua runtime that has standard `io` (all of them do):

```
<game external files>/hexed/bridge_cmd.txt    Lua  ->  plugin   (one command per line)
<game external files>/hexed/bridge_out.txt    plugin  ->  Lua   (one response per line)
```

Command/response protocol (also in `include/lua_bridge.h` and handled by
`lua/HexedResolution.lua`):

```
status | probe | apply <w> <h> [p720|p540|p450|custom] | reset
enable <0|1> | save <w> <h> <preset> | restore | log [n] | help
→ response:  CMD|CODE|w|h|text        CODE: OK QUEUED INVALID UNSUPPORTED FAILED DISABLED INFO
```

The plugin polls `bridge_cmd.txt` on a 200 ms worker thread, executes
game-memory operations only on the game thread (via the `frameEndEvent`
lifecycle hook), and writes results to `bridge_out.txt`.

For other **AML mods** there is also a native mod-to-mod interface registered
under `IHexedResolution001` (see `include/hexed_interface.h`), following AML's
documented interface system.

## Supported game versions and ABIs (as verified)

| Component | Status |
|---|---|
| GTA:SA Android v2.00, `libGTASA.so` armeabi-v7a (`RsGlobal` ptr @ `+0x67910C`) | PSDK-pinned, runtime-audited before use |
| GTA:SA Android v2.10, `libGTASA.so` arm64-v8a (`RsGlobal` ptr @ `+0x850240`) | PSDK-pinned, runtime-audited before use |
| Other libGTASA builds (e.g. 1.03-based clients) | Diagnostic-only unless you add a verified offset profile |

The pin values are taken from the vendored [aml-psdk](aml-psdk/README.md)
headers (`game_sa/engine/RsGlobal.h`, `DECL_OBJECT_PLT_GLOBAL(...,
BYBIT(0x67910C, 0x850240))`) — they are not HEXED inventions. The audit checks
that the pinned offset lies inside the mapped library, that the pointer targets
a `RsGlobalType` inside the library image, and that the width/height pair is a
plausible resolution (256–7680). Any failure ⇒ unsupported, nothing written.

> **Nezuko 1.0.3 TESTING note:** the client version string alone does not
> identify the underlying GTA:SA library build. No Nezuko APK was available
> during development, so its underlying libGTASA version could not be verified.
> If the audit rejects the build, capture `hexed/hexed_resolution.log` — it
> states exactly which check failed.

## Requirements

- A GTA:SA Android-based client with **AndroidModLoader (AML) 1.4.0+** working
  (Nezuko and similar SA-MP mobile repacks ship AML or a compatible loader).
- Android 5.0+ (plugin `APP_PLATFORM := android-21`).
- A client Lua runtime with standard `io` for the menu (optional — the plugin
  is fully usable via `bridge_cmd.txt` without Lua).

## Building

See [BUILD.md](BUILD.md). Short version:

```bash
./scripts/build.sh /path/to/android-ndk-r26d
# → build/libs/armeabi-v7a/libHexedResolution.so
# → build/libs/arm64-v8a/libHexedResolution64.so
```

Or push the repository to GitHub and run the included workflow
(`.github/workflows/build.yml`, supports `workflow_dispatch`).

## Installing

See [INSTALL.md](INSTALL.md) for file placement, menu usage, logs and
restoration.

## Known limitations (read before testing)

1. **Mid-game applies change `RsGlobal` immediately, but a full internal
   resolution change (camera/raster recreation) takes effect at the next
   renderer initialization.** The apply result code tells you which happened
   (`OK` = written and read back; watch the log/probe to confirm what the
   renderer is doing).
2. If the game derives its camera raster from the EGL surface rather than
   `RsGlobal` on your build, lowering `RsGlobal` reduces the HUD/2D coordinate
   space but not the 3D workload. The probe (RsGlobal vs EGL surface vs GL
   viewport) exists precisely to distinguish these cases on your device.
3. Aspect ratios differing from the surface ratio stretch the picture — the
   game's aspect handling is not re-derived by this plugin.
4. Touch coordinates follow the game's viewport; if you observe misalignment
   after an apply, use Reset and report the probe output.
5. Plugins cannot verify the renderer's behavior without a live device — that
   is what TESTING.md tracks honestly.

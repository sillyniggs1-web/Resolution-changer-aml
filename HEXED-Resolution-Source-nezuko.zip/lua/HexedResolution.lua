script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("1.1")
require "lib.moonloader"

-- HEXED Resolution: in-game menu for libHexedResolution.so (AML plugin).
-- Target: SA-MP Nezuko (MonetLoader / LuaJIT / mimgui). Open with /hres.
--
-- How it talks to the plugin (first one that works wins):
--   1. FFI: calls the exported hexed_command() of the already-loaded AML mod.
--   2. File bridge: <Android/data/com.nezukosamp.game>/files/hexed/bridge_*.txt
-- Nothing here changes Android display settings.

local imgui  = require("mimgui")
local inicfg = require("inicfg")
local ffi    = require("ffi")
local DPI    = MONET_DPI_SCALE or 1

-- Everything lives in one table: LuaJIT allows only 200 locals / 60 upvalues.
local H = {
    PKG      = "com.nezukosamp.game",
    MIN_DIM  = 128,
    MAX_DIM  = 7680,
    open     = imgui.new.bool(false),
    tab      = 1,
    en       = imgui.new.bool(false),   -- master enable (mirrors plugin)
    allow    = imgui.new.bool(false),   -- AllowNativeApply (mirrors plugin)
    w        = imgui.new.int(960),
    h        = imgui.new.int(540),
    preset   = "p540",
    lines    = {},                      -- diagnostics output
    last     = { code = "INFO", text = "Ready." },
    queue    = {},                      -- file-bridge requests awaiting a reply
    buf      = ffi.new("char[2048]"),
}

H.PRESETS = {
    { name = "p720", w = 1280, h = 720, label = "1280 x 720" },
    { name = "p540", w = 960,  h = 540, label = "960 x 540" },
    { name = "p450", w = 800,  h = 450, label = "800 x 450" },
}

-- ---------------------------------------------------------------- config ----
H.cfg = inicfg.load({
    main = { preset = "p540", width = 960, height = 540 },
}, "Hexed Resolution.ini")

local function saveCfg()
    H.cfg.main.preset = H.preset
    H.cfg.main.width  = H.w[0]
    H.cfg.main.height = H.h[0]
    pcall(inicfg.save, H.cfg, "Hexed Resolution.ini")
end

H.preset = tostring(H.cfg.main.preset or "p540")
H.w[0]   = tonumber(H.cfg.main.width)  or 960
H.h[0]   = tonumber(H.cfg.main.height) or 540

-- ------------------------------------------------------------- native side ----
ffi.cdef[[ int hexed_command(const char* cmd, char* out, int outLen); ]]

function H.detectPackage()
    local ok, dir = pcall(function() return getWorkingDirectory() end)
    if ok and type(dir) == "string" then
        local pkg = dir:match("Android/%a+/([%w_%.]+)/")
        if pkg and pkg:find("%.") then return pkg end
    end
    return H.PKG
end

function H.bindNative()
    local cands = { "libHexedResolution.so", "HexedResolution" }
    for _, name in ipairs(cands) do
        local ok, lib = pcall(ffi.load, name)
        if ok and lib then
            local ok2 = pcall(function() return lib.hexed_command end)
            if ok2 then H.lib = lib; H.libName = name; return true end
        end
    end
    local ok3 = pcall(function() return ffi.C.hexed_command end)
    if ok3 then H.lib = ffi.C; H.libName = "ffi.C"; return true end
    return false
end

-- Response line: CMD|CODE|w|h|text
function H.parse(line)
    local cmd, code, w, h, text = line:match("^([^|]+)|([^|]+)|(-?%d+)|(-?%d+)|(.*)$")
    if not cmd then return nil end
    return { cmd = cmd, code = code, w = tonumber(w) or 0, h = tonumber(h) or 0, text = text }
end

function H.codeColor(code)
    if code == "OK" or code == "QUEUED" then return imgui.ImVec4(0.30, 0.85, 0.40, 1) end
    if code == "INVALID" or code == "DISABLED" or code == "INFO" then return imgui.ImVec4(1.00, 0.70, 0.20, 1) end
    return imgui.ImVec4(1.00, 0.35, 0.35, 1)
end

function H.chat(text)
    if type(sampAddChatMessage) == "function" then
        pcall(sampAddChatMessage, "{3D9BFF}[HEXED]{FFFFFF} " .. text, -1)
    end
end

function H.handle(r)
    if not r then return end
    H.last = { code = r.code, text = r.text }
    if r.cmd == "status" or r.cmd == "probe" or r.cmd == "info" or r.cmd == "log" then
        table.insert(H.lines, 1, "[" .. r.cmd .. "] " .. r.text)
        while #H.lines > 12 do table.remove(H.lines) end
    end
end

-- file-bridge fallback ----------------------------------------------------------
function H.bridgeDir()
    local pkg = H.detectPackage()
    local c = {
        "/storage/emulated/0/Android/data/" .. pkg .. "/files/hexed",
        "/sdcard/Android/data/" .. pkg .. "/files/hexed",
        "/storage/emulated/0/Android/data/" .. pkg .. "/hexed",
    }
    for _, d in ipairs(c) do
        local f = io.open(d .. "/bridge_out.txt", "r")
        if f then f:close(); return d end
    end
    return nil
end

function H.fileSend(cmd)
    H.dir = H.dir or H.bridgeDir()
    if not H.dir then
        H.last = { code = "FAILED", text = "Plugin not found: is libHexedResolution.so in the mods folder?" }
        return
    end
    local f = io.open(H.dir .. "/bridge_cmd.txt", "w")
    if not f then H.last = { code = "FAILED", text = "cannot write bridge_cmd.txt" }; return end
    f:write(cmd, "\n"); f:close()
    H.queue[#H.queue + 1] = { cmd = cmd:match("^(%S+)"), t = os.clock() }
    H.last = { code = "INFO", text = "sent '" .. cmd .. "' ..." }
end

function H.filePoll()
    if #H.queue == 0 or not H.dir then return end
    local f = io.open(H.dir .. "/bridge_out.txt", "r")
    if not f then return end
    local got = {}
    for line in f:lines() do
        local r = H.parse(line)
        if r then got[#got + 1] = r end
    end
    f:close()
    if #got > 0 then
        local w = io.open(H.dir .. "/bridge_out.txt", "w"); if w then w:close() end
        for _, r in ipairs(got) do H.handle(r) end
        H.queue = {}
    elseif os.clock() - H.queue[1].t > 3 then
        H.last = { code = "FAILED", text = "no response from plugin (timeout)" }
        H.queue = {}
    end
end

-- single entry point used by the menu / chat command ---------------------------
function H.send(cmd)
    if H.lib then
        local n = H.lib.hexed_command(cmd, H.buf, 2048)
        local s = ffi.string(H.buf)
        if n >= 0 and #s > 0 then H.handle(H.parse(s)) else
            H.last = { code = "FAILED", text = (#s > 0 and s) or "empty response" }
        end
    else
        H.fileSend(cmd)
    end
end

function H.validate(w, h)
    if w < H.MIN_DIM or h < H.MIN_DIM then return false, "minimum dimension is " .. H.MIN_DIM end
    if w > H.MAX_DIM or h > H.MAX_DIM then return false, "maximum dimension is " .. H.MAX_DIM end
    local a = h / w
    if a < 0.40 or a > 2.80 then return false, "aspect ratio outside 0.40 .. 2.80" end
    return true
end

function H.presetName(w, h)
    for _, p in ipairs(H.PRESETS) do
        if p.w == w and p.h == h then return p.name end
    end
    return "custom"
end

function H.doApply()
    local w, h = H.w[0], H.h[0]
    local ok, why = H.validate(w, h)
    if not ok then H.last = { code = "INVALID", text = why }; return end
    H.send(string.format("apply %d %d %s", w, h, H.presetName(w, h)))
    saveCfg()
end

function H.doSave()
    local w, h = H.w[0], H.h[0]
    local ok, why = H.validate(w, h)
    if not ok then H.last = { code = "INVALID", text = why }; return end
    H.send(string.format("save %d %d %s", w, h, H.presetName(w, h)))
    saveCfg()
end

-- chat sub-commands: /hres [1|2|3|custom w h|apply|reset|status|probe|info|log|...]
function H.chatCmd(arg)
    arg = arg or ""
    local a = {}
    for t in arg:gmatch("%S+") do a[#a + 1] = t end
    local c = (a[1] or ""):lower()
    if c == "" or c == "menu" then H.open[0] = not H.open[0]; return end
    if c == "1" or c == "2" or c == "3" then
        local p = H.PRESETS[tonumber(c)]
        H.w[0], H.h[0], H.preset = p.w, p.h, p.name
        H.chat("preset " .. p.label .. " selected; use /hres apply")
        return
    end
    if c == "custom" then
        local w, h = tonumber(a[2]), tonumber(a[3])
        if not w or not h then H.chat("usage: /hres custom <w> <h>"); return end
        H.w[0], H.h[0], H.preset = math.floor(w), math.floor(h), "custom"
        H.chat("custom " .. H.w[0] .. "x" .. H.h[0] .. " selected; use /hres apply")
        return
    end
    if c == "apply" then H.doApply()
    elseif c == "save" then H.doSave()
    elseif c == "enable" then H.send("enable " .. ((a[2] == "off" or a[2] == "0") and 0 or 1))
    elseif c == "allow" then H.send("allow " .. ((a[2] == "off" or a[2] == "0") and 0 or 1))
    else H.send(arg) end -- reset | restore | status | probe | info | last | log [n] | help
    H.chat(H.last.code .. ": " .. H.last.text)
end

-- ------------------------------------------------------------------ style ----
local function V4(r, g, b, a) return imgui.ImVec4(r, g, b, a or 1) end

imgui.OnInitialize(function()
    imgui.GetIO().IniFilename = nil
    local fontPath = getWorkingDirectory() .. "/HEXED/Fonts/LamarFont.ttf"
    local f = io.open(fontPath, "r")
    if f then
        f:close()
        local fonts = imgui.GetIO().Fonts
        pcall(function()
            fonts:AddFontFromFileTTF(fontPath, 17 * DPI, nil, fonts:GetGlyphRangesCyrillic())
        end)
    end

    local st = imgui.GetStyle()
    st.WindowRounding   = 10 * DPI
    st.FrameRounding    = 6 * DPI
    st.ChildRounding    = 8 * DPI
    st.GrabRounding     = 6 * DPI
    st.WindowBorderSize = 1
    st.WindowPadding    = imgui.ImVec2(14 * DPI, 12 * DPI)
    st.ItemSpacing      = imgui.ImVec2(8 * DPI, 8 * DPI)
    st.FramePadding     = imgui.ImVec2(8 * DPI, 6 * DPI)
    st.ScrollbarSize    = 10 * DPI

    local c = st.Colors
    c[imgui.Col.WindowBg]         = V4(0.02, 0.03, 0.07, 0.97)
    c[imgui.Col.ChildBg]          = V4(0.03, 0.05, 0.10, 1.00)
    c[imgui.Col.Border]           = V4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]          = V4(0.06, 0.09, 0.18, 1.00)
    c[imgui.Col.FrameBgHovered]   = V4(0.10, 0.18, 0.36, 1.00)
    c[imgui.Col.FrameBgActive]    = V4(0.12, 0.25, 0.55, 1.00)
    c[imgui.Col.Button]           = V4(0.08, 0.20, 0.50, 1.00)
    c[imgui.Col.ButtonHovered]    = V4(0.12, 0.30, 0.70, 1.00)
    c[imgui.Col.ButtonActive]     = V4(0.15, 0.40, 0.90, 1.00)
    c[imgui.Col.CheckMark]        = V4(0.30, 0.65, 1.00, 1.00)
    c[imgui.Col.SliderGrab]       = V4(0.20, 0.50, 1.00, 1.00)
    c[imgui.Col.SliderGrabActive] = V4(0.30, 0.60, 1.00, 1.00)
    c[imgui.Col.Separator]        = V4(0.10, 0.35, 0.85, 0.60)
    c[imgui.Col.Text]             = V4(1.00, 1.00, 1.00, 1.00)
end)

-- width helper: reserve room for the label drawn to the right of a widget
local function widthLong()
    return imgui.GetContentRegionAvail().x - 90 * DPI
end

-- tab button, highlighted when active
local function tabButton(label, idx)
    local active = (H.tab == idx)
    if active then imgui.PushStyleColor(imgui.Col.Button, V4(0.15, 0.40, 0.90, 1)) end
    if imgui.Button(label, imgui.ImVec2(130 * DPI, 35 * DPI)) then H.tab = idx end
    if active then imgui.PopStyleColor() end
end

-- hand-made touch scrolling inside the current child window
local function touchScroll()
    if imgui.IsWindowHovered() and imgui.IsMouseDown(0) and not imgui.IsAnyItemActive() then
        local d = imgui.GetIO().MouseDelta.y
        if d ~= 0 then imgui.SetScrollY(imgui.GetScrollY() - d) end
    end
end

-- ------------------------------------------------------------------- tabs ----
local function drawResolutionTab()
    if imgui.Checkbox("Enable HEXED Resolution", H.en) then H.send("enable " .. (H.en[0] and 1 or 0)) end
    if imgui.Checkbox("Allow native apply (writes game memory)", H.allow) then
        H.send("allow " .. (H.allow[0] and 1 or 0))
    end
    imgui.Separator()

    imgui.Text("Presets")
    for i, p in ipairs(H.PRESETS) do
        local sel = (H.preset == p.name)
        if sel then imgui.PushStyleColor(imgui.Col.Button, V4(0.15, 0.40, 0.90, 1)) end
        if imgui.Button(p.label, imgui.ImVec2(0, 34 * DPI)) then
            H.w[0], H.h[0], H.preset = p.w, p.h, p.name
        end
        if sel then imgui.PopStyleColor() end
        if i < #H.PRESETS then imgui.SameLine() end
    end

    imgui.Separator()
    imgui.Text("Custom resolution")
    imgui.PushItemWidth(widthLong())
    if imgui.SliderInt("Width##s", H.w, 320, 3840) then H.preset = "custom" end
    if imgui.InputInt("Width##i", H.w) then H.preset = "custom" end
    if imgui.SliderInt("Height##s", H.h, 180, 2160) then H.preset = "custom" end
    if imgui.InputInt("Height##i", H.h) then H.preset = "custom" end
    imgui.PopItemWidth()

    imgui.Separator()
    local bw = (imgui.GetContentRegionAvail().x - imgui.GetStyle().ItemSpacing.x * 3) / 4
    local bs = imgui.ImVec2(bw, 38 * DPI)
    if imgui.Button("Apply", bs) then H.doApply() end
    imgui.SameLine()
    if imgui.Button("Reset", bs) then H.send("reset") end
    imgui.SameLine()
    if imgui.Button("Save", bs) then H.doSave() end
    imgui.SameLine()
    if imgui.Button("Restore", bs) then H.send("restore") end

    imgui.Separator()
    imgui.TextColored(H.codeColor(H.last.code), "[" .. H.last.code .. "]")
    imgui.SameLine()
    imgui.TextWrapped(H.last.text)
    imgui.TextWrapped("A full internal-resolution change may only take effect after the renderer "
        .. "re-initialises. Use the Diagnostics tab to check what the game is really rendering at.")
end

local function drawDiagTab()
    local bw = (imgui.GetContentRegionAvail().x - imgui.GetStyle().ItemSpacing.x * 3) / 4
    local bs = imgui.ImVec2(bw, 36 * DPI)
    if imgui.Button("Info", bs) then H.send("info") end
    imgui.SameLine()
    if imgui.Button("Status", bs) then H.send("status") end
    imgui.SameLine()
    if imgui.Button("Probe", bs) then H.send("probe") end
    imgui.SameLine()
    if imgui.Button("Log", bs) then H.send("log 8") end
    imgui.Separator()
    imgui.Text("Link: " .. (H.lib and ("FFI (" .. tostring(H.libName) .. ")") or "file bridge"))
    imgui.Separator()
    if #H.lines == 0 then
        imgui.TextWrapped("Press Info / Status / Probe. Probe compares RsGlobal with the EGL surface "
            .. "and GL viewport: that is the real test of whether the resolution changed.")
    end
    for _, l in ipairs(H.lines) do imgui.TextWrapped(l); imgui.Separator() end
end

-- ------------------------------------------------------------------- frame ----
imgui.OnFrame(function() return H.open[0] end, function()
    local io = imgui.GetIO()
    local sw, sh = io.DisplaySize.x, io.DisplaySize.y
    local ww = math.min(sw * 0.92, 640 * DPI)
    local wh = math.min(sh * 0.90, 430 * DPI)
    imgui.SetNextWindowPos(imgui.ImVec2(sw / 2, sh / 2), imgui.Cond.Always, imgui.ImVec2(0.5, 0.5))
    imgui.SetNextWindowSize(imgui.ImVec2(ww, wh), imgui.Cond.Always)
    imgui.Begin("##hexed_res", H.open,
        imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoCollapse
        + imgui.WindowFlags.NoScrollbar)

    local title = "HEXED Resolution"
    local tw = imgui.CalcTextSize(title).x
    imgui.SetCursorPosX((imgui.GetWindowWidth() - tw) / 2)
    imgui.TextColored(V4(0.30, 0.65, 1.00, 1), title)
    imgui.Separator()

    local bodyH = imgui.GetContentRegionAvail().y
    imgui.BeginChild("##tabs", imgui.ImVec2(146 * DPI, bodyH), false)
    tabButton("Resolution", 1)
    tabButton("Diagnostics", 2)
    imgui.SetCursorPosY(imgui.GetCursorPosY() + 10 * DPI)
    if imgui.Button("Close", imgui.ImVec2(130 * DPI, 35 * DPI)) then H.open[0] = false end
    imgui.EndChild()

    imgui.SameLine()
    imgui.BeginChild("##content", imgui.ImVec2(0, bodyH), true)
    touchScroll()
    if H.tab == 1 then drawResolutionTab() else drawDiagTab() end
    imgui.EndChild()

    imgui.End()
end)

-- --------------------------------------------------------------------- main ----
function main()
    while type(isSampAvailable) == "function" and not isSampAvailable() do wait(100) end

    H.bindNative()
    if type(sampRegisterChatCommand) == "function" then
        sampRegisterChatCommand("hres", H.chatCmd)
    end

    -- pull the plugin's current switches into the menu
    H.send("info")
    if H.lib then
        local s = H.last.text or ""
        H.en[0]    = s:find("enabled=1") ~= nil
        H.allow[0] = s:find("allowNativeApply=1") ~= nil
    end
    H.chat(H.lib and "Resolution plugin linked. Type /hres" or "Plugin not linked (file bridge). Type /hres")

    while true do
        wait(0)
        imgui.Process = true
        H.filePoll()
    end
end

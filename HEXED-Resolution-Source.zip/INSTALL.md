# INSTALL.md — installing and using HEXED Resolution

## 1. Prerequisites

- A GTA:SA Android client with **AndroidModLoader (AML) 1.4.0+** functioning
  (Nezuko SA-MP and similar repacks ship AML or a compatible loader). If other
  AML `.so` mods already load for you, you are set.
- The built plugin: `libHexedResolution.so` (32-bit clients) and/or
  `libHexedResolution64.so` (64-bit clients) from `build/libs/<abi>/` or the
  GitHub Actions artifact.

## 2. File placement

All paths below are resolved by AML at runtime; the plugin also **logs the two
important ones at startup** (see §6).

| File | Destination |
|---|---|
| `libHexedResolution.so` / `libHexedResolution64.so` | `/sdcard/Android/data/<game.package>/mods/` (AML mods directory; the loader picks the ABI it needs) |
| `lua/HexedResolution.lua` | Your client's Lua scripts directory (the folder your client already loads `.lua` scripts from). If your package name differs from `com.rockstargames.gtasa`, edit `CANDIDATE_DIRS` at the top of the script to the actual `files/hexed` path. |
| `config/HexedResolution.ini` *(optional)* | `/sdcard/Android/data/<game.package>/configs/HexedResolution.ini` — AML's config directory (returned by `aml->GetConfigPath()`). If you skip this, the plugin creates the file with safe defaults on first run. |

Runtime files the plugin creates itself:

```
/sdcard/Android/data/<game.package>/files/hexed/
├── bridge_cmd.txt            write commands here (Lua menu does this for you)
├── bridge_out.txt            read responses here
└── hexed_resolution.log      diagnostic log
```

## 3. First run (diagnostic mode by default)

On first launch the plugin runs **read-only**: it audits the game build,
starts the bridge, logs the environment — and changes nothing
(`AllowNativeApply = false`, `Enabled = false` by design).

1. Launch the game.
2. Open the Lua menu: type **`/hres`** in chat (or run `hexed_command("menu")`
   if your runtime lacks chat commands).
3. `/hres status` and `/hres probe` show the current rendering state and
   confirm the plugin sees your game build.
   - If you see `UNSUPPORTED`, your game build does not match the vendored
     PSDK profile — the log tells you exactly what failed (see §7).

## 4. Applying a resolution

1. `/hres enable on` — master switch.
2. Pick a preset: `/hres 1` (1280×720), `/hres 2` (960×540), `/hres 3`
   (800×450), or `/hres custom <w> <h>`.
3. `/hres apply` — sends the request. The plugin validates (128–7680, aspect
   0.40–2.80) and reports `OK`, `QUEUED`, `INVALID`, `UNSUPPORTED` or
   `DISABLED` with a human-readable reason.
4. The plugin writes `RsGlobal.maximumWidth/Height` on the next game frame and
   at the safe `initRwEvent` point. **A full internal-resolution change takes
   effect at the next renderer initialization** (e.g. reconnect or game
   restart with `RestoreAtStartup = true`).
5. Verify with `/hres probe` (RsGlobal vs EGL surface vs GL viewport) and the
   on-screen HEXED status line.

### Enabling native writes (one-time)

`Apply` reports `DISABLED` until you flip the master gate in
`HexedResolution.ini`:

```ini
[hexed]
Enabled = true
RestoreAtStartup = true      ; recommended: re-apply at RW init

[backend]
AllowNativeApply = true
```

Then `/hres save` + `/hres restore` (or just restart) makes the selection
stick. These defaults are deliberately conservative: no game memory is touched
until you opt in.

## 5. Resetting / restoring the original resolution

- **In-game:** `/hres reset` — restores the dimensions captured before the
  first apply of the session.
- **Automatically on unload:** if the mod is unloaded, the plugin attempts a
  restore.
- **Fallback:** set `Enabled = false` / `AllowNativeApply = false` in the INI
  and restart the game — the plugin then only ever reads.

## 6. Logs

- **File log** (always): `/sdcard/Android/data/<game.package>/files/hexed/hexed_resolution.log`
  (rotated at 512 KB, previous copy as `.log.old`).
- **Logcat:** tag `HEXED-Resolution`.
- **From the menu:** `/hres log 12` prints the last lines.
- **Verbose sampling:** set `VerboseLogging = true` for periodic
  RsGlobal/EGL/viewport samples.

## 7. If the build is reported unsupported

The audit log lists the failing check, e.g.:

```
compat: RsGlobal pointer 0x... outside libGTASA mapping (unsupported game build;
supply a verified offset profile in HexedResolution.ini)
```

That means your client uses a libGTASA build other than the PSDK-pinned
v2.00/v2.10 (e.g. a 1.03-based repack). The plugin will NOT guess. Options:

1. Keep using it in diagnostic mode (bridge + probe still work).
2. Obtain the `RsGlobal` pointer offset for **your exact library** from the
   community (or by reverse-engineering your own copy of `libGTASA.so`), then:

   ```ini
   [backend]
   UseCustomProfile = true
   RsGlobalPtrOffset32 = 0x......   ; armeabi-v7a libGTASA.so
   RsGlobalPtrOffset64 = 0x......   ; arm64 libGTASA.so
   ```

   The value is the offset **of the pointer to `RsGlobalType`** inside the
   library. The plugin still runs the full plausibility audit on it — a wrong
   value is rejected safely, never written.

## 8. Uninstalling

Delete the `.so` from `mods/`, the Lua script from your scripts folder, and
`configs/HexedResolution.ini` plus `files/hexed/` if you want a clean slate.
No system settings are ever modified, so nothing else needs reverting.

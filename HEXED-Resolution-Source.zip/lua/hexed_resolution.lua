script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("2.0.0")
require "lib.moonloader"
local imgui = require("mimgui")
local ffi   = require("ffi")
local DPI   = MONET_DPI_SCALE or 1

-- One table for all state (LuaJIT: 200 locals / 60 upvalues limit)
local H = {
    lib = nil, status = "Starting...", open = imgui.new.bool(false),
    pct = imgui.new.int(100), w = imgui.new.int(1280), tab = 1,
}

ffi.cdef[[
    int HEXED_IsReady(); int HEXED_GetOverride(); int HEXED_GetPercent(); int HEXED_GetOriginal();
    int HEXED_GetScreenW(); int HEXED_GetScreenH(); int HEXED_GetActiveW(); int HEXED_GetActiveH();
    int HEXED_PercentToWidth(int p); int HEXED_PercentToHeight(int p);
    int HEXED_SetPercent(int p); int HEXED_SetWidth(int w); int HEXED_Reset();
]]

-- AML already loaded the .so into this process; find its real path in /proc/self/maps
local function findLib()
    local ok, f = pcall(io.open, "/proc/self/maps", "r")
    if ok and f then
        for line in f:lines() do
            local p = line:match("(/%S*libHEXED_Resolution%.so)")
            if p then f:close(); local ok2, l = pcall(ffi.load, p); if ok2 then return l, p end end
        end
        f:close()
    end
    local ok3, l = pcall(ffi.load, "libHEXED_Resolution.so")
    if ok3 then return l, "libHEXED_Resolution.so" end
end

local function ready()
    if not H.lib then H.status = "Native mod not loaded"; return false end
    if H.lib.HEXED_IsReady() ~= 1 then H.status = "Game settings not loaded yet, try again in a moment"; return false end
    return true
end

local function previewText(p)
    return ("%d x %d"):format(H.lib.HEXED_PercentToWidth(p), H.lib.HEXED_PercentToHeight(p))
end

local function applyPct(p)
    if not ready() then return end
    if H.lib.HEXED_SetPercent(p) == 1 then H.pct[0] = p; H.status = ("Applied %d%% (%s)"):format(p, previewText(p))
    else H.status = "Rejected (engine range is 0-100%)" end
end

local function applyWidth(w)
    if not ready() then return end
    local p = H.lib.HEXED_SetWidth(w)
    if p >= 0 then H.pct[0] = p; H.status = ("Applied %d%% (%s)"):format(p, previewText(p))
    else H.status = "Rejected" end
end

local function doReset()
    if not ready() then return end
    H.lib.HEXED_Reset(); H.pct[0] = H.lib.HEXED_GetOriginal(); H.status = "Reset to the game's original value"
end

local function widthLong() return imgui.GetContentRegionAvail().x - 120 * DPI end

imgui.OnInitialize(function()
    local s = imgui.GetStyle(); local c = s.Colors
    s.WindowRounding = 10; s.FrameRounding = 6; s.WindowBorderSize = 1; s.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.96)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.05, 0.08, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.25, 0.65, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.12, 0.38, 0.90, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.06, 0.20, 0.55, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.15, 0.45, 1.00, 1.00)
end)

local function tabButton(i, name)
    if imgui.Button(name, imgui.ImVec2(130 * DPI, 35 * DPI)) then H.tab = i end
end

imgui.OnFrame(function() return H.open[0] end, function()
    local io, L = imgui.GetIO(), H.lib
    imgui.SetNextWindowPos(imgui.ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.SetNextWindowSize(imgui.ImVec2(620 * DPI, 380 * DPI), imgui.Cond.FirstUseEver)
    imgui.Begin("##hxdres", H.open, imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoCollapse)

    local t = "HEXED RESOLUTION"
    imgui.SetCursorPosX((imgui.GetWindowWidth() - imgui.CalcTextSize(t).x) / 2)
    imgui.TextColored(imgui.ImVec4(0.25, 0.55, 1, 1), t)
    imgui.Separator()

    imgui.BeginChild("##left", imgui.ImVec2(140 * DPI, 0), false)
    tabButton(1, "Quality"); tabButton(2, "Width"); tabButton(3, "Info")
    imgui.Dummy(imgui.ImVec2(0, 20 * DPI))
    if imgui.Button("Close", imgui.ImVec2(130 * DPI, 35 * DPI)) then H.open[0] = false end
    imgui.EndChild()
    imgui.SameLine()

    imgui.BeginChild("##right", imgui.ImVec2(0, 0), false)
    if H.tab == 1 then
        imgui.Text("Engine resolution (100% = native screen)")
        imgui.PushItemWidth(widthLong())
        imgui.SliderInt("##pct", H.pct, 0, 100)
        imgui.PopItemWidth()
        if L and L.HEXED_IsReady() == 1 then imgui.Text("Render size: " .. previewText(H.pct[0])) end
        for _, p in ipairs({0, 25, 50, 75, 100}) do
            if imgui.Button(p .. "%", imgui.ImVec2(70 * DPI, 35 * DPI)) then applyPct(p) end
            imgui.SameLine()
        end
        imgui.NewLine()
        if imgui.Button("Apply", imgui.ImVec2(120 * DPI, 35 * DPI)) then applyPct(H.pct[0]) end
        imgui.SameLine()
        if imgui.Button("Reset", imgui.ImVec2(120 * DPI, 35 * DPI)) then doReset() end
    elseif H.tab == 2 then
        imgui.Text("Target render width (nearest engine step)")
        imgui.PushItemWidth(widthLong())
        imgui.InputInt("Width", H.w, 16, 64)
        imgui.PopItemWidth()
        if imgui.Button("Apply", imgui.ImVec2(120 * DPI, 35 * DPI)) then applyWidth(H.w[0]) end
        imgui.SameLine()
        if imgui.Button("Reset", imgui.ImVec2(120 * DPI, 35 * DPI)) then doReset() end
        for _, w in ipairs({854, 1280, 1600}) do
            if imgui.Button(tostring(w), imgui.ImVec2(90 * DPI, 35 * DPI)) then H.w[0] = w; applyWidth(w) end
            imgui.SameLine()
        end
        imgui.NewLine()
        imgui.TextWrapped("The game cannot render above the native screen width.")
    else
        if L and L.HEXED_IsReady() == 1 then
            imgui.Text(("Screen : %d x %d"):format(L.HEXED_GetScreenW(), L.HEXED_GetScreenH()))
            imgui.Text(("Active render target: %d x %d (0 = direct)"):format(L.HEXED_GetActiveW(), L.HEXED_GetActiveH()))
            imgui.Text(("Engine value: %d%%   Original: %d%%"):format(L.HEXED_GetPercent(), L.HEXED_GetOriginal()))
            imgui.Text("Override: " .. (L.HEXED_GetOverride() == 1 and "ON" or "off"))
        else
            imgui.Text(L and "Waiting for game settings..." or "Native mod not found")
        end
        imgui.TextWrapped("Uses the game's own resolution setting. No code is hooked.")
    end
    imgui.Separator()
    imgui.Text("Status: " .. H.status)
    imgui.EndChild()
    imgui.End()
end)

function main()
    while not isSampLoaded or not isSampLoaded() do wait(100) end
    local path
    H.lib, path = findLib()
    if not H.lib then H.status = "libHEXED_Resolution.so not loaded by AML"
    else
        local tries = 0
        while H.lib.HEXED_IsReady() ~= 1 and tries < 100 do wait(200); tries = tries + 1 end
        if H.lib.HEXED_IsReady() == 1 then
            H.pct[0] = H.lib.HEXED_GetPercent()
            H.status = H.lib.HEXED_GetOverride() == 1 and "Ready (override active)" or "Ready"
        else H.status = "Settings never loaded - see logcat HEXED_Resolution" end
    end
    print("[HEXED Resolution] " .. H.status .. (path and (" [" .. path .. "]") or ""))
    sampRegisterChatCommand("hxdres", function() H.open[0] = not H.open[0]; imgui.Process = true end)
    sampRegisterChatCommand("hxdres_pct", function(a)
        local p = tonumber(a); if p then applyPct(math.floor(p)) else sampAddChatMessage("Usage: /hxdres_pct 0-100", -1) end
    end)
    sampRegisterChatCommand("hxdres_reset", doReset)
    while true do wait(0); imgui.Process = H.open[0] end
end

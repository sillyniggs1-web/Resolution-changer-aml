script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("3.0.0")
require "lib.moonloader"
local imgui = require("mimgui")
local ffi   = require("ffi")
local DPI   = MONET_DPI_SCALE or 1

-- One table for all state (LuaJIT: 200 locals / 60 upvalues limit)
local H = {
    lib = nil, status = "Starting...", open = imgui.new.bool(false),
    w = imgui.new.int(1280), h = imgui.new.int(720),
}
local PRESETS = { {1280, 720}, {1366, 768}, {1920, 1080} }

ffi.cdef[[
    int HEXED_IsReady(); int HEXED_GetOverride();
    int HEXED_GetNativeW(); int HEXED_GetNativeH();
    int HEXED_GetCurrentW(); int HEXED_GetCurrentH();
    int HEXED_GetActiveW(); int HEXED_GetActiveH();
    int HEXED_GetMaxSide(); int HEXED_GetMinW(); int HEXED_GetMinH();
    int HEXED_SetSize(int w, int h); int HEXED_Reset();
]]

-- AML already loaded the .so into this process; find its real path in /proc/self/maps
local function findLib()
    local ok, f = pcall(io.open, "/proc/self/maps", "r")
    if ok and f then
        for line in f:lines() do
            local p = line:match("(/%S*libHEXED_Resolution%.so)")
            if p then f:close(); local ok2, l = pcall(ffi.load, p); if ok2 then return l, p end end
        end
        f:close()
    end
    local ok3, l = pcall(ffi.load, "libHEXED_Resolution.so")
    if ok3 then return l, "libHEXED_Resolution.so" end
end

local function ready()
    if not H.lib then H.status = "Native mod not loaded"; return false end
    if H.lib.HEXED_IsReady() ~= 1 then H.status = "Game not ready yet, try again in a moment"; return false end
    return true
end

local function applySize(w, h)
    if not ready() then return end
    if H.lib.HEXED_SetSize(w, h) == 1 then
        H.w[0], H.h[0] = w, h
        H.status = ("Applied %d x %d"):format(w, h)
    else
        H.status = ("Rejected (min %dx%d, max side %d)"):format(H.lib.HEXED_GetMinW(), H.lib.HEXED_GetMinH(), H.lib.HEXED_GetMaxSide())
    end
end

local function doReset()
    if not ready() then return end
    H.lib.HEXED_Reset()
    H.w[0], H.h[0] = H.lib.HEXED_GetNativeW(), H.lib.HEXED_GetNativeH()
    H.status = "Back to native"
end

local function stepper(label, v, lo, hi)
    imgui.PushItemWidth(imgui.GetContentRegionAvail().x - 90 * DPI)
    imgui.SliderInt("##s" .. label, v, lo, hi)
    imgui.PopItemWidth()
    imgui.SameLine()
    if imgui.Button("-##" .. label, imgui.ImVec2(36 * DPI, 0)) then v[0] = math.max(lo, v[0] - 1) end
    imgui.SameLine()
    if imgui.Button("+##" .. label, imgui.ImVec2(36 * DPI, 0)) then v[0] = math.min(hi, v[0] + 1) end
end

imgui.OnInitialize(function()
    local s = imgui.GetStyle(); local c = s.Colors
    s.WindowRounding = 10; s.FrameRounding = 6; s.WindowBorderSize = 1; s.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.96)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.05, 0.08, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.25, 0.65, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.12, 0.38, 0.90, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.06, 0.20, 0.55, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.15, 0.45, 1.00, 1.00)
end)

imgui.OnFrame(function() return H.open[0] end, function()
    local io, L = imgui.GetIO(), H.lib
    imgui.SetNextWindowPos(imgui.ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.SetNextWindowSize(imgui.ImVec2(420 * DPI, 430 * DPI), imgui.Cond.FirstUseEver)
    imgui.Begin("Hexed Resolution##hxdres", H.open, imgui.WindowFlags.NoCollapse)

    imgui.Text("Display / Resolution")
    if L and L.HEXED_IsReady() == 1 then
        local cw, ch = L.HEXED_GetCurrentW(), L.HEXED_GetCurrentH()
        local tag = (L.HEXED_GetOverride() == 0) and " (native)" or ""
        imgui.Text(("Current: %d x %d%s"):format(cw, ch, tag))
        local aw, ah = L.HEXED_GetActiveW(), L.HEXED_GetActiveH()
        if aw > 0 then imgui.TextDisabled(("Render target: %d x %d"):format(aw, ah)) end
    else
        imgui.Text(L and "Waiting for the game to finish loading..." or "Native mod not found")
    end

    imgui.Separator()
    imgui.Text("Presets")
    local bw = (imgui.GetContentRegionAvail().x - 16 * DPI) / 3
    for i, p in ipairs(PRESETS) do
        if imgui.Button(("%dx%d"):format(p[1], p[2]), imgui.ImVec2(bw, 34 * DPI)) then applySize(p[1], p[2]) end
        if i < #PRESETS then imgui.SameLine() end
    end
    if imgui.Button("Default (native)", imgui.ImVec2(-1, 34 * DPI)) then doReset() end

    imgui.Separator()
    imgui.Text("Custom")
    local mx = L and L.HEXED_GetMaxSide() or 2560
    stepper("w", H.w, 320, mx); stepper("h", H.h, 180, mx)
    if imgui.Button("Apply Custom", imgui.ImVec2(-1, 34 * DPI)) then applySize(H.w[0], H.h[0]) end

    imgui.Separator()
    imgui.TextWrapped("Status: " .. H.status)
    if imgui.Button("Close", imgui.ImVec2(-1, 34 * DPI)) then H.open[0] = false end
    imgui.End()
end)

function main()
    while not isSampLoaded or not isSampLoaded() do wait(100) end
    local path
    H.lib, path = findLib()
    if not H.lib then H.status = "libHEXED_Resolution.so not loaded by AML"
    else
        local tries = 0
        while H.lib.HEXED_IsReady() ~= 1 and tries < 150 do wait(200); tries = tries + 1 end
        if H.lib.HEXED_IsReady() == 1 then
            H.w[0], H.h[0] = H.lib.HEXED_GetCurrentW(), H.lib.HEXED_GetCurrentH()
            H.status = H.lib.HEXED_GetOverride() == 1 and "Ready (saved size active)" or "Ready"
        else H.status = "Game never became ready - see logcat HEXED_Resolution" end
    end
    print("[HEXED Resolution] " .. H.status .. (path and (" [" .. path .. "]") or ""))
    sampRegisterChatCommand("hxdres", function() H.open[0] = not H.open[0]; imgui.Process = true end)
    sampRegisterChatCommand("hxdres_set", function(a)
        local w, h = tostring(a):match("(%d+)%D+(%d+)")
        if w then applySize(tonumber(w), tonumber(h)) else sampAddChatMessage("Usage: /hxdres_set 1280 720", -1) end
    end)
    sampRegisterChatCommand("hxdres_reset", doReset)
    while true do wait(0); imgui.Process = H.open[0] end
end

script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("1.0.0")
require "lib.moonloader"
local imgui = require("mimgui")
local ffi   = require("ffi")
local DPI   = MONET_DPI_SCALE or 1

-- Everything lives in one table (LuaJIT: 200 locals / 60 upvalues limit)
local H = {
    lib = nil, status = "Starting...", open = imgui.new.bool(false),
    scale = imgui.new.int(100), w = imgui.new.int(1280), h = imgui.new.int(720),
    tab = 1,
}

ffi.cdef[[
    int HEXED_IsReady(); int HEXED_GetMode(); int HEXED_GetScale();
    int HEXED_GetSizeW(); int HEXED_GetSizeH();
    int HEXED_GetScreenW(); int HEXED_GetScreenH();
    int HEXED_GetActiveW(); int HEXED_GetActiveH();
    int HEXED_SetScale(int percent); int HEXED_SetSize(int w, int h); int HEXED_Reset();
]]

-- AML already loaded the .so into this process. Find its real path in /proc/self/maps
-- so ffi.load returns that same loaded library instead of guessing folders.
local function findLib()
    local ok, f = pcall(io.open, "/proc/self/maps", "r")
    if ok and f then
        for line in f:lines() do
            local p = line:match("(/%S*libHEXED_Resolution%.so)")
            if p then f:close(); local ok2, l = pcall(ffi.load, p); if ok2 then return l, p end end
        end
        f:close()
    end
    local ok3, l = pcall(ffi.load, "libHEXED_Resolution.so")
    if ok3 then return l, "libHEXED_Resolution.so" end
end

local function sync()
    local L = H.lib
    if not L then return end
    H.scale[0] = L.HEXED_GetScale()
    H.w[0], H.h[0] = L.HEXED_GetSizeW(), L.HEXED_GetSizeH()
end

local function setStatus(ok, okText)
    H.status = ok and okText or "Rejected (range 25-200% / 320x180 to 4096x4096)"
end

local function applyScale(p)
    if not H.lib then H.status = "Native mod not loaded"; return end
    H.scale[0] = p
    setStatus(H.lib.HEXED_SetScale(p) == 1, "Applied " .. p .. "%")
end

local function applySize(w, h)
    if not H.lib then H.status = "Native mod not loaded"; return end
    setStatus(H.lib.HEXED_SetSize(w, h) == 1, ("Applied %dx%d"):format(w, h))
end

local function doReset()
    if not H.lib then H.status = "Native mod not loaded"; return end
    H.lib.HEXED_Reset(); H.status = "Reset to engine default"
end

local function widthLong() return imgui.GetContentRegionAvail().x - 120 * DPI end

imgui.OnInitialize(function()
    local s = imgui.GetStyle(); local c = s.Colors
    s.WindowRounding = 10; s.FrameRounding = 6; s.WindowBorderSize = 1; s.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.96)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.05, 0.08, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.25, 0.65, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.12, 0.38, 0.90, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.06, 0.20, 0.55, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.15, 0.45, 1.00, 1.00)
end)

local function tabButton(i, name)
    if imgui.Button(name, imgui.ImVec2(130 * DPI, 35 * DPI)) then H.tab = i end
end

imgui.OnFrame(function() return H.open[0] end, function()
    local io = imgui.GetIO()
    imgui.SetNextWindowPos(imgui.ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.SetNextWindowSize(imgui.ImVec2(620 * DPI, 380 * DPI), imgui.Cond.FirstUseEver)
    imgui.Begin("##hxdres", H.open, imgui.WindowFlags.NoTitleBar + imgui.WindowFlags.NoCollapse)

    local t = "HEXED RESOLUTION"
    imgui.SetCursorPosX((imgui.GetWindowWidth() - imgui.CalcTextSize(t).x) / 2)
    imgui.TextColored(imgui.ImVec4(0.25, 0.55, 1, 1), t)
    imgui.Separator()

    imgui.BeginChild("##left", imgui.ImVec2(140 * DPI, 0), false)
    tabButton(1, "Scale"); tabButton(2, "Custom"); tabButton(3, "Info")
    imgui.Dummy(imgui.ImVec2(0, 20 * DPI))
    if imgui.Button("Close", imgui.ImVec2(130 * DPI, 35 * DPI)) then H.open[0] = false end
    imgui.EndChild()
    imgui.SameLine()

    imgui.BeginChild("##right", imgui.ImVec2(0, 0), false)
    local L = H.lib
    if H.tab == 1 then
        imgui.Text("Render scale (% of screen width)")
        imgui.PushItemWidth(widthLong())
        imgui.SliderInt("##scale", H.scale, 25, 200)
        imgui.PopItemWidth()
        for _, p in ipairs({50, 60, 75, 100, 125, 150}) do
            if imgui.Button(p .. "%", imgui.ImVec2(70 * DPI, 35 * DPI)) then applyScale(p) end
            imgui.SameLine()
        end
        imgui.NewLine()
        if imgui.Button("Apply", imgui.ImVec2(120 * DPI, 35 * DPI)) then applyScale(H.scale[0]) end
        imgui.SameLine()
        if imgui.Button("Reset", imgui.ImVec2(120 * DPI, 35 * DPI)) then doReset() end
    elseif H.tab == 2 then
        imgui.Text("Exact render size")
        imgui.PushItemWidth(widthLong())
        imgui.InputInt("Width", H.w, 16, 64); imgui.InputInt("Height", H.h, 16, 64)
        imgui.PopItemWidth()
        if imgui.Button("Apply", imgui.ImVec2(120 * DPI, 35 * DPI)) then applySize(H.w[0], H.h[0]) end
        imgui.SameLine()
        if imgui.Button("Reset", imgui.ImVec2(120 * DPI, 35 * DPI)) then doReset() end
        for _, p in ipairs({{854,480},{1280,720},{1600,900},{1920,1080}}) do
            if imgui.Button(p[1] .. "x" .. p[2], imgui.ImVec2(110 * DPI, 35 * DPI)) then H.w[0], H.h[0] = p[1], p[2]; applySize(p[1], p[2]) end
            imgui.SameLine()
        end
        imgui.NewLine()
    else
        if L then
            local m = ({[0] = "Engine default", "Scale", "Exact size"})[L.HEXED_GetMode()] or "?"
            imgui.Text(("Screen : %d x %d"):format(L.HEXED_GetScreenW(), L.HEXED_GetScreenH()))
            imgui.Text(("Active render target: %d x %d (0 = direct)"):format(L.HEXED_GetActiveW(), L.HEXED_GetActiveH()))
            imgui.Text("Mode   : " .. m)
        else
            imgui.Text("Native mod not found")
        end
        imgui.TextWrapped("Changes the game's internal render size. HUD and touch are not affected.")
    end
    imgui.Separator()
    imgui.Text("Status: " .. H.status)
    imgui.EndChild()
    imgui.End()
end)

function main()
    while not isSampLoaded or not isSampLoaded() do wait(100) end
    local path
    H.lib, path = findLib()
    if H.lib and H.lib.HEXED_IsReady() == 1 then
        sync(); H.status = "Ready (" .. (H.lib.HEXED_GetMode() == 0 and "default" or "custom active") .. ")"
    elseif H.lib then
        H.status = "Native loaded but hook inactive - see logcat HEXED_Resolution"
    else
        H.status = "libHEXED_Resolution.so not loaded by AML"
    end
    print("[HEXED Resolution] " .. H.status .. (path and (" [" .. path .. "]") or ""))
    sampRegisterChatCommand("hxdres", function() H.open[0] = not H.open[0]; imgui.Process = true end)
    sampRegisterChatCommand("hxdres_scale", function(a)
        local p = tonumber(a); if p then applyScale(p) else sampAddChatMessage("Usage: /hxdres_scale 25-200", -1) end
    end)
    sampRegisterChatCommand("hxdres_reset", doReset)
    while true do wait(0); imgui.Process = H.open[0] end
end

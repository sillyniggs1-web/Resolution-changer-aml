script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("5.0.1")
require "lib.moonloader"
local imgui = require("mimgui")
local ffi   = require("ffi")
local DPI   = MONET_DPI_SCALE or 1

-- One table for all state (LuaJIT: 200 locals / 60 upvalues limit)
local H = {
    lib = nil, status = "Starting...", open = imgui.new.bool(false), pending = nil,
    pct = imgui.new.int(100), w = imgui.new.int(1280), h = imgui.new.int(720),
}
local SCALE_PRESETS = { 50, 75, 100 }
local WIDTH_PRESETS = { 1280, 1600, 1920 }
local WIN_PRESETS   = { {1280, 720}, {1366, 768}, {1920, 1080} }

ffi.cdef[[
    int HEXED_IsReady(); int HEXED_GetOverride(); int HEXED_WasSafeMode();
    int HEXED_GetNativeW(); int HEXED_GetNativeH(); int HEXED_GetCurrentW(); int HEXED_GetCurrentH();
    int HEXED_GetActiveW(); int HEXED_GetActiveH(); int HEXED_GetMaxSide(); int HEXED_GetMinW(); int HEXED_GetMinH();
    int HEXED_SetSize(int w, int h); int HEXED_Reset();
    int HEXED_ScaleAvailable(); int HEXED_GetScaleOverride(); int HEXED_GetScalePercent(); int HEXED_GetScaleOriginal();
    int HEXED_PercentToWidth(int p); int HEXED_PercentToHeight(int p); int HEXED_WidthToPercent(int w);
    int HEXED_SetScale(int p); int HEXED_ResetScale();
    int HEXED_SetCenter(int on); int HEXED_GetCenter(); int HEXED_SetFitMode(int m); int HEXED_GetFitMode();
    int HEXED_GetCenterInfo(int idx); int HEXED_SetMenuOpen(int open); int HEXED_Tick();
]]

-- AML already loaded the .so into this process; find its real path in /proc/self/maps
local function findLib()
    local ok, f = pcall(io.open, "/proc/self/maps", "r")
    if ok and f then
        for line in f:lines() do
            local p = line:match("(/%S*libHEXED_Resolution%.so)")
            if p then f:close(); local ok2, l = pcall(ffi.load, p); if ok2 then return l, p end end
        end
        f:close()
    end
    local ok3, l = pcall(ffi.load, "libHEXED_Resolution.so")
    if ok3 then return l, "libHEXED_Resolution.so" end
end

local function ready()
    if not H.lib then H.status = "Native mod not loaded"; return false end
    if H.lib.HEXED_IsReady() ~= 1 then H.status = "Game not ready yet, try again in a moment"; return false end
    return true
end

local function sizeText(p) return ("%d x %d"):format(H.lib.HEXED_PercentToWidth(p), H.lib.HEXED_PercentToHeight(p)) end

-- Real work runs on the game's script thread (main loop), never inside the draw callback.
local function realScale(p)
    if not ready() then return end
    print(("[HEXED Resolution] render scale %d%%"):format(p))
    if H.lib.HEXED_ScaleAvailable() ~= 1 then H.status = "Render scale unavailable (see log)"; return end
    if H.lib.HEXED_SetScale(p) == 1 then H.pct[0] = p; H.status = ("Render scale %d%% (%s)"):format(p, sizeText(p))
    else H.status = "Rejected (range 0-100)" end
end
local function realScaleReset()
    if not ready() then return end
    print("[HEXED Resolution] render scale reset")
    H.lib.HEXED_ResetScale(); H.pct[0] = H.lib.HEXED_GetScaleOriginal(); H.status = "Render scale: default"
end
local function realWindow(w, h)
    if not ready() then return end
    print(("[HEXED Resolution] window size %dx%d"):format(w, h))
    if H.lib.HEXED_SetSize(w, h) == 1 then H.w[0], H.h[0] = w, h; H.status = ("Window size %d x %d (experimental)"):format(w, h)
    else H.status = ("Rejected (min %dx%d, max side %d)"):format(H.lib.HEXED_GetMinW(), H.lib.HEXED_GetMinH(), H.lib.HEXED_GetMaxSide()) end
end
local function realWindowReset()
    if not ready() then return end
    print("[HEXED Resolution] window reset")
    H.lib.HEXED_Reset(); H.w[0], H.h[0] = H.lib.HEXED_GetNativeW(), H.lib.HEXED_GetNativeH(); H.status = "Window size: native"
end

local function realCenter(on)
    if not ready() then return end
    print(("[HEXED Resolution] center %s"):format(on and "on" or "off"))
    H.lib.HEXED_SetCenter(on and 1 or 0)
    H.status = on and "Centered with black bars: ON" or "Centered with black bars: OFF"
end
local function realFit(m)
    if not ready() then return end
    print(("[HEXED Resolution] fit mode %d"):format(m))
    H.lib.HEXED_SetFitMode(m)
    H.status = (m == 1) and "Centered 1:1 (no upscaling, bigger black bars)" or "Centered, scaled to fit the screen"
end

local function queue(kind, a, b) H.pending = { kind = kind, a = a, b = b }; H.status = "Applying ..." end
local function applyScale(p)     queue("scale", p) end
local function applyWidth(w)
    if not ready() then return end
    local p = H.lib.HEXED_WidthToPercent(w)
    if p >= 0 then queue("scale", p) else H.status = "Width mapping unavailable" end
end
local function resetScale()      queue("scale_reset") end
local function applyWindow(w, h) queue("window", w, h) end
local function resetWindow()     queue("window_reset") end
local function applyCenter(on)   queue("center", on) end
local function applyFit(m)       queue("fit", m) end

imgui.OnInitialize(function()
    local s = imgui.GetStyle(); local c = s.Colors
    s.WindowRounding = 10; s.FrameRounding = 6; s.WindowBorderSize = 1; s.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.96)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.05, 0.08, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.25, 0.65, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.12, 0.38, 0.90, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.06, 0.20, 0.55, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.15, 0.45, 1.00, 1.00)
end)

local function row3(labels, fn)
    local bw = (imgui.GetContentRegionAvail().x - 16 * DPI) / #labels
    for i, l in ipairs(labels) do
        if imgui.Button(l[1], imgui.ImVec2(bw, 34 * DPI)) then fn(l[2]) end
        if i < #labels then imgui.SameLine() end
    end
end

imgui.OnFrame(function() return H.open[0] end, function()
    local io, L = imgui.GetIO(), H.lib
    imgui.SetNextWindowPos(imgui.ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.SetNextWindowSize(imgui.ImVec2(430 * DPI, 640 * DPI), imgui.Cond.FirstUseEver)
    imgui.Begin("Hexed Resolution##hxdres", H.open, imgui.WindowFlags.NoCollapse)

    local rdy = L and L.HEXED_IsReady() == 1
    imgui.Text("Display / Resolution")
    if rdy then
        imgui.Text(("Screen: %d x %d (native)"):format(L.HEXED_GetNativeW(), L.HEXED_GetNativeH()))
        local aw, ah = L.HEXED_GetActiveW(), L.HEXED_GetActiveH()
        imgui.TextDisabled(("Render target: %s"):format(aw > 0 and ("%d x %d"):format(aw, ah) or "direct"))
    else
        imgui.Text(L and "Waiting for the game to finish loading..." or "Native mod not found")
    end

    imgui.Separator()
    imgui.TextColored(imgui.ImVec4(0.35, 0.75, 1, 1), "Render resolution (recommended)")
    imgui.TextDisabled("Engine's own scale: touch and HUD stay correct")
    if rdy and L.HEXED_ScaleAvailable() == 1 then
        imgui.PushItemWidth(imgui.GetContentRegionAvail().x - 8 * DPI)
        imgui.SliderInt("##pct", H.pct, 0, 100, "%d%%")
        imgui.PopItemWidth()
        imgui.Text("Renders at " .. sizeText(H.pct[0]))
        local lab = {}
        for _, p in ipairs(SCALE_PRESETS) do lab[#lab + 1] = { p .. "%", p } end
        row3(lab, applyScale)
        lab = {}
        for _, w in ipairs(WIDTH_PRESETS) do lab[#lab + 1] = { w .. " wide", w } end
        row3(lab, applyWidth)
        if imgui.Button("Apply slider", imgui.ImVec2(imgui.GetContentRegionAvail().x / 2 - 4 * DPI, 34 * DPI)) then applyScale(H.pct[0]) end
        imgui.SameLine()
        if imgui.Button("Default", imgui.ImVec2(-1, 34 * DPI)) then resetScale() end
    else
        imgui.Text("Not available yet")
    end

    imgui.Separator()
    imgui.TextColored(imgui.ImVec4(1, 0.7, 0.3, 1), "Window size (experimental)")
    imgui.TextWrapped("Changes the size the game thinks the screen has. Touch is NOT rescaled, so controls can be off.")
    local mx = L and L.HEXED_GetMaxSide() or 2560
    imgui.PushItemWidth(imgui.GetContentRegionAvail().x - 8 * DPI)
    imgui.SliderInt("##ww", H.w, 320, mx, "W %d"); imgui.SliderInt("##wh", H.h, 180, mx, "H %d")
    imgui.PopItemWidth()
    local lab = {}
    for _, p in ipairs(WIN_PRESETS) do lab[#lab + 1] = { ("%dx%d"):format(p[1], p[2]), p } end
    row3(lab, function(p) applyWindow(p[1], p[2]) end)
    if imgui.Button("Apply custom", imgui.ImVec2(imgui.GetContentRegionAvail().x / 2 - 4 * DPI, 34 * DPI)) then applyWindow(H.w[0], H.h[0]) end
    imgui.SameLine()
    if imgui.Button("Native", imgui.ImVec2(-1, 34 * DPI)) then resetWindow() end

    imgui.Separator()
    imgui.TextColored(imgui.ImVec4(0.4, 1, 0.6, 1), "Screen centering (black bars)")
    imgui.TextDisabled("Keeps the picture in the middle of the screen")
    if rdy then
        local on  = L.HEXED_GetCenter() == 1
        local one = L.HEXED_GetFitMode() == 1
        local hw = imgui.GetContentRegionAvail().x / 2 - 4 * DPI
        if imgui.Button(on and "Center: ON" or "Center: OFF", imgui.ImVec2(hw, 34 * DPI)) then applyCenter(not on) end
        imgui.SameLine()
        if imgui.Button(one and "Mode: 1:1 pixels" or "Mode: Fit screen", imgui.ImVec2(-1, 34 * DPI)) then applyFit(one and 0 or 1) end
        local sw, sh = L.HEXED_GetCenterInfo(0), L.HEXED_GetCenterInfo(1)
        imgui.TextDisabled(("Surface %dx%d | game draws %dx%d"):format(sw, sh, L.HEXED_GetCenterInfo(6), L.HEXED_GetCenterInfo(7)))
        imgui.TextWrapped("While this menu is open the picture is NOT moved (so taps match). Close the menu to see it centered.")
        imgui.TextDisabled(("hooks=%d frames=%d gpu=%d glerr=0x%x"):format(L.HEXED_GetCenterInfo(8),
            L.HEXED_GetCenterInfo(12), L.HEXED_GetCenterInfo(14), L.HEXED_GetCenterInfo(13)))
    else
        imgui.Text("Not available yet")
    end

    imgui.Separator()
    imgui.TextWrapped("Status: " .. H.status)
    if imgui.Button("Close", imgui.ImVec2(-1, 34 * DPI)) then H.open[0] = false end
    imgui.End()
end)

function main()
    while not isSampLoaded or not isSampLoaded() do wait(100) end
    local path
    H.lib, path = findLib()
    if not H.lib then H.status = "libHEXED_Resolution.so not loaded by AML"
    else
        local tries = 0
        while H.lib.HEXED_IsReady() ~= 1 and tries < 150 do wait(200); tries = tries + 1 end
        if H.lib.HEXED_IsReady() == 1 then
            H.pct[0] = H.lib.HEXED_GetScalePercent()
            if H.pct[0] < 0 or H.pct[0] > 100 then H.pct[0] = 100 end
            H.w[0], H.h[0] = H.lib.HEXED_GetCurrentW(), H.lib.HEXED_GetCurrentH()
            H.status = H.lib.HEXED_WasSafeMode() == 1 and "Safe mode: last setting crashed the game, it was cleared"
                or ((H.lib.HEXED_GetScaleOverride() == 1 or H.lib.HEXED_GetOverride() == 1) and "Ready (saved setting active)" or "Ready")
        else H.status = "Game never became ready - see logcat HEXED_Resolution" end
    end
    print("[HEXED Resolution] " .. H.status .. (path and (" [" .. path .. "]") or ""))
    sampRegisterChatCommand("hxdres", function() H.open[0] = not H.open[0]; imgui.Process = true end)
    sampRegisterChatCommand("hxdres_pct", function(a)
        local p = tonumber(a); if p then applyScale(math.floor(p)) else sampAddChatMessage("Usage: /hxdres_pct 0-100", -1) end
    end)
    sampRegisterChatCommand("hxdres_set", function(a)
        local w, h = tostring(a):match("(%d+)%D+(%d+)")
        if w then applyWindow(tonumber(w), tonumber(h)) else sampAddChatMessage("Usage: /hxdres_set 1280 720 (experimental)", -1) end
    end)
    sampRegisterChatCommand("hxdres_reset", function() resetScale(); resetWindow() end)
    sampRegisterChatCommand("hxdres_center", function(a)
        local v = tostring(a):match("%d")
        if v then applyCenter(v ~= "0") else applyCenter(H.lib and H.lib.HEXED_GetCenter() ~= 1) end
    end)
    sampRegisterChatCommand("hxdres_fit", function(a)
        local v = tostring(a):match("%d")
        if v then applyFit(v == "1" and 1 or 0) else applyFit(H.lib and H.lib.HEXED_GetFitMode() == 1 and 0 or 1) end
    end)
    local frame, lastOpen = 0, nil
    while true do
        wait(0); imgui.Process = H.open[0]
        frame = frame + 1
        if H.lib then
            if frame % 30 == 0 then H.lib.HEXED_Tick() end
            if lastOpen ~= H.open[0] then lastOpen = H.open[0]; H.lib.HEXED_SetMenuOpen(lastOpen and 1 or 0) end
        end
        if H.pending then
            local p = H.pending; H.pending = nil
            if     p.kind == "scale"        then realScale(p.a)
            elseif p.kind == "scale_reset"  then realScaleReset()
            elseif p.kind == "window"       then realWindow(p.a, p.b)
            elseif p.kind == "center"       then realCenter(p.a)
            elseif p.kind == "fit"          then realFit(p.a)
            else                                 realWindowReset() end
        end
    end
end

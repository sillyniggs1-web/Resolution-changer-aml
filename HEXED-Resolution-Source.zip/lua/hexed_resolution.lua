--[[
    HEXED Resolution – MonetLoader menu
    For SA-MP Nezuko v1.0.3 (TESTING) + AML

    Place this file in the MonetLoader scripts folder, typically:
      /sdcard/Android/media/<package>/monetloader/
      or the path your client uses for .lua scripts

    The native library libHEXED_Resolution.so must be loaded by AML first
    (put it in the mods folder).  The script will try to locate the
    exported C functions.
]]

script_name("HEXED Resolution")
script_author("HEXED starter")
script_version("0.1.0-beta")

local ffi = require("ffi")
local memory = require("memory")  -- MonetLoader / SAMemory style if available

-- ---------------------------------------------------------------------------
-- Try to bind the native exports
-- ---------------------------------------------------------------------------
local native = nil
local native_ok = false

local function try_load_native()
    -- MonetLoader on this client can load additional .so files.
    -- Common locations for AML mods:
    local candidates = {
        "libHEXED_Resolution.so",
        "/sdcard/Android/data/com.nezukosamp.game/mods/libHEXED_Resolution.so",
        "/sdcard/Android_unprotected/data/com.nezukosamp.game/mods/libHEXED_Resolution.so",
        "/sdcard/Android/data/com.rockstargames.gtasa/mods/libHEXED_Resolution.so",
    }

    for _, path in ipairs(candidates) do
        local ok, lib = pcall(ffi.load, path)
        if ok and lib then
            native = lib
            native_ok = true
            print("[HEXED] Native library loaded from " .. path)
            break
        end
    end

    if not native_ok then
        print("[HEXED] WARNING: could not load libHEXED_Resolution.so")
        print("[HEXED] Menu will show values but Apply/Reset will be disabled")
        return
    end

    -- Declare the C API we exported
    ffi.cdef[[
        int HEXED_GetCurrentWidth();
        int HEXED_GetCurrentHeight();
        int HEXED_GetOriginalWidth();
        int HEXED_GetOriginalHeight();
        int HEXED_IsApplied();
        int HEXED_Apply(int width, int height);
        int HEXED_Reset();
        int HEXED_SaveSettings(int width, int height);
        int HEXED_LoadSettings(int* outW, int* outH);
    ]]
end

try_load_native()

-- ---------------------------------------------------------------------------
-- Presets (safe starting set)
-- ---------------------------------------------------------------------------
local presets = {
    { name = "Native / Reset", w = 0, h = 0 },          -- special
    { name = "960 x 540",     w = 960,  h = 540 },
    { name = "1280 x 720",    w = 1280, h = 720 },
    { name = "1600 x 900",    w = 1600, h = 900 },
    { name = "1920 x 1080",   w = 1920, h = 1080 },
    { name = "854 x 480",     w = 854,  h = 480 },
    { name = "640 x 360",     w = 640,  h = 360 },
}

local custom_w = 1280
local custom_h = 720
local selected_preset = 1
local menu_visible = false
local last_status = "Ready"

local function get_current()
    if native_ok then
        return native.HEXED_GetCurrentWidth(), native.HEXED_GetCurrentHeight()
    end
    return 0, 0
end

local function get_original()
    if native_ok then
        return native.HEXED_GetOriginalWidth(), native.HEXED_GetOriginalHeight()
    end
    return 0, 0
end

local function apply_res(w, h)
    if not native_ok then
        last_status = "Native library not loaded"
        return
    end
    if w == 0 and h == 0 then
        if native.HEXED_Reset() == 1 then
            last_status = "Reset to original"
        else
            last_status = "Reset failed"
        end
        return
    end
    if native.HEXED_Apply(w, h) == 1 then
        last_status = string.format("Applied %d x %d", w, h)
        native.HEXED_SaveSettings(w, h)
    else
        last_status = string.format("Rejected %d x %d", w, h)
    end
end

-- ---------------------------------------------------------------------------
-- Simple ImGui-style menu (works with MonetLoader's mimgui or basic text)
-- Falls back to chat commands if mimgui is unavailable
-- ---------------------------------------------------------------------------
local has_mimgui = false
local imgui = nil

pcall(function()
    imgui = require("mimgui")
    has_mimgui = true
end)

if has_mimgui then
    local newFrame = imgui.OnFrame()
    local winFlags = imgui.WindowFlags.NoCollapse + imgui.WindowFlags.AlwaysAutoResize

    newFrame.OnFrame = function()
        if not menu_visible then return end

        local cw, ch = get_current()
        local ow, oh = get_original()

        imgui.Begin("HEXED Resolution (beta)", true, winFlags)

        imgui.Text(string.format("Current : %d x %d", cw, ch))
        imgui.Text(string.format("Original: %d x %d", ow, oh))
        imgui.Text("Status  : " .. last_status)
        imgui.Separator()

        imgui.Text("Presets:")
        for i, p in ipairs(presets) do
            if imgui.Button(p.name, imgui.ImVec2(160, 0)) then
                if p.w == 0 then
                    apply_res(0, 0)
                else
                    apply_res(p.w, p.h)
                end
            end
            if i % 2 == 1 then imgui.SameLine() end
        end

        imgui.Separator()
        imgui.Text("Custom:")
        local changedW, newW = imgui.InputInt("Width", custom_w, 16, 64)
        if changedW then custom_w = newW end
        local changedH, newH = imgui.InputInt("Height", custom_h, 16, 64)
        if changedH then custom_h = newH end

        if imgui.Button("Apply Custom", imgui.ImVec2(120, 0)) then
            apply_res(custom_w, custom_h)
        end
        imgui.SameLine()
        if imgui.Button("Reset", imgui.ImVec2(80, 0)) then
            apply_res(0, 0)
        end

        imgui.Separator()
        imgui.TextWrapped("WARNING: This only writes RsGlobal + renderWidth/Height. HUD, touch and true render-target size may still be wrong. Beta only.")

        imgui.End()
    end
end

-- ---------------------------------------------------------------------------
-- Chat commands (always available)
-- ---------------------------------------------------------------------------
function main()
    print("[HEXED] Resolution script loaded")
    if not native_ok then
        print("[HEXED] Native .so not found – place libHEXED_Resolution.so in the AML mods folder")
    end

    while true do
        wait(0)

        -- Toggle menu (default: /hexed)
        if wasKeyPressed(0x71) then -- F2 as alternative
            menu_visible = not menu_visible
        end
    end
end

-- Register commands
cmd = require("mcmd") or {}   -- some MonetLoader builds expose this
if type(cmd) == "table" and cmd.add then
    cmd.add("hexed", function()
        menu_visible = not menu_visible
        print("[HEXED] Menu " .. (menu_visible and "opened" or "closed"))
    end)

    cmd.add("hexed_apply", function(w, h)
        w = tonumber(w) or 0
        h = tonumber(h) or 0
        apply_res(w, h)
        print("[HEXED] " .. last_status)
    end)

    cmd.add("hexed_reset", function()
        apply_res(0, 0)
        print("[HEXED] " .. last_status)
    end)
else
    -- Fallback: simple samp events if available
    if sampGetCurrentServerName then
        -- classic SAMP.lua style
        function sampev.onSendCommand(cmd)
            if cmd == "/hexed" then
                menu_visible = not menu_visible
                print("[HEXED] Menu toggled")
                return false
            end
        end
    end
end

print("[HEXED] Commands: /hexed  |  /hexed_apply <w> <h>  |  /hexed_reset")
print("[HEXED] Or press F2 to toggle the menu (if mimgui is present)")
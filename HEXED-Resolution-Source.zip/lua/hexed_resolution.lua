script_name("Hexed Resolution")
script_author("HEXED Studio")
script_version("1.0.2")
require "lib.moonloader"
local imgui = require("mimgui")
local ffi   = require("ffi")
local bit   = require("bit")
local DPI   = MONET_DPI_SCALE or 1

-- One table for all state (LuaJIT: 200 locals / 60 upvalues limit)
local H = {
    lib = nil, status = "Starting...", open = imgui.new.bool(false), pending = nil, tab = 1,
    pct = imgui.new.int(75), w = imgui.new.int(1280), h = imgui.new.int(720),
}
local HEIGHT_PRESETS = { 1080, 900, 720, 540, 480 }
local TABS = { "Resolution", "Touch", "Status" }

ffi.cdef[[
    int HEXED_Tick(); int HEXED_IsReady(); int HEXED_GetMode(); int HEXED_GetOverride(); int HEXED_WasSafeMode();
    int HEXED_GetNativeW(); int HEXED_GetNativeH(); int HEXED_GetActiveW(); int HEXED_GetActiveH();
    int HEXED_GetScalePercent(); int HEXED_PercentToWidth(int p); int HEXED_PercentToHeight(int p); int HEXED_HeightToWidth(int h);
    int HEXED_SetScale(int p); int HEXED_SetHeight(int h); int HEXED_SetSize(int w, int h); int HEXED_Reset();
    int HEXED_SetTouchRemap(int on); int HEXED_GetTouchRemap();
    int HEXED_GetMinW(); int HEXED_GetMinH(); int HEXED_GetMaxSide(); int HEXED_GetInfo(int idx);
    const char* HEXED_GetError();
]]

-- AML already loaded the .so into this process; find its real path in /proc/self/maps
local function findLib()
    local ok, f = pcall(io.open, "/proc/self/maps", "r")
    if ok and f then
        for line in f:lines() do
            local p = line:match("(/%S*libHEXED_Resolution%.so)")
            if p then f:close(); local ok2, l = pcall(ffi.load, p); if ok2 then return l, p end end
        end
        f:close()
    end
    local ok3, l = pcall(ffi.load, "libHEXED_Resolution.so")
    if ok3 then return l, "libHEXED_Resolution.so" end
end

local function ready()
    if not H.lib then H.status = "Native mod not loaded"; return false end
    if H.lib.HEXED_Tick() ~= 1 then H.status = "Game not ready yet, try again in a moment"; return false end
    return true
end

local function describe()
    local L = H.lib
    if L.HEXED_GetOverride() == 1 then
        return ("Rendering %d x %d (screen %d x %d)"):format(L.HEXED_GetActiveW(), L.HEXED_GetActiveH(), L.HEXED_GetNativeW(), L.HEXED_GetNativeH())
    end
    return ("Native resolution (%d x %d)"):format(L.HEXED_GetNativeW(), L.HEXED_GetNativeH())
end

-- Real work runs on the game's script thread (main loop), never inside the draw callback.
local function runPending(p)
    if not ready() then return end
    local L, ok = H.lib, 0
    print(("[HEXED Resolution] %s %s %s"):format(p.kind, tostring(p.a), tostring(p.b)))
    if     p.kind == "scale"  then ok = L.HEXED_SetScale(p.a)
    elseif p.kind == "height" then ok = L.HEXED_SetHeight(p.a)
    elseif p.kind == "size"   then ok = L.HEXED_SetSize(p.a, p.b)
    elseif p.kind == "touch"  then ok = L.HEXED_SetTouchRemap(p.a and 1 or 0)
    else                           ok = L.HEXED_Reset() end
    if ok == 1 then
        H.status = (p.kind == "touch") and (p.a and "Touch remap: ON" or "Touch remap: OFF") or describe()
    else
        H.status = "Failed: " .. ffi.string(L.HEXED_GetError())
    end
end

local function queue(kind, a, b) H.pending = { kind = kind, a = a, b = b }; H.status = "Applying ..." end

local function shapeDiffers(w, h)
    local nw, nh = H.lib.HEXED_GetNativeW(), H.lib.HEXED_GetNativeH()
    if nw <= 0 or nh <= 0 or h <= 0 then return false end
    return math.abs(w / h - nw / nh) > 0.02
end

imgui.OnInitialize(function()
    local s = imgui.GetStyle(); local c = s.Colors
    s.WindowRounding = 10; s.FrameRounding = 6; s.ChildRounding = 8; s.WindowBorderSize = 1
    c[imgui.Col.WindowBg]      = imgui.ImVec4(0.02, 0.03, 0.07, 0.96)
    c[imgui.Col.ChildBg]       = imgui.ImVec4(0.03, 0.05, 0.11, 1.00)
    c[imgui.Col.Border]        = imgui.ImVec4(0.10, 0.35, 0.85, 1.00)
    c[imgui.Col.FrameBg]       = imgui.ImVec4(0.05, 0.08, 0.18, 1.00)
    c[imgui.Col.Button]        = imgui.ImVec4(0.08, 0.25, 0.65, 1.00)
    c[imgui.Col.ButtonHovered] = imgui.ImVec4(0.12, 0.38, 0.90, 1.00)
    c[imgui.Col.ButtonActive]  = imgui.ImVec4(0.06, 0.20, 0.55, 1.00)
    c[imgui.Col.SliderGrab]    = imgui.ImVec4(0.15, 0.45, 1.00, 1.00)
end)

local function touchScroll()
    if imgui.IsWindowHovered() and imgui.IsMouseDown(0) and not imgui.IsAnyItemActive() then
        imgui.SetScrollY(imgui.GetScrollY() - imgui.GetIO().MouseDelta.y)
    end
end

local function widthLong() imgui.PushItemWidth(imgui.GetContentRegionAvail().x - 110 * DPI) end

local function row(labels, fn)
    local bw = (imgui.GetContentRegionAvail().x - 8 * DPI * (#labels - 1)) / #labels
    for i, l in ipairs(labels) do
        if imgui.Button(l[1], imgui.ImVec2(bw, 34 * DPI)) then fn(l[2]) end
        if i < #labels then imgui.SameLine() end
    end
end

local function tabResolution(L)
    local nw, nh = L.HEXED_GetNativeW(), L.HEXED_GetNativeH()
    imgui.Text(("Screen: %d x %d"):format(nw, nh))
    imgui.TextColored(imgui.ImVec4(0.35, 0.75, 1, 1), describe())
    imgui.Separator()

    imgui.TextColored(imgui.ImVec4(0.35, 0.75, 1, 1), "Render height (keeps the screen shape)")
    local lab = {}
    for _, hh in ipairs(HEIGHT_PRESETS) do
        if hh < nh then lab[#lab + 1] = { hh .. "p", hh } end
    end
    if #lab > 0 then row(lab, function(v) queue("height", v) end) end
    imgui.TextDisabled("Width is derived from your screen, so nothing is stretched.")

    imgui.Separator()
    imgui.TextColored(imgui.ImVec4(0.35, 0.75, 1, 1), "Scale of native size")
    widthLong()
    imgui.SliderInt("Scale##pct", H.pct, 25, 100, "%d%%")
    imgui.PopItemWidth()
    imgui.Text(("Renders at %d x %d"):format(L.HEXED_PercentToWidth(H.pct[0]), L.HEXED_PercentToHeight(H.pct[0])))
    if imgui.Button("Apply scale", imgui.ImVec2(-1, 34 * DPI)) then queue("scale", H.pct[0]) end

    imgui.Separator()
    imgui.TextColored(imgui.ImVec4(1, 0.7, 0.3, 1), "Custom size")
    widthLong()
    imgui.InputInt("Width##cw", H.w); imgui.InputInt("Height##ch", H.h)
    imgui.PopItemWidth()
    if shapeDiffers(H.w[0], H.h[0]) then
        imgui.TextColored(imgui.ImVec4(1, 0.5, 0.3, 1), "Different shape than the screen: the picture will be stretched.")
    end
    if imgui.Button("Apply custom", imgui.ImVec2(-1, 34 * DPI)) then queue("size", H.w[0], H.h[0]) end

    imgui.Separator()
    if imgui.Button("Reset to native", imgui.ImVec2(-1, 38 * DPI)) then queue("reset") end
    imgui.TextWrapped("If a setting makes the game unusable, close the game within 10 seconds of starting it: the next launch resets to native.")
end

local function tabTouch(L)
    local on = L.HEXED_GetTouchRemap() == 1
    imgui.TextWrapped("Android sends touches in real screen pixels. When the game renders smaller, touches are scaled to the game's size so buttons, the camera and this menu stay under your finger.")
    if imgui.Button(on and "Touch remap: ON" or "Touch remap: OFF", imgui.ImVec2(-1, 38 * DPI)) then queue("touch", not on) end
    imgui.TextDisabled("Leave ON. Turn off only to compare behaviour.")
end

local function tabStatus(L)
    local mask = L.HEXED_GetInfo(0)
    local function flag(b) return bit.band(mask, b) ~= 0 and "OK" or "--" end
    imgui.Text(("Stage: %d (3 = full)   Mode: %d   Override: %d   Safe mode: %d"):format(L.HEXED_GetInfo(8), L.HEXED_GetMode(), L.HEXED_GetOverride(), L.HEXED_WasSafeMode()))
    imgui.Text(("Hook setWindowSize: %s"):format(flag(1)))
    imgui.Text(("Hook touchEvent: %s   multiTouch: %s"):format(flag(2), flag(4)))
    imgui.Text(("Activity: %s   Config dir: %s"):format(L.HEXED_GetInfo(1) == 1 and "OK" or "--", L.HEXED_GetInfo(7) == 1 and "OK" or "--"))
    imgui.Text(("View: %d x %d"):format(L.HEXED_GetInfo(4), L.HEXED_GetInfo(5)))
    imgui.Text(("Java resize calls: %d   Touch calls: %d   Buffer sets: %d"):format(L.HEXED_GetInfo(2), L.HEXED_GetInfo(3), L.HEXED_GetInfo(6)))
    local e = ffi.string(L.HEXED_GetError())
    if e ~= "" then imgui.TextWrapped("Last error: " .. e) end
    imgui.TextDisabled("Log: Android/data/<game>/files/hexed_resolution.log")
end

imgui.OnFrame(function() return H.open[0] end, function()
    local io, L = imgui.GetIO(), H.lib
    local ww = math.min(560 * DPI, io.DisplaySize.x - 20 * DPI)
    local wh = math.min(430 * DPI, io.DisplaySize.y - 20 * DPI)
    imgui.SetNextWindowPos(imgui.ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
    imgui.SetNextWindowSize(imgui.ImVec2(ww, wh), imgui.Cond.FirstUseEver)
    local flags = bit.bor(imgui.WindowFlags.NoTitleBar, imgui.WindowFlags.NoCollapse, imgui.WindowFlags.NoScrollbar)
    imgui.Begin("##hxdres", H.open, flags)

    imgui.SetWindowFontScale(1.4)
    local title = "HEXED RESOLUTION"
    imgui.SetCursorPosX((imgui.GetWindowWidth() - imgui.CalcTextSize(title).x) / 2)
    imgui.TextColored(imgui.ImVec4(0.35, 0.75, 1, 1), title)
    imgui.SetWindowFontScale(1.0)
    imgui.Separator()

    imgui.BeginChild("##tabs", imgui.ImVec2(140 * DPI, -48 * DPI), false)
    for i, name in ipairs(TABS) do
        local active = (H.tab == i)
        if active then imgui.PushStyleColor(imgui.Col.Button, imgui.ImVec4(0.15, 0.45, 1.00, 1.00)) end
        if imgui.Button(name, imgui.ImVec2(130 * DPI, 35 * DPI)) then H.tab = i end
        if active then imgui.PopStyleColor() end
    end
    imgui.EndChild()
    imgui.SameLine()

    imgui.BeginChild("##content", imgui.ImVec2(0, -48 * DPI), true)
    touchScroll()
    if L and L.HEXED_IsReady() == 1 then
        if     H.tab == 1 then tabResolution(L)
        elseif H.tab == 2 then tabTouch(L)
        else                   tabStatus(L) end
    else
        imgui.Text(L and "Waiting for the game window..." or "Native mod not found")
    end
    imgui.EndChild()

    imgui.TextWrapped(H.status)
    if imgui.Button("Close", imgui.ImVec2(-1, 34 * DPI)) then H.open[0] = false end
    imgui.End()
end)

function main()
    while not isSampLoaded or not isSampLoaded() do wait(100) end
    local path
    H.lib, path = findLib()
    if not H.lib then H.status = "libHEXED_Resolution.so not loaded by AML"
    else
        local tries = 0
        while H.lib.HEXED_Tick() ~= 1 and tries < 150 do wait(200); tries = tries + 1 end
        if H.lib.HEXED_Tick() == 1 then
            local p = H.lib.HEXED_GetScalePercent()
            if p >= 25 and p <= 100 then H.pct[0] = p end
            H.w[0], H.h[0] = H.lib.HEXED_GetActiveW(), H.lib.HEXED_GetActiveH()
            if H.lib.HEXED_WasSafeMode() == 1 then H.status = "Safe mode: last session ended right after a change, it was reset"
            else H.status = describe() end
        elseif H.lib.HEXED_GetInfo(8) < 2 then
            H.status = ("Diagnostic stage %d: hooks are off after a failed start. See hexed_resolution.log"):format(H.lib.HEXED_GetInfo(8))
        else H.status = "Game never became ready - see hexed_resolution.log" end
    end
    print("[HEXED Resolution] " .. H.status .. (path and (" [" .. path .. "]") or ""))

    sampRegisterChatCommand("hxdres", function() H.open[0] = not H.open[0]; imgui.Process = true end)
    sampRegisterChatCommand("hxdres_pct", function(a)
        local p = tonumber(a); if p then queue("scale", math.floor(p)) else sampAddChatMessage("Usage: /hxdres_pct 25-100", -1) end
    end)
    sampRegisterChatCommand("hxdres_h", function(a)
        local v = tonumber(a); if v then queue("height", math.floor(v)) else sampAddChatMessage("Usage: /hxdres_h 720", -1) end
    end)
    sampRegisterChatCommand("hxdres_set", function(a)
        local w, h = tostring(a):match("(%d+)%D+(%d+)")
        if w then queue("size", tonumber(w), tonumber(h)) else sampAddChatMessage("Usage: /hxdres_set 1280 720", -1) end
    end)
    sampRegisterChatCommand("hxdres_reset", function() queue("reset") end)
    sampRegisterChatCommand("hxdres_touch", function(a)
        local v = tostring(a):match("%d")
        if v then queue("touch", v ~= "0") else queue("touch", H.lib and H.lib.HEXED_GetTouchRemap() ~= 1) end
    end)

    local frame = 0
    while true do
        wait(0); imgui.Process = H.open[0]
        frame = frame + 1
        if H.lib and frame % 30 == 0 then H.lib.HEXED_Tick() end
        if H.pending then
            local p = H.pending; H.pending = nil
            runPending(p)
        end
    end
end

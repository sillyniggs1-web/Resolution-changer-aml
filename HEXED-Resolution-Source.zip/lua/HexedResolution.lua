--[[
    HEXED Resolution — Lua menu for SA-MP mobile clients (AML native plugin)

    This script is the in-game front end for the HEXED Resolution native AML
    plugin (libHexedResolution.so). It does NOT change Android system display
    settings — it talks to the native plugin only.

    HOW IT CONNECTS
    ---------------
    The plugin exposes a file-based command bridge at:

        <game external files>/hexed/bridge_cmd.txt   (script -> plugin)
        <game external files>/hexed/bridge_out.txt   (plugin -> script)

    Standard Lua `io` is the only hard requirement, so this works with any
    client Lua runtime. SA-MP client APIs (chat output / chat commands /
    dialogs) are OPTIONAL and probed at runtime — the script never assumes a
    function exists; if the client does not provide one, the menu degrades
    gracefully instead of erroring.

    MENU
    ----
    With a chat-command capable runtime:  /hres [args]  (type /hres for help)
    Without one:                          hexed_command("...") from the console,
                                          or edit bridge_cmd.txt manually.

    This file is part of HEXED Resolution. License: MIT (see LICENSES.md).
--]]

local VERSION = "1.0.0"

-- ============================================================================
-- Configuration
-- ============================================================================

-- Candidate locations of the plugin bridge directory. The first existing
-- candidate containing bridge_out.txt wins. Adjust the first entry if your
-- client uses a different package name.
local CANDIDATE_DIRS = {
    "/storage/emulated/0/Android/data/com.rockstargames.gtasa/files/hexed",
    "/sdcard/Android/data/com.rockstargames.gtasa/files/hexed",
    "/storage/emulated/0/Android/data/com.rockstargames.gtasa/mods/hexed",
}

local POLL_TRIES   = 12     -- response poll attempts after a command
local POLL_DELAY   = function() end  -- replaced with wait() when threading exists

-- HEXED identity (dark / blue / white)
local C_TITLE  = "{3D9BFF}"
local C_TEXT   = "{FFFFFF}"
local C_DIM    = "{9AA7B4}"
local C_OK     = "{39D353}"
local C_WARN   = "{FFB020}"
local C_ERR    = "{FF5252}"

-- ============================================================================
-- Limits (mirrored by the native side; the plugin validates again)
-- ============================================================================

local MIN_DIM = 128
local MAX_DIM = 7680

local PRESETS = {
    { key = "1", name = "p720", w = 1280, h = 720, label = "1280 x 720  (720p class)" },
    { key = "2", name = "p540", w = 960,  h = 540, label = "960 x 540   (balanced)" },
    { key = "3", name = "p450", w = 800,  h = 450, label = "800 x 450   (performance)" },
}

-- ============================================================================
-- Client API detection (never assume; probe everything)
-- ============================================================================

local function has(fn) return type(_G[fn]) == "function" end

local API = {
    chat    = has("sampAddChatMessage"),
    command = has("sampRegisterChatCommand"),
    thread  = has("lua_thread") or type(lua_thread) == "table",
    wait    = has("wait"),
}

-- ============================================================================
-- Output helpers
-- ============================================================================

local function out(msg)
    if API.chat then
        sampAddChatMessage(msg, -1)
    else
        print(msg and msg:gsub("%b{}", "") or "")
    end
end

local function say(color, msg) out(color .. msg) end

-- ============================================================================
-- File bridge
-- ============================================================================

local DIR = nil
local CMD_PATH, OUT_PATH = nil, nil

local function detect_dir()
    for _, dir in ipairs(CANDIDATE_DIRS) do
        local probe = dir .. "/bridge_out.txt"
        local f = io.open(probe, "r")
        if f then
            local first = f:read("*l") or ""
            f:close()
            if first:find("HEXED") then
                return dir
            end
            return dir -- exists even if not the expected banner; trust order
        end
    end
    return nil
end

local function read_out()
    local f = io.open(OUT_PATH, "r")
    if not f then return {} end
    local lines = {}
    for line in f:lines() do
        if line and #line > 0 then lines[#lines + 1] = line end
    end
    f:close()
    -- consume
    local w = io.open(OUT_PATH, "w")
    if w then w:close() end
    return lines
end

local function send(cmd)
    if not DIR then
        say(C_ERR, "HEXED: bridge not found. Is libHexedResolution.so installed?")
        return false
    end
    -- clear previous output
    local w = io.open(OUT_PATH, "w")
    if w then w:close() end
    local f = io.open(CMD_PATH, "w")
    if not f then
        say(C_ERR, "HEXED: cannot write " .. tostring(CMD_PATH))
        return false
    end
    f:write(cmd, "\n")
    f:close()
    return true
end

-- Parse one response line: CMD|CODE|w|h|text
local function parse_resp(line)
    local cmd, code, w, h, text = line:match("^(%S+)|(%S+)|(-?%d+)|(-?%d+)|(.*)$")
    if not cmd then return nil end
    return { cmd = cmd, code = code, w = tonumber(w) or 0, h = tonumber(h) or 0, text = text }
end

local function code_color(code)
    if code == "OK" or code == "QUEUED" then return C_OK end
    if code == "INVALID" or code == "DISABLED" or code == "INFO" then return C_WARN end
    return C_ERR
end

-- Send + wait for the matching response (works with or without coroutine wait)
local function request(cmd)
    if not send(cmd) then return nil end
    for _ = 1, POLL_TRIES do
        if API.wait then wait(100) end
        local lines = read_out()
        for _, line in ipairs(lines) do
            local r = parse_resp(line)
            if r and r.cmd == cmd:match("^(%S+)") then return r end
        end
    end
    say(C_ERR, "HEXED: no response from plugin (timeout)")
    return nil
end

local function show_resp(r, prefix)
    if not r then return end
    say(code_color(r.code), string.format("%s[%s] %s", prefix or "", r.code, r.text))
end

-- ============================================================================
-- Validation (mirrors native rules)
-- ============================================================================

local function validate_dims(w, h)
    if type(w) ~= "number" or type(h) ~= "number" or w ~= math.floor(w) or h ~= math.floor(h) then
        return false, "width and height must be integers"
    end
    if w < MIN_DIM or h < MIN_DIM then
        return false, "minimum dimension is " .. MIN_DIM
    end
    if w > MAX_DIM or h > MAX_DIM then
        return false, "maximum dimension is " .. MAX_DIM
    end
    local aspect = h / w
    if aspect < 0.40 or aspect > 2.80 then
        return false, "aspect ratio outside supported range (0.40 .. 2.80)"
    end
    return true
end

-- ============================================================================
-- Menu actions
-- ============================================================================

local function banner()
    out("")
    say(C_TITLE, "== HEXED Resolution v" .. VERSION .. " ==")
end

local function menu()
    banner()
    say(C_TEXT,  "Presets:")
    for _, p in ipairs(PRESETS) do
        say(C_DIM, "  /hres " .. p.key .. "   " .. p.label)
    end
    say(C_DIM,   "  /hres custom <w> <h>   custom resolution")
    say(C_TEXT,  "Control:")
    say(C_DIM,   "  /hres apply            apply the selected preset")
    say(C_DIM,   "  /hres reset            restore original resolution")
    say(C_DIM,   "  /hres save             persist the selection")
    say(C_DIM,   "  /hres restore          apply the saved selection")
    say(C_DIM,   "  /hres enable on|off    master switch")
    say(C_DIM,   "  /hres status           current rendering state")
    say(C_DIM,   "  /hres probe            detailed renderer probe")
    say(C_DIM,   "  /hres last             result of the most recent command")
    say(C_DIM,   "  /hres log [n]          recent plugin log lines")
    say(C_DIM,   "  /hres help             this help")
    out("")
end

local selected = nil   -- { name = ..., w = ..., h = ... }

local function do_preset(idx)
    local p = PRESETS[idx]
    if not p then return end
    selected = { name = p.name, w = p.w, h = p.h }
    say(C_TITLE, string.format("HEXED: preset %s (%dx%d) selected — now use /hres apply", p.name, p.w, p.h))
end

local function do_custom(w, h)
    w, h = tonumber(w), tonumber(h)
    local ok, why = validate_dims(w, h)
    if not ok then
        say(C_ERR, "HEXED: " .. tostring(why))
        return
    end
    selected = { name = "custom", w = w, h = h }
    say(C_TITLE, string.format("HEXED: custom %dx%d selected — now use /hres apply", w, h))
end

local function do_apply()
    if not selected then
        say(C_WARN, "HEXED: nothing selected. Pick a preset first (/hres).")
        return
    end
    show_resp(request(string.format("apply %d %d %s", selected.w, selected.h, selected.name)), "HEXED: ")
end

local function do_reset()
    show_resp(request("reset"), "HEXED: ")
end

local function do_save()
    if not selected then
        say(C_WARN, "HEXED: nothing selected to save.")
        return
    end
    show_resp(request(string.format("save %d %d %s", selected.w, selected.h, selected.name)), "HEXED: ")
end

local function do_restore()
    show_resp(request("restore"), "HEXED: ")
end

local function do_enable(arg)
    local on = (arg ~= "off" and arg ~= "0" and arg ~= "false")
    show_resp(request("enable " .. (on and "1" or "0")), "HEXED: ")
end

local function do_status()
    show_resp(request("status"), "HEXED: ")
end

local function do_probe()
    show_resp(request("probe"), "HEXED: ")
end

local function do_log(n)
    show_resp(request("log " .. tostring(tonumber(n) or 8)), "HEXED: ")
end

-- ============================================================================
-- Command dispatcher
-- ============================================================================

local function dispatch(argline)
    local args = {}
    for a in (argline or ""):gmatch("%S+") do args[#args + 1] = a end
    local cmd = (args[1] or "menu"):lower()

    if cmd == "menu" or cmd == "help" then menu()
    elseif cmd == "1" then do_preset(1)
    elseif cmd == "2" then do_preset(2)
    elseif cmd == "3" then do_preset(3)
    elseif cmd == "custom" then do_custom(args[2], args[3])
    elseif cmd == "apply" then do_apply()
    elseif cmd == "reset" then do_reset()
    elseif cmd == "save" then do_save()
    elseif cmd == "restore" then do_restore()
    elseif cmd == "enable" then do_enable(args[2])
    elseif cmd == "status" then do_status()
    elseif cmd == "probe" then do_probe()
    elseif cmd == "last" then show_resp(request("last"), "HEXED: ")
    elseif cmd == "log" then do_log(args[2])
    else
        say(C_ERR, "HEXED: unknown sub-command '" .. cmd .. "' — /hres help")
    end
end

-- ============================================================================
-- Startup
-- ============================================================================

local function startup()
    DIR = detect_dir()
    if DIR then
        CMD_PATH = DIR .. "/bridge_cmd.txt"
        OUT_PATH = DIR .. "/bridge_out.txt"
    end

    banner()
    if not DIR then
        say(C_ERR, "HEXED: bridge directory not found — check CANDIDATE_DIRS in this file")
        say(C_DIM, "  expected: <game files>/hexed/  created by libHexedResolution.so")
        return
    end
    say(C_DIM, "  bridge: " .. DIR)

    if API.command then
        sampRegisterChatCommand("hres", dispatch)
        say(C_OK, "HEXED: menu ready — type /hres")
    else
        say(C_WARN, "HEXED: sampRegisterChatCommand not available in this runtime.")
        say(C_DIM,   "  use hexed_command('<args>') from the console, or write")
        say(C_DIM,   "  commands directly into " .. tostring(CMD_PATH))
        _G.hexed_command = dispatch
    end
end

-- Run now, or via the client's script-load event when available.
if type(addEventHandler) == "function" and type(onScriptLoad) == "table" then
    addEventHandler("onScriptLoad", startup)
else
    startup()
end

return {
    version = VERSION,
    dispatch = dispatch,
    request = request,
}

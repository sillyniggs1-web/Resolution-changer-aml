# SA-MP Nezuko v1.0.3 TESTING (armeabi-v7a) - how resolution really works

All addresses are from `libGTASA.so` of the APK (md5 cba51176474c7b3e88801bc3d1d8112a). Static analysis only.

## 1. The coordinate contract
`touch pixels == windowSize == real EGL surface size`. Everything below assumes it.

| Piece | Evidence |
|---|---|
| Touch is raw Android pixels | Java `onTouchEvent` passes `MotionEvent.getX/getY` unscaled; `AND_TouchEvent` (0x2697c0) stores them as-is |
| Screen size = `windowSize` (exported, 2 ints) | `OS_ScreenGetWidth/Height` (0x268d3c/4c) read it; `ProcessEvents` event type 6 writes it |
| Window size is set from Java | `surfaceChanged -> setGameWindowSize -> native setWindowSize (0x273e3c) -> NVEventPostEvent({6,w,h}) (0x27c4f0)` |
| Startup ignores size | `OS_ApplicationStartup(w,h,..)` (0x5e5288) never uses its arguments |
| Live consumers of `windowSize` | CAdjustableHUD (touch HUD layout), CDraw::CalculateAspectRatio, CSprite::CalcScreenCoors, emu_glViewport, rqTargetSelect/Scissor, `_rwOpenGLSystem` video-mode info, Idle() |
| `RsGlobal.maximumWidth/Height` is NOT the screen | `RsEventHandler` init writes `{640, 480, 30, 0}` at RsGlobal+4; it is the 2D virtual space and nothing updates it |
| Default framebuffer viewport | `RQ_Command_rqTargetSelect` (0x1d0f50): `glViewport(0,0,OS_ScreenGetWidth(),OS_ScreenGetHeight())` |

## 2. The engine's own resolution scale (what mode 1 uses)
`Idle()` (every frame) reads `MobileSettings::settings + 0x28` (int 0..100; entry stride 0x20, value at +8):
```
w = 640 + (OS_ScreenGetWidth() - 640) * pct / 100      (MobileSettings::GetMaxResWidth() == OS_ScreenGetWidth())
h = OS_ScreenGetHeight() * w / OS_ScreenGetWidth()
w, h rounded up to a multiple of 4
emu_SetAltRenderTarget(w, h)   (0,0 in menus/fades)
```
`emu_SetAltRenderTarget` stores w,h in `renderWidth/renderHeight` (a copy, never the screen size), returns early if unchanged,
and `emu_glViewport` maps screen coordinates with `x * renderWidth / OS_ScreenGetWidth()`.
`emu_FlushAltRenderTarget` (0x1bc28c) stretches the target to the full surface. Touch, HUD and aspect never change.
`MobileSettings::Initialize` defaults the value from the device; `Menu_LoadSettings` can overwrite it (the mod re-asserts).

## 3. Why spoofing `windowSize` (mode 2) is experimental
Posting event 6 changes only the number. The EGL surface keeps its size and Android keeps sending touches in real pixels,
so the viewport, HUD layout and touch can disagree (crop / letterbox / offset controls). Making it fully consistent also needs
a real buffer-size change on the UI thread (`SurfaceHolder.setFixedSize`; the game only does this on Shield TV) plus touch rescaling.

## 4. Other findings
- `libsamp.so` installs its own signal handler (`sigaction` + `sigaltstack`); the mod's crash recorder chains and re-installs.
- `libsamp.so` logs `RsGlobal` width/height as "Resolution", i.e. 640x480 virtual, not the screen.
- No Nezuko library references `emu_SetAltRenderTarget`, `windowSize` or `OS_ScreenGet*` by name.
- The reference "Zen Menu" shows HUD resizing and letterboxing, which matches a window-size change, not a render scale.

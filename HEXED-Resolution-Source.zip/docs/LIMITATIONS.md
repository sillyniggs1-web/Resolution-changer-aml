# HEXED Resolution 3.0.0 - notes

## Method
Same path Android uses when the surface changes (verified in libGTASA.so of Nezuko 1.0.3):
`NvEventQueueActivity.setWindowSize(w,h)` -> `NVEventPostEvent({6, w, h})` -> `ProcessEvents()` (main thread)
stores `windowSize = {w,h}`. `OS_ScreenGetWidth/Height` read it live and drive the touch HUD layout
(CAdjustableHUD), camera aspect (CDraw::CalculateAspectRatio), CSprite::CalcScreenCoors, glViewport,
render-target scissor/select and the render-target size in Idle().
This reproduces the reference "Zen Menu" behaviour (HUD resizes, aspect changes, letterboxing).

No code is hooked or patched. `NVEventPostEvent` is called at libGTASA+0x27c4f0 only after its first
14 bytes match; otherwise a single `strd` store into `windowSize` (what the event handler itself does).

## Safety limits
- Min 320x180, max side 2560 (render-target memory). Zero/negative sizes are never posted
  (the engine divides by the screen width).
- Android surface callbacks (resume, hideSystemUI, rotation) re-post the real size; a watcher
  re-applies your size within ~250 ms while an override is active.
- Default (native) restores the size seen when the game finished loading.

## Not verified (never run on a device)
- How the final blit looks when the requested size is larger than the real surface (the reference
  video shows 1920x1080 working on a 1612x720 device, but I could not trace that blit statically).
- Other mods that also resize the window (CLEO reads windowSize/RsGlobal but does not write it).
- Log tag `HEXED_Resolution`: expect "Using NVEventPostEvent (verified bytes)" then
  "Ready. native window WxH".

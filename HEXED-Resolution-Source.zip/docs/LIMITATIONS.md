# HEXED Resolution 4.0.0 - notes

## Modes
1. **Render resolution (recommended)** - writes the engine's own resolution setting (MobileSettings+0x28, 0..100).
   No hooks. Touch/HUD/aspect untouched. Max is native resolution. See ENGINE-ANALYSIS.md.
2. **Window size (experimental)** - posts the engine's window-resize event. Touch is not rescaled; the real
   surface is not resized. Use only to experiment. Min 320x180, max side 2560.
Modes are exclusive: choosing one clears the other.

## Safety / diagnostics
- Crash-loop guard: `apply.pending` is written before an apply and removed after 20 s stable. If it is still there
  at the next launch the saved setting is dropped (Safe mode). Closing the game within 20 s of applying also triggers it.
- Log: `Android/data/<game package>/files/HEXED/hexed_resolution.log` (steps, engine reaction, crash pc/lr with module+offset).
  The previous crash handler is chained; the game crashes exactly as before.
- Buttons queue the request; the script thread performs it, never the ImGui draw callback.

## Not verified (never run on a device)
- Visual quality/FPS of each percentage on your tablet.
- Whether the in-game settings screen's own resolution slider fights the override (the mod re-asserts every 250 ms).

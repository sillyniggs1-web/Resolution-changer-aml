# HEXED Resolution 1.0.10 - status and limitations

## 1.0.10: the MotionEvent itself is rebuilt (log of 1.0.9: integer coordinates were right, the game still used the unmapped position)
The 1.0.9 log shows both the Java proxy and the native hook turning window (597,346) into game (109,130) correctly, yet touches still behaved
as if the touch area sat at the window origin. Every earlier attempt (gate 1.0.7, proxy 1.0.8, hooks 1.0.9) changed only what `getX()`/the int
arguments return. `MotionEvent.transform()` leaves `getRawX()/getRawY()` untouched, and the natives also receive the event object, so anything
reading those saw window coordinates. Now `surface::BuildMappedEvent` builds a fresh event (MotionEvent.obtain from pointer arrays) where
getX == getRawX == the mapped value for every pointer; the Java callback path and both native hooks (touchEvent, multiTouchEvent) hand that
event to the game. If the rebuild is unavailable it falls back to the old transform copy (log: `touch: event rebuild NOT available`).
Also: the "real rectangle wins" fallback of 1.0.9 is gone (the log showed it firing before the layout had settled and picking (0,0)); the
centering rule is always used. The log now dumps the window's view hierarchy at the first and sixth touch (`view tree (...)`), so a touch
layout that is a Java view outside the padded content root can be identified by class name and position.

## 1.0.9: touch area computed with the centering rule (screenshot: touch layout still at the top-left)
Reading the 1.0.8 code, three things could leave the game's touch area at the window origin while the picture is centered:
1. The touch origin was a different quantity from the one that centered the picture: it was read back from the live SurfaceView
   (`getLocationInWindow`) on each pointer-down, while the picture was placed by `calc::CenterRect`. Now `RefreshGeometry` computes the
   rectangle with `calc::PictureRect` = `CenterRect` + the content root's window position, from the same inputs `ApplyLayout` uses
   (content size, box, `calc::HasBox`). It is also computed right after every layout, before any touch. The live view position is only
   compared (log line `geometry: ...`, Status tab); if the two ever disagree the picture's real rectangle is used so the touch area
   still lies on the picture.
2. The native touch hooks stood down whenever a Java touch path was merely installed (`gateOn`), so if touches reached the game some other
   way they were never mapped. Now the Java paths raise `g.mappedGesture` only while they hand an already-mapped event to the game, and the
   native hooks map everything else. One mapping per event, whichever path it takes.
3. If something replaced our Window.Callback after install it stayed unnoticed. `VerifyTouchPath` (UI thread, every ~2 s while an override is
   active) puts it back; the old proxy keeps forwarding to its own original (no loop).
Status tab (new lines) tells which of these is happening on a device: `Proxy saw N touches` (0 = the Java proxy is not on the touch path),
`Mapped N`, `Last touch: window -> game`, computed origin vs. the view position Android reports.
Verified on a PC: C++ syntax-checks against stub JNI/AML headers; `tests/calc_test.cpp` (PictureRect for the screenshot numbers, content inset,
rotated, no box, box larger than the content, screen centre == picture centre for 9 screens). NOT verified on a device.
If touch is still off, send `hexed_resolution.log` and a screenshot of the Status tab.

## 1.0.7 device test (screenshot): touch area still at the top-left -> 1.0.8 callback proxy
Screenshot (2000x1200 tablet, 1024x768 window): the picture is centered at (488,216) and the whole touch layout is at the screen's top-left,
with the finger in the left black bar still driving the game. Reading the code: the game's touch sink gets WINDOW coordinates, the picture
origin is (488,216), and nothing shifted them, i.e. the 1.0.7 gate (a listener on one SurfaceView / the content root) was not on the path
the touches really take. 1.0.8 moves the mapping to the one place every touch passes, `Window.Callback.dispatchTouchEvent` (proxy), keeps the
view tree in window coordinates and maps only the event that goes to the game. A layout-signature bug is fixed too: the same box on a different
screen size (rotation) was not re-centered because the screen size was not part of the signature.
Verified on a PC: DEX parses (3 classes), C++ compiles against stub headers, `tests/calc_test.cpp` (centering + mapping for 9 screen/box
combinations incl. the screenshot numbers, rotated screens, bars). NOT verified on a device: that `Proxy.newProxyInstance` + `Window.setCallback`
are accepted by this client, and that the game's `onTouchEvent` is the sink (if the Activity overrides `dispatchTouchEvent` the plugin detects it and
sends the mapped event there instead; the log prints `Activity overrides dispatchTouchEvent: 0|1`).
If touch is still wrong, send `hexed_resolution.log`: the lines `touch: Window.Callback proxy installed`, `layout: ... touch path ...` and the first
`touch(cb) window ... -> ...` lines say which path ran and what it computed.

## Report from device tests
- 1.0.0: game did not start (no log).
- 1.0.1 log + AML crash log (Honor HNELN-Q, Android 13, armeabi-v7a): SIGSEGV in `memcmp`, R0=0xFFFFFFFF, right after
  `step: scan setWindowSize`. Cause: `scan::In()` used `address + length <= end`, which wraps on 32-bit for a word equal to
  0xFFFFFFFF and wrongly passed. Fixed in 1.0.7 (no addition; regression test added).
- 1.0.1 crash guard never lowered the stage: `sleep(15)` was interrupted by the crash handler's signals so `boot ok` was
  logged ~3 s after start. Fixed in 1.0.7 (monotonic-clock wait).
- Lesson: the PC test ran with 64-bit pointers, which hid the wrap. The remaining steps (hooks, surface calls) are still unproven on a device.

## 1.0.6 device test (screenshot + log): touch area still at the top-left -> 1.0.7 touch gate
Log: all hooks installed (stage 3), box applied correctly (`pad L488 T216`), but no `touch window(...)` line ever appeared, so the
hooked natives are not on the path real touches take. Java analysis: the running activity is `com.arizona.game.GTASA`
(extends SAMP -> rockstargames GTASA -> ... -> NvEventQueueActivity). Its `onTouchEvent` does NOT call super; it fills 4 slots by
pointer id from `MotionEvent.getX/Y` (window coordinates) and calls `multiTouchEvent4(actionMasked, pointerId, x0,y0,x1,y1,x2,y2,x3,y3, ev)`.
In libGTASA that native is a 4-byte `return true` stub (cannot be inline-hooked, and whatever consumes touches at runtime is not visible
statically). So 1.0.7 maps touches on the Java side instead: `View.OnTouchListener` on the SurfaceView (picture-local events, scaled with
MotionEvent.transform on a copy) forwarded to `Activity.onTouchEvent`; content-root listener swallows bar touches.
Expected log lines: `touch gate class ready`, `layout: ... | touch gate ON`, `gate touch picture-local (x,y) -> game (x,y)`.
Unproven on a device: that the SurfaceView receives the touches (it is not covered by a view that consumes them) and that
`Activity.onTouchEvent` called from the listener behaves like the normal dispatch. Fallback: if the gate class fails to load the log says
`touch gate unavailable` and the native hooks (1.0.5 mapping) are used.

## 1.0.5 device test: touch still wrong -> real cause was the crash guard (fixed in 1.0.7)
The log showed `stage 2` and `stage: not hooking touchEvent`: the touch fix never ran. A 1.0.3 session closed within 15 s
(user closed the game) left the boot marker, the guard dropped to stage 2 and saved it, and 1.0.4/1.0.5 inherited it. The video
confirms it: with the finger in a black bar the camera inside the picture still turned. 1.0.7: two failed starts in a row are
needed to drop a stage, a stage saved by another build is ignored, the menu warns when touch hooks are off, and the first 12
pointer-downs are logged (`touch window(x,y) off(..) view .. game .. -> (..) GAME|BAR-ignored`) so the mapping can be verified.

## 1.0.4 device test (video): touch area was not centered -> 1.0.5
Cause: the game gets touches from `NvEventQueueActivity.onTouchEvent` (the SurfaceView subclass has no touch handler), whose
coordinates are WINDOW coordinates, not picture-local. With a centered box the game saw them shifted by the bar size, so its touch
area sat in the top-left of the screen. 1.0.7 subtracts the box origin (read with getLocationInWindow on every pointer-down),
scales to the render size and ignores gestures that start in the bars. Unit-tested with the numbers from the video; not yet device-tested.
The Lua menu now re-centers (Cond.Appearing) so a position saved at another resolution cannot hide it.

## 1.0.3 device test (video) -> why 1.0.4 changed approach
The box appeared (a 4:3 box with bars), but the HUD bottom bar and the ImGui menu were cut off at the right edge, the Android
overlays stayed full-screen, and touches were wrong in places. Cause: the game was told a substituted size while Java, EGL and
other code still saw the real one, and only the SurfaceView was shrunk. 1.0.7 stops faking values (setWindowSize hook is
pass-through, no buffer-geometry or field writes) and resizes the whole content root instead.
Still unproven on a device: that `setFixedSize` + padding give a clean result in this client, and that no mod uses raw display metrics.

## Earlier box notes (1.0.3 build)
Verified: the SurfaceView is added to a `new FrameLayout` with `FrameLayout.LayoutParams` (systemInit); onCreate sets a
`ColorDrawable` window background; the generated DEX parses with an independent reader (class, ctor, native run(), Runnable,
checksum and SHA-1); FitBox reproduces the three box shapes measured in the reference video.
Unproven on a device: (a) InMemoryDexClassLoader accepts the generated DEX and `runOnUiThread` reaches `ApplyLayout`
(log lines `ui dispatcher ready` / `layout -> box WxH`); (b) the game handles `surfaceChanged` with the box size (expected, it
is the normal path); (c) the FrameLayout paint makes the bars black. If (a) fails the change is applied on the next touch.
Overlay widgets (chat, buttons, voice) are separate full-screen views and stay at the screen edges, like in the reference video.

## Verified (APK analysis + host tests)
- `libGTASA.so` is ELF32 ARM, all JNI natives Thumb. The three natives are found by scanning the static
  JNINativeMethod table; the scanner was run against a relocated image of the real `libGTASA.so` and returns
  the expected addresses; reference prologues match (`tests` in NOTES.md).
- `OS_ScreenSetResolution` = `bx lr` (no-op). `OS_ScreenGetWidth/Height` just return `renderWidth/renderHeight`.
- `setWindowSize(II)V` builds `{6, w, h}` and calls an event-posting function; it does not use `env`/`thiz`.
- `onTouchEvent` passes raw `getX/getY` ints: `touchEvent(action,x,y)`, `multiTouchEvent(action,count,x0,y0,x1,y1)`.
- `multiTouchEvent4` is a 4-byte `return true` stub: never hook it.
- Java fields `view`, `cachedSurfaceHolder`, `holder`, `surfaceWidth`, `surfaceHeight` exist on `NvEventQueueActivity`.
- C++ compiles warning-free against stub headers; `calc.h` and `scan.h` pass their unit tests; Lua structure and
  ffi/export cross-check pass. **No Lua interpreter and no ARM toolchain were available: the Lua was not executed
  and the .so was not built or run.**

## Inferred / unproven (test first on a device)
1. That the game thread's handler for window-size event type 6 resizes the viewport/camera correctly when called at
   runtime. (Java already calls it on every surface change, so the engine is expected to support it.)
2. That `ANativeWindow_setBuffersGeometry` on an already-created EGL window surface takes effect on the next frame and
   is scaled to the screen by the compositor (documented NDK behaviour; vendor drivers vary).
3. Writing `surfaceWidth/Height` in Java (best effort, keeps `getSurfaceWidth()` consistent).
4. Hook coexistence: nothing else in the APK references these three natives, but a mod loaded earlier could patch them;
   the prologue check then skips the hook and logs it (Status tab shows which hooks are active).
5. Late-loaded AML (after the first surface event): activity is found through `ActivityThread.mActivities` reflection,
   which Android's hidden-API rules may restrict on some versions.

## Known limits
- Black bars come from shrinking the SurfaceView (picture size presets / custom size, bars ON). With bars OFF the picture is stretched to fill the screen.
- Mouse/cursor natives (`mouseMoveEvent`, `updateCursorPos`) are not remapped (touch only).
- 32-bit only (the APK ships only `armeabi-v7a`). Build-specific: prologue bytes are for 1.0.7 TESTING.
- Rotation is not handled (the game is landscape-locked).

## First-run checklist
1. logcat: `hooked setWindowSize / touchEvent / multiTouchEvent`, then `Ready. native=WxH`.
2. `/hxdres_h 720`: picture must fill the screen with no repeated tiles; HUD and radar proportions correct.
3. Test touch: movement stick, fire button, camera drag, the menu buttons, chat/keyboard.
4. Background the app and come back (surface is recreated): size must persist (Status tab: buffer sets increase).
5. `/hxdres_reset`, then relaunch with a saved setting; also test the 10-second safe-mode escape.
If step 2 shows the picture in a corner instead of filling the screen, `setBuffersGeometry` is not being scaled on that
device: report the Android version/GPU and the logcat lines.

# HEXED Resolution – Limitations & Beta Notes

## What this starter actually does

- Resolves the real exported symbols `RsGlobal`, `renderWidth` and `renderHeight`
  from the `libGTASA.so` that ships inside SA-MP Nezuko v1.0.3 (TESTING).
- Saves the original `maximumWidth` / `maximumHeight`.
- Writes new values when requested.
- Provides a small C API and a MonetLoader Lua menu with presets + custom size.
- Saves/restores a simple config file (best-effort paths).

## Centering / black bars (0.5.0) - status

- Written from the symptoms in a screen recording, NOT tested on a device: static
  analysis only, no libGTASA available when this was written.
- Needs the game to swap buffers through `eglSwapBuffers` (native import or libEGL). If the
  in-menu line shows `frames=0` after a few seconds, neither hook fired.
- **Touch is still not remapped.** With bars, a tap lands where the game thinks the
  screen is, so touch is offset by the bar size. Fixing that needs the game's touch
  entry point (`nm -D libGTASA.so | grep -i touch`) which is not known yet.

## What it does **not** do (yet)

1. **Full internal render-target / framebuffer resize**  
   Only the high-level RsGlobal (and the two helper integers) are touched.
   The actual OpenGL / RenderWare render target, camera viewport and back-buffer
   size are often set earlier or in other places.  Result: the game may still
   render at the original internal size and letterbox/stretch, or the HUD may
   scale incorrectly.

2. **HUD / radar / widget re-layout**  
   Most mobile HUD code uses hard-coded or RsGlobal-based scaling that is
   computed once at startup.  Changing the values later does not automatically
   re-position every widget.

3. **Touch coordinate remapping**  
   Touch input is usually in screen / window space.  If the internal resolution
   changes while the Android surface stays the same, controls can become
   misaligned or unusable.

4. **Aspect-ratio safety for every preset**  
   The starter accepts any even size inside 320×240 – 4096×4096.  Extreme
   ratios will look wrong.

5. **64-bit**  
   The provided Nezuko APK contains only `armeabi-v7a`.  The build files target
   that ABI only.

## Safe testing procedure

1. Install the original Nezuko APK and confirm the game + SA-MP work.
2. Place `libHEXED_Resolution.so` into the AML mods folder used by the client
   (commonly `Android/data/<package>/mods` or `Android_unprotected/data/<package>/mods`).
3. Place `hexed_resolution.lua` into the MonetLoader scripts directory.
4. Launch the game.  Check logcat for the tag `HEXED_Resolution`.
5. Start with a mild preset (e.g. 1280×720 or 960×540) and immediately test:
   - movement
   - aiming / shooting
   - vehicle controls
   - pause menu / map
6. If anything breaks, use the Reset button or `/hexed_reset` and note the
   exact resolution that caused the problem.
7. Never test on a device you cannot easily recover (keep a backup of the
   original APK / data).

## Next engineering steps (if you continue development)

- Locate the real render-target creation / `RwCamera` / `RQRenderTarget` paths
  in this specific `libGTASA.so` and add coordinated writes.
- Hook the HUD scale / widget layout functions so they re-run after a change.
- Capture the original Android surface size and keep a mapping for touch.
- Add a short “apply on next launch” mode instead of live change, which is
  safer for many internal systems.
- Expand the config format and add per-device profiles.

## Symbol reference (from the APK you supplied)

```
RsGlobal        0x009FC8FC  (size 60, .bss)
renderWidth     0x006B407C
renderHeight    0x006B4080
OS_ScreenGetWidth / OS_ScreenGetHeight also present
```

These were obtained with `readelf` / `nm` on the exact `libGTASA.so` extracted
from `SA-MP Nezuko v1.0.3 (TESTING).apk`.  Do not hard-code absolute addresses
at runtime; always use `aml->GetSym` as the plugin does.
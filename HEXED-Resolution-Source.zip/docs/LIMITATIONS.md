# HEXED Resolution 1.0.3 - status and limitations

## Report from device tests
- 1.0.0: game did not start (no log).
- 1.0.1 log + AML crash log (Honor HNELN-Q, Android 13, armeabi-v7a): SIGSEGV in `memcmp`, R0=0xFFFFFFFF, right after
  `step: scan setWindowSize`. Cause: `scan::In()` used `address + length <= end`, which wraps on 32-bit for a word equal to
  0xFFFFFFFF and wrongly passed. Fixed in 1.0.3 (no addition; regression test added).
- 1.0.1 crash guard never lowered the stage: `sleep(15)` was interrupted by the crash handler's signals so `boot ok` was
  logged ~3 s after start. Fixed in 1.0.3 (monotonic-clock wait).
- Lesson: the PC test ran with 64-bit pointers, which hid the wrap. The remaining steps (hooks, surface calls) are still unproven on a device.

## 1.0.3 additions
Verified: the SurfaceView is added to a `new FrameLayout` with `FrameLayout.LayoutParams` (systemInit); onCreate sets a
`ColorDrawable` window background; the generated DEX parses with an independent reader (class, ctor, native run(), Runnable,
checksum and SHA-1); FitBox reproduces the three box shapes measured in the reference video.
Unproven on a device: (a) InMemoryDexClassLoader accepts the generated DEX and `runOnUiThread` reaches `ApplyLayout`
(log lines `ui dispatcher ready` / `layout -> box WxH`); (b) the game handles `surfaceChanged` with the box size (expected, it
is the normal path); (c) the FrameLayout paint makes the bars black. If (a) fails the change is applied on the next touch.
Overlay widgets (chat, buttons, voice) are separate full-screen views and stay at the screen edges, like in the reference video.

## Verified (APK analysis + host tests)
- `libGTASA.so` is ELF32 ARM, all JNI natives Thumb. The three natives are found by scanning the static
  JNINativeMethod table; the scanner was run against a relocated image of the real `libGTASA.so` and returns
  the expected addresses; reference prologues match (`tests` in NOTES.md).
- `OS_ScreenSetResolution` = `bx lr` (no-op). `OS_ScreenGetWidth/Height` just return `renderWidth/renderHeight`.
- `setWindowSize(II)V` builds `{6, w, h}` and calls an event-posting function; it does not use `env`/`thiz`.
- `onTouchEvent` passes raw `getX/getY` ints: `touchEvent(action,x,y)`, `multiTouchEvent(action,count,x0,y0,x1,y1)`.
- `multiTouchEvent4` is a 4-byte `return true` stub: never hook it.
- Java fields `view`, `cachedSurfaceHolder`, `holder`, `surfaceWidth`, `surfaceHeight` exist on `NvEventQueueActivity`.
- C++ compiles warning-free against stub headers; `calc.h` and `scan.h` pass their unit tests; Lua structure and
  ffi/export cross-check pass. **No Lua interpreter and no ARM toolchain were available: the Lua was not executed
  and the .so was not built or run.**

## Inferred / unproven (test first on a device)
1. That the game thread's handler for window-size event type 6 resizes the viewport/camera correctly when called at
   runtime. (Java already calls it on every surface change, so the engine is expected to support it.)
2. That `ANativeWindow_setBuffersGeometry` on an already-created EGL window surface takes effect on the next frame and
   is scaled to the screen by the compositor (documented NDK behaviour; vendor drivers vary).
3. Writing `surfaceWidth/Height` in Java (best effort, keeps `getSurfaceWidth()` consistent).
4. Hook coexistence: nothing else in the APK references these three natives, but a mod loaded earlier could patch them;
   the prologue check then skips the hook and logs it (Status tab shows which hooks are active).
5. Late-loaded AML (after the first surface event): activity is found through `ActivityThread.mActivities` reflection,
   which Android's hidden-API rules may restrict on some versions.

## Known limits
- Black bars come from shrinking the SurfaceView (picture size presets / custom size, bars ON). With bars OFF the picture is stretched to fill the screen.
- Mouse/cursor natives (`mouseMoveEvent`, `updateCursorPos`) are not remapped (touch only).
- 32-bit only (the APK ships only `armeabi-v7a`). Build-specific: prologue bytes are for 1.0.3 TESTING.
- Rotation is not handled (the game is landscape-locked).

## First-run checklist
1. logcat: `hooked setWindowSize / touchEvent / multiTouchEvent`, then `Ready. native=WxH`.
2. `/hxdres_h 720`: picture must fill the screen with no repeated tiles; HUD and radar proportions correct.
3. Test touch: movement stick, fire button, camera drag, the menu buttons, chat/keyboard.
4. Background the app and come back (surface is recreated): size must persist (Status tab: buffer sets increase).
5. `/hxdres_reset`, then relaunch with a saved setting; also test the 10-second safe-mode escape.
If step 2 shows the picture in a corner instead of filling the screen, `setBuffersGeometry` is not being scaled on that
device: report the Android version/GPU and the logcat lines.

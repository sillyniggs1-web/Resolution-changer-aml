# HEXED Resolution 2.0.0 - notes

## Method (engine-native, no hooks)
`Idle()` in libGTASA.so (Nezuko 1.0.3) reads `MobileSettings::settings + 0x28` (int 0..100) each frame:

    w = 640 + (OS_ScreenGetWidth() - 640) * pct / 100     (GetMaxResWidth == OS_ScreenGetWidth)
    h = OS_ScreenGetHeight() * w / OS_ScreenGetWidth()
    round both up to a multiple of 4 -> emu_SetAltRenderTarget(w, h)

This mod writes only that int (after `MobileSettings::loaded` is set) and re-asserts it
while an override is active. Nothing is hooked or patched.

## Why v1 could crash
v1 hooked `emu_SetAltRenderTarget` and substituted sizes the engine never produces
(above native width, arbitrary aspect), on a hot function other injected code may also patch.
`renderWidth/renderHeight` are only a copy of the last target size; they are never written.

## Limits
- Maximum is native resolution (100%). Supersampling is not supported by the engine path.
- Reset restores the value read when settings loaded this launch. If the game saved the changed
  value to its own settings file earlier, "original" will be that saved value.
- Menus and fades use no alt target (0x0); that is normal.
- Not run on a device. Log tag: `HEXED_Resolution` (expect "Ready. engine pct=..." and
  "no hooks installed").

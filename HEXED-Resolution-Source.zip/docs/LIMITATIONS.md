# HEXED Resolution 1.0.0 - status and limitations

## Verified (APK analysis + host tests)
- `libGTASA.so` is ELF32 ARM, all JNI natives Thumb. The three natives are found by scanning the static
  JNINativeMethod table; the scanner was run against a relocated image of the real `libGTASA.so` and returns
  the expected addresses; reference prologues match (`tests` in NOTES.md).
- `OS_ScreenSetResolution` = `bx lr` (no-op). `OS_ScreenGetWidth/Height` just return `renderWidth/renderHeight`.
- `setWindowSize(II)V` builds `{6, w, h}` and calls an event-posting function; it does not use `env`/`thiz`.
- `onTouchEvent` passes raw `getX/getY` ints: `touchEvent(action,x,y)`, `multiTouchEvent(action,count,x0,y0,x1,y1)`.
- `multiTouchEvent4` is a 4-byte `return true` stub: never hook it.
- Java fields `view`, `cachedSurfaceHolder`, `holder`, `surfaceWidth`, `surfaceHeight` exist on `NvEventQueueActivity`.
- C++ compiles warning-free against stub headers; `calc.h` and `scan.h` pass their unit tests; Lua structure and
  ffi/export cross-check pass. **No Lua interpreter and no ARM toolchain were available: the Lua was not executed
  and the .so was not built or run.**

## Inferred / unproven (test first on a device)
1. That the game thread's handler for window-size event type 6 resizes the viewport/camera correctly when called at
   runtime. (Java already calls it on every surface change, so the engine is expected to support it.)
2. That `ANativeWindow_setBuffersGeometry` on an already-created EGL window surface takes effect on the next frame and
   is scaled to the screen by the compositor (documented NDK behaviour; vendor drivers vary).
3. Writing `surfaceWidth/Height` in Java (best effort, keeps `getSurfaceWidth()` consistent).
4. Hook coexistence: nothing else in the APK references these three natives, but a mod loaded earlier could patch them;
   the prologue check then skips the hook and logs it (Status tab shows which hooks are active).
5. Late-loaded AML (after the first surface event): activity is found through `ActivityThread.mActivities` reflection,
   which Android's hidden-API rules may restrict on some versions.

## Known limits
- No black bars: the picture always fills the screen. Use screen-shaped sizes to avoid stretching.
- Mouse/cursor natives (`mouseMoveEvent`, `updateCursorPos`) are not remapped (touch only).
- 32-bit only (the APK ships only `armeabi-v7a`). Build-specific: prologue bytes are for 1.0.3 TESTING.
- Rotation is not handled (the game is landscape-locked).

## First-run checklist
1. logcat: `hooked setWindowSize / touchEvent / multiTouchEvent`, then `Ready. native=WxH`.
2. `/hxdres_h 720`: picture must fill the screen with no repeated tiles; HUD and radar proportions correct.
3. Test touch: movement stick, fire button, camera drag, the menu buttons, chat/keyboard.
4. Background the app and come back (surface is recreated): size must persist (Status tab: buffer sets increase).
5. `/hxdres_reset`, then relaunch with a saved setting; also test the 10-second safe-mode escape.
If step 2 shows the picture in a corner instead of filling the screen, `setBuffersGeometry` is not being scaled on that
device: report the Android version/GPU and the logcat lines.

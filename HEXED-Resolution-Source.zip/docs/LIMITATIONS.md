# HEXED Resolution 1.0.8 - status and limitations

## Report from device tests
- 1.0.0: game did not start (no log).
- 1.0.1 log + AML crash log (Honor HNELN-Q, Android 13, armeabi-v7a): SIGSEGV in `memcmp`, R0=0xFFFFFFFF, right after
  `step: scan setWindowSize`. Cause: `scan::In()` used `address + length <= end`, which wraps on 32-bit for a word equal to
  0xFFFFFFFF and wrongly passed. Fixed in 1.0.8 (no addition; regression test added).
- 1.0.1 crash guard never lowered the stage: `sleep(15)` was interrupted by the crash handler's signals so `boot ok` was
  logged ~3 s after start. Fixed in 1.0.8 (monotonic-clock wait).
- Lesson: the PC test ran with 64-bit pointers, which hid the wrap. The remaining steps (hooks, surface calls) are still unproven on a device.

## 1.0.7 -> 1.0.8: touch gate moved to the content root
1.0.7 put the listener on the SurfaceView and read its position at touch time; the user still reported an off-centre touch area (no log
was attached). 1.0.8 removes both assumptions (SurfaceView must receive the touch; live position query): the listener is on the content
root only, uses the padding/box/render numbers ApplyLayout stored, and mirrors Android's own fallback order. Checked in the APK: the app
installs no touch listeners of its own on these views, so nothing is replaced. Expected log: `gate touch content(x,y) box origin(L,T)
size WxH game WxH -> GAME|BAR-ignored`. Still unproven on a device.

## 1.0.6 device test (screenshot + log): touch area still at the top-left -> 1.0.8 touch gate
Log: all hooks installed (stage 3), box applied correctly (`pad L488 T216`), but no `touch window(...)` line ever appeared, so the
hooked natives are not on the path real touches take. Java analysis: the running activity is `com.arizona.game.GTASA`
(extends SAMP -> rockstargames GTASA -> ... -> NvEventQueueActivity). Its `onTouchEvent` does NOT call super; it fills 4 slots by
pointer id from `MotionEvent.getX/Y` (window coordinates) and calls `multiTouchEvent4(actionMasked, pointerId, x0,y0,x1,y1,x2,y2,x3,y3, ev)`.
In libGTASA that native is a 4-byte `return true` stub (cannot be inline-hooked, and whatever consumes touches at runtime is not visible
statically). So 1.0.8 maps touches on the Java side instead: `View.OnTouchListener` on the SurfaceView (picture-local events, scaled with
MotionEvent.transform on a copy) forwarded to `Activity.onTouchEvent`; content-root listener swallows bar touches.
Expected log lines: `touch gate class ready`, `layout: ... | touch gate ON`, `gate touch picture-local (x,y) -> game (x,y)`.
Unproven on a device: that the SurfaceView receives the touches (it is not covered by a view that consumes them) and that
`Activity.onTouchEvent` called from the listener behaves like the normal dispatch. Fallback: if the gate class fails to load the log says
`touch gate unavailable` and the native hooks (1.0.5 mapping) are used.

## 1.0.5 device test: touch still wrong -> real cause was the crash guard (fixed in 1.0.8)
The log showed `stage 2` and `stage: not hooking touchEvent`: the touch fix never ran. A 1.0.3 session closed within 15 s
(user closed the game) left the boot marker, the guard dropped to stage 2 and saved it, and 1.0.4/1.0.5 inherited it. The video
confirms it: with the finger in a black bar the camera inside the picture still turned. 1.0.8: two failed starts in a row are
needed to drop a stage, a stage saved by another build is ignored, the menu warns when touch hooks are off, and the first 12
pointer-downs are logged (`touch window(x,y) off(..) view .. game .. -> (..) GAME|BAR-ignored`) so the mapping can be verified.

## 1.0.4 device test (video): touch area was not centered -> 1.0.5
Cause: the game gets touches from `NvEventQueueActivity.onTouchEvent` (the SurfaceView subclass has no touch handler), whose
coordinates are WINDOW coordinates, not picture-local. With a centered box the game saw them shifted by the bar size, so its touch
area sat in the top-left of the screen. 1.0.8 subtracts the box origin (read with getLocationInWindow on every pointer-down),
scales to the render size and ignores gestures that start in the bars. Unit-tested with the numbers from the video; not yet device-tested.
The Lua menu now re-centers (Cond.Appearing) so a position saved at another resolution cannot hide it.

## 1.0.3 device test (video) -> why 1.0.4 changed approach
The box appeared (a 4:3 box with bars), but the HUD bottom bar and the ImGui menu were cut off at the right edge, the Android
overlays stayed full-screen, and touches were wrong in places. Cause: the game was told a substituted size while Java, EGL and
other code still saw the real one, and only the SurfaceView was shrunk. 1.0.8 stops faking values (setWindowSize hook is
pass-through, no buffer-geometry or field writes) and resizes the whole content root instead.
Still unproven on a device: that `setFixedSize` + padding give a clean result in this client, and that no mod uses raw display metrics.

## Earlier box notes (1.0.3 build)
Verified: the SurfaceView is added to a `new FrameLayout` with `FrameLayout.LayoutParams` (systemInit); onCreate sets a
`ColorDrawable` window background; the generated DEX parses with an independent reader (class, ctor, native run(), Runnable,
checksum and SHA-1); FitBox reproduces the three box shapes measured in the reference video.
Unproven on a device: (a) InMemoryDexClassLoader accepts the generated DEX and `runOnUiThread` reaches `ApplyLayout`
(log lines `ui dispatcher ready` / `layout -> box WxH`); (b) the game handles `surfaceChanged` with the box size (expected, it
is the normal path); (c) the FrameLayout paint makes the bars black. If (a) fails the change is applied on the next touch.
Overlay widgets (chat, buttons, voice) are separate full-screen views and stay at the screen edges, like in the reference video.

## Verified (APK analysis + host tests)
- `libGTASA.so` is ELF32 ARM, all JNI natives Thumb. The three natives are found by scanning the static
  JNINativeMethod table; the scanner was run against a relocated image of the real `libGTASA.so` and returns
  the expected addresses; reference prologues match (`tests` in NOTES.md).
- `OS_ScreenSetResolution` = `bx lr` (no-op). `OS_ScreenGetWidth/Height` just return `renderWidth/renderHeight`.
- `setWindowSize(II)V` builds `{6, w, h}` and calls an event-posting function; it does not use `env`/`thiz`.
- `onTouchEvent` passes raw `getX/getY` ints: `touchEvent(action,x,y)`, `multiTouchEvent(action,count,x0,y0,x1,y1)`.
- `multiTouchEvent4` is a 4-byte `return true` stub: never hook it.
- Java fields `view`, `cachedSurfaceHolder`, `holder`, `surfaceWidth`, `surfaceHeight` exist on `NvEventQueueActivity`.
- C++ compiles warning-free against stub headers; `calc.h` and `scan.h` pass their unit tests; Lua structure and
  ffi/export cross-check pass. **No Lua interpreter and no ARM toolchain were available: the Lua was not executed
  and the .so was not built or run.**

## Inferred / unproven (test first on a device)
1. That the game thread's handler for window-size event type 6 resizes the viewport/camera correctly when called at
   runtime. (Java already calls it on every surface change, so the engine is expected to support it.)
2. That `ANativeWindow_setBuffersGeometry` on an already-created EGL window surface takes effect on the next frame and
   is scaled to the screen by the compositor (documented NDK behaviour; vendor drivers vary).
3. Writing `surfaceWidth/Height` in Java (best effort, keeps `getSurfaceWidth()` consistent).
4. Hook coexistence: nothing else in the APK references these three natives, but a mod loaded earlier could patch them;
   the prologue check then skips the hook and logs it (Status tab shows which hooks are active).
5. Late-loaded AML (after the first surface event): activity is found through `ActivityThread.mActivities` reflection,
   which Android's hidden-API rules may restrict on some versions.

## Known limits
- Black bars come from shrinking the SurfaceView (picture size presets / custom size, bars ON). With bars OFF the picture is stretched to fill the screen.
- Mouse/cursor natives (`mouseMoveEvent`, `updateCursorPos`) are not remapped (touch only).
- 32-bit only (the APK ships only `armeabi-v7a`). Build-specific: prologue bytes are for 1.0.8 TESTING.
- Rotation is not handled (the game is landscape-locked).

## First-run checklist
1. logcat: `hooked setWindowSize / touchEvent / multiTouchEvent`, then `Ready. native=WxH`.
2. `/hxdres_h 720`: picture must fill the screen with no repeated tiles; HUD and radar proportions correct.
3. Test touch: movement stick, fire button, camera drag, the menu buttons, chat/keyboard.
4. Background the app and come back (surface is recreated): size must persist (Status tab: buffer sets increase).
5. `/hxdres_reset`, then relaunch with a saved setting; also test the 10-second safe-mode escape.
If step 2 shows the picture in a corner instead of filling the screen, `setBuffersGeometry` is not being scaled on that
device: report the Android version/GPU and the logcat lines.

# HEXED Resolution 1.0.0 - notes

## What it does
Hooks `emu_SetAltRenderTarget(w,h)` in the libGTASA.so of SA-MP Nezuko v1.0.3 TESTING.
The game calls it every frame from `Idle()`; we replace the size with yours. The engine
renders the scene at that size and stretches it to the screen itself.
HUD, menus and touch are unchanged because they use the real screen size.

## Verified in the APK (armeabi-v7a libGTASA.so)
- `Idle()` builds the size from a settings percentage, `MobileSettings::GetMaxResWidth()`,
  rounds to a multiple of 4 and calls `emu_SetAltRenderTarget`.
- `emu_SetAltRenderTarget` stores its arguments in `renderWidth/renderHeight` and returns
  early if the size is unchanged. `(0,0)` = no alt target (menus, fades); we pass it through.
- `emu_glViewport` scales by `renderWidth / OS_ScreenGetWidth()` while a target is bound.
- `OS_ScreenGetWidth/Height` read the real window size (`windowSize`); `OS_ScreenSetResolution` is an empty stub.

## Not verified (never run on a device)
- Visual result and FPS on your tablet, GPU max texture size above ~4096, memory use at 150%+.
- The hook refuses to install if the function bytes differ (other APK builds).

## Safe use
Start with 75% or 100%. 125%+ is supersampling and costs FPS. Reset returns to the engine default.
Log tag: `HEXED_Resolution`.

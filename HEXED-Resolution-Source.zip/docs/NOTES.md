# Evidence from SA-MP Nezuko v1.0.3 (TESTING) - armeabi-v7a

## libGTASA.so (load bias 0; thumb addresses without the +1)
| Item | Address | Notes |
|---|---|---|
| JNINativeMethod table | 0x661e40.. | entries {name, sig, fn}, 12 bytes each |
| setWindowSize "(II)V" | 0x273e3c | prologue b580 466f b086 2006 9201 9000 |
| touchEvent "(IIILandroid/view/MotionEvent;)Z" | 0x273508 | b5f0 af03 f84d 8d04 b086 4606 |
| multiTouchEvent "(IIIIIILandroid/view/MotionEvent;)Z" | 0x27371c | b5f0 af03 e92d 0b00 b086 4606 |
| multiTouchEvent4 | 0x273b30 | `movs r0,#1; bx lr` - do not hook |
| OS_ScreenSetResolution / SetRefresh | 0x268d5c / 0x268d64 | `bx lr` stubs |
| OS_ScreenGetWidth / GetHeight | 0x268d3c / 0x268d4c | return renderWidth / renderHeight |
| renderWidth / renderHeight | 0x6b407c / 0x6b4080 | adjacent ints |
| RsGlobal | 0x9fc8fc | size 60 |
| imports | | no eglSwapBuffers/eglCreateWindowSurface: EGL lives in Java |

## NvEventQueueActivity (classes.dex)
- `surfaceChanged` and `surfaceCreated` call `setGameWindowSize(surfaceWidth, surfaceHeight)` -> native `setWindowSize`.
- `createEGLSurface(SurfaceHolder)` -> `eglCreateWindowSurface`, then `eglQuerySurface(EGL_WIDTH/HEIGHT)` into `surfaceWidth/Height`.
- `onTouchEvent`: single `touchEvent(action,x,y,ev)`; multi `multiTouchEvent(action,count,x0,y0,x1,y1,ev)`; ints from `(int)getX/getY`.
- `swapBuffers()` calls `EGL10.eglSwapBuffers` from Java.

## Tests run on a PC
- `calc.h`: sizes for scale/height/size modes, limits, touch mapping incl. edge clamp and -1 sentinel.
- `scan.h` on a relocated image of the real libGTASA.so (5228 R_ARM_RELATIVE relocs applied, mapped at 0x20000000):
  found setWindowSize, touchEvent, multiTouchEvent, multiTouchEvent4 at the addresses above; prologues match;
  wrong signature / unknown name rejected.

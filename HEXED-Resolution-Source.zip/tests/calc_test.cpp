// Host test (PC): the picture's centering and the touch mapping use ONE rule. Build: g++ -std=c++14 -I src tests/calc_test.cpp && ./a.out
#include "calc.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
using namespace hexed::calc;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

// What MapEvent() does in surface.cpp (Matrix: translate(-off) then scale(active/view)), on one point.
static void MapMatrix(float x, float y, int offX, int offY, int vw, int vh, int aw, int ah, float* ox, float* oy)
{
    float sx = (aw != vw) ? (float)aw / vw : 1.f, sy = (ah != vh) ? (float)ah / vh : 1.f;
    *ox = (x - offX) * sx; *oy = (y - offY) * sy;
}

int main()
{
    // The screenshot: 2000x1200 tablet, 1024x768 window.
    int l, t, r, b;
    CenterRect(2000, 1200, 1024, 768, &l, &t, &r, &b);
    CHECK(l == 488 && t == 216 && r == 488 && b == 216);

    // Touch at the picture's four corners and centre -> game corners, regardless of screen shape.
    struct S { int sw, sh, rw, rh; } screens[] = {
        {2000,1200,1024,768}, {2000,1200,1280,720}, {2000,1200,1920,1080}, {1200,2000,1024,768},   // rotated
        {2400,1080,1280,720}, {1080,2400,1024,768}, {1920,1080,1366,768}, {2560,1600,1024,768}, {1334,750,1280,720} };
    for (auto& s : screens) {
        int bw, bh; FitDown(s.rw, s.rh, s.sw, s.sh, &bw, &bh);
        CenterRect(s.sw, s.sh, bw, bh, &l, &t, &r, &b);
        CHECK(l + bw + r == s.sw && t + bh + b == s.sh);            // box + bars tile the screen exactly
        CHECK(l == r || l == r - 1);                                // horizontally centered (odd px goes to one side)
        CHECK(t == b || t == b - 1);                                // vertically centered
        // the view rect the layout produces is (l,t,bw,bh): touch inside it must hit the same game pixel via both implementations
        int aw = bw, ah = bh;
        for (int k = 0; k < 5; ++k) {
            int px = l + (k == 0 ? 0 : k == 1 ? bw - 1 : bw / 2), py = t + (k == 2 ? 0 : k == 3 ? bh - 1 : bh / 2);
            int mx, my; bool in = MapTouch(px, py, l, t, bw, bh, aw, ah, &mx, &my);
            float fx, fy; MapMatrix((float)px, (float)py, l, t, bw, bh, aw, ah, &fx, &fy);
            CHECK(in);
            CHECK(fabsf(fx - mx) < 1.0f && fabsf(fy - my) < 1.0f);
            CHECK(mx >= 0 && mx < aw && my >= 0 && my < ah);
        }
        CHECK(!MapTouch(l - 1, t + bh / 2, l, t, bw, bh, aw, ah, new int, new int));   // bar left
        CHECK(!MapTouch(l + bw, t + bh / 2, l, t, bw, bh, aw, ah, new int, new int));  // bar right
        if (t > 0) CHECK(!MapTouch(l + bw / 2, t - 1, l, t, bw, bh, aw, ah, new int, new int));  // bar top
    }
    // The old bug, as numbers: at (0,0) of the window the game used to see (0,0); it must now be a bar touch, and the
    // picture's top-left corner (488,216) must be the game's (0,0).
    int mx, my;
    CHECK(!MapTouch(268, 722, 488, 216, 1024, 768, 1024, 768, &mx, &my));          // the finger in the left bar in the screenshot
    CHECK(MapTouch(488, 216, 488, 216, 1024, 768, 1024, 768, &mx, &my) && mx == 0 && my == 0);
    CHECK(MapTouch(1511, 983, 488, 216, 1024, 768, 1024, 768, &mx, &my) && mx == 1023 && my == 767);
    // Render size different from the box (setFixedSize): scaled.
    CHECK(MapTouch(488 + 512, 216 + 384, 488, 216, 1024, 768, 512, 384, &mx, &my) && mx == 256 && my == 192);
    // PictureRect: the touch origin comes from the SAME inputs as the centering (content size + window position + box).
    int px, py, pw, ph;
    PictureRect(0, 0, 2000, 1200, 1024, 768, &px, &py, &pw, &ph);                  // the screenshot
    CHECK(px == 488 && py == 216 && pw == 1024 && ph == 768);
    PictureRect(0, 0, 2000, 1200, 0, 0, &px, &py, &pw, &ph);                       // no box: the picture is the whole content area
    CHECK(px == 0 && py == 0 && pw == 2000 && ph == 1200);
    PictureRect(0, 48, 2000, 1152, 1024, 768, &px, &py, &pw, &ph);                 // content root below a 48 px inset: origin follows it
    CHECK(px == 488 && py == 48 + 192 && pw == 1024 && ph == 768);
    PictureRect(0, 0, 1200, 2000, 1024, 768, &px, &py, &pw, &ph);                  // rotated screen
    CHECK(px == 88 && py == 616);
    PictureRect(0, 0, 1000, 600, 1920, 1080, &px, &py, &pw, &ph);                  // box bigger than the content: HasBox is false, fill
    CHECK(px == 0 && py == 0 && pw == 1000 && ph == 600);
    // For every screen/box combination the touch rectangle is exactly where CenterRect puts the picture (padding l,t), and the
    // centre of the screen maps to the centre of the game.
    for (auto& s : screens) {
        int bw, bh; FitDown(s.rw, s.rh, s.sw, s.sh, &bw, &bh);
        CenterRect(s.sw, s.sh, bw, bh, &l, &t, &r, &b);
        PictureRect(0, 0, s.sw, s.sh, bw, bh, &px, &py, &pw, &ph);
        const bool box = HasBox(bw, bh, s.sw, s.sh);
        CHECK(box ? (px == l && py == t && pw == bw && ph == bh) : (px == 0 && py == 0 && pw == s.sw && ph == s.sh));
        int gx, gy; MapTouch(s.sw / 2, s.sh / 2, px, py, pw, ph, pw, ph, &gx, &gy);
        CHECK(abs(gx - pw / 2) <= 1 && abs(gy - ph / 2) <= 1);                      // screen centre == picture centre
    }
    printf(fails ? "%d FAILED\n" : "all calc tests passed\n", fails);
    return fails != 0;
}

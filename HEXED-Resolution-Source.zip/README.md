# HEXED Resolution 3.0.0

AML plugin + MonetLoader Lua menu that resizes the game window the way the Android surface does (engine event `NVEventPostEvent` type 6), like the reference Zen Menu: HUD, aspect and render target follow. No hooks.

## Build (unchanged GitHub Actions flow)
Replace `HEXED-Resolution-Source.zip` in the repo root with this one and push; the workflow
builds `libHEXED_Resolution.so` (armeabi-v7a). Local: `ANDROID_NDK_HOME=... ./build.sh`.

## Install
1. `libHEXED_Resolution.so` -> AML mods folder
2. `lua/hexed_resolution.lua` -> MonetLoader scripts folder
3. In game: `/hxdres` (menu), `/hxdres_set 1280 720`, `/hxdres_reset`
4. `adb logcat -s HEXED_Resolution` - you should see "Using NVEventPostEvent (verified bytes) / Ready. native window WxH"

The setting is saved to `<Android/data/pkg/files>/HEXED/hexed_resolution.cfg` and re-applied
at the next launch even without the Lua script. See `docs/LIMITATIONS.md`.

# HEXED Resolution 2.0.0

AML plugin + MonetLoader Lua menu that changes the **game-internal render resolution** of
SA-MP Nezuko v1.0.3 (TESTING, armeabi-v7a). It writes the engine's own resolution setting (no hooks)
(`MobileSettings` resolution %), so HUD, menus and touch keep working. Android DPI is not changed.

## Build (unchanged GitHub Actions flow)
Replace `HEXED-Resolution-Source.zip` in the repo root with this one and push; the workflow
builds `libHEXED_Resolution.so` (armeabi-v7a). Local: `ANDROID_NDK_HOME=... ./build.sh`.

## Install
1. `libHEXED_Resolution.so` -> AML mods folder
2. `lua/hexed_resolution.lua` -> MonetLoader scripts folder
3. In game: `/hxdres` (menu), `/hxdres_pct 75` (0-100), `/hxdres_reset`
4. `adb logcat -s HEXED_Resolution` - you should see "Ready. engine pct=..."

The setting is saved to `<Android/data/pkg/files>/HEXED/hexed_resolution.cfg` and re-applied
at the next launch even without the Lua script. See `docs/LIMITATIONS.md`.

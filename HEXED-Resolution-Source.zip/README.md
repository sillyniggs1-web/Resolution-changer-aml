# HEXED Resolution 4.0.0

AML plugin + MonetLoader Lua menu. Main mode drives the engine's own render-resolution setting (no hooks); an experimental window-size mode is also included. See docs/ENGINE-ANALYSIS.md.

## Build (unchanged GitHub Actions flow)
Replace `HEXED-Resolution-Source.zip` in the repo root with this one and push; the workflow
builds `libHEXED_Resolution.so` (armeabi-v7a). Local: `ANDROID_NDK_HOME=... ./build.sh`.

## Install
1. `libHEXED_Resolution.so` -> AML mods folder
2. `lua/hexed_resolution.lua` -> MonetLoader scripts folder
3. In game: `/hxdres` (menu), `/hxdres_pct 75` (render scale), `/hxdres_set 1280 720` (experimental window size), `/hxdres_reset`
4. `adb logcat -s HEXED_Resolution` - you should see "Using NVEventPostEvent (verified bytes) / Ready. native window WxH"

The setting is saved to `<Android/data/pkg/files>/HEXED/hexed_resolution.cfg` and re-applied
at the next launch even without the Lua script. See `docs/LIMITATIONS.md`.

## If the game crashes
Send `Android/data/<game package>/files/HEXED/hexed_resolution.log` (last 40 lines). After a crash the next launch
starts in safe mode automatically (saved size cleared).

# HEXED Resolution 1.0.9 (picture box + black bars, centered touch)

AML plugin + MonetLoader Lua menu that changes the **game's render resolution** on
SA-MP Nezuko v1.0.7 (TESTING), `armeabi-v7a`. Android's display size / DPI is never touched.

> Status: built from static analysis of the APK + host tests. **Not yet run on a device.**
> See `docs/LIMITATIONS.md` for what is verified vs. inferred.

## 1.0.7: one consistent size (window with black bars)

Pick a window size (e.g. 1280x720): the game becomes a real window of that size, centered, with black bars around it.
Earlier builds only shrank the SurfaceView and told the game a made-up size, so the HUD was cut off, the Android overlays
(chat, buttons, voice) stayed full-screen and touch no longer matched. Now Android does the whole resize:

1. `setPadding` on `android.R.id.content` (the grandparent of the SurfaceView): the SurfaceView **and every overlay added with
   addContentView** share the same centered box; the content is painted black for the bars.
2. `SurfaceHolder.setFixedSize` only when the render resolution must differ from the box (percent / height presets, or bars OFF).
3. Android's own `surfaceChanged -> setWindowSize` then tells the game; nothing is faked, so the game, EGL, Java and mods agree.
4. Touch (1.0.8, "callback proxy"): the game reads touches in `GTASA.onTouchEvent` with WINDOW coordinates, so with a centered picture its
   touch area used to sit at the screen's top-left (offset by the bar size). 1.0.8 wraps the Activity's `Window.Callback` with a
   `java.lang.reflect.Proxy` (generated handler class `hexed.CbHandler`). Every touch passes there: the view tree (Java overlays, dialogs)
   gets it unchanged, and only what nobody consumed goes on to the game as `Activity.onTouchEvent(picture-local, render-size event)`.
   The picture rectangle is read from the SurfaceView that `ApplyLayout` centered, using the same `calc::CenterRect` rule, so picture and
   touch area share one reference at any resolution / aspect ratio / orientation. Touches that start in the black bars are swallowed.
   Fallbacks, in order: the 1.0.7 `View.OnTouchListener` gate, then the native hooks.

## 1.0.9: one centering rule for the picture AND its touch area

The touch area is the picture rectangle `calc::PictureRect(content x/y/w/h, box)`, i.e. `calc::CenterRect` with the same inputs `ApplyLayout`
uses, not a value read back from the view. Java paths flag the events they already mapped, so the native hooks map every other touch (once).
The touch path is re-verified every ~2 s. Status tab shows proxy calls, mapped touches and the last window -> game coordinate pair.

## What changed from 0.5.x (and why the screen showed a repeated pattern)

0.5.x told the game "the screen is smaller" but the real EGL surface stayed 2000x1200, so the game drew
into a corner and the rest of the surface showed stale GPU tiles (your screenshot). The GL "present pass"
that tried to repair this never ran. 1.0.0 fixes the cause:

1. **Surface is the picture.** `ANativeWindow_setBuffersGeometry` shrinks the buffers of the game's own
   SurfaceView; Android scales them to the screen. Nothing is left over to clear.
2. **The game's own resize path.** Java `surfaceChanged -> setWindowSize(w,h)` (native, hooked) posts the
   game's window-size event. While an override is active the game is told *our* size, and the plugin posts
   the same event at runtime. (`OS_ScreenSetResolution` is an empty `bx lr` stub in this build.)
3. **Touch remap.** `touchEvent` / `multiTouchEvent` get raw screen pixels; they are scaled to the game size.

## Build

ndk-build (what the GitHub workflow uses):

    export ANDROID_NDK_HOME=/path/to/ndk-r26d
    ndk-build -C jni NDK_LIBS_OUT=./libs NDK_OUT=./obj

CMake:

    cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake \
          -DANDROID_ABI=armeabi-v7a -DANDROID_PLATFORM=android-21 -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
    cmake --build build -j

GitHub Actions: commit `.github/workflows/build.yml` + the source `.zip` in the repo root (unchanged flow).

## Install

1. `libHEXED_Resolution.so` -> AML mods folder
2. `lua/hexed_resolution.lua` -> MonetLoader scripts folder
3. `adb logcat -s HEXED_Resolution` (or `hexed_resolution.log`) -> expect `touch callback handler class ready`, `touch: Window.Callback proxy installed`,
   `layout: ... touch path callback`, and on the first touches `touch(cb) window (x,y) picture at (ox,oy) WxH game WxH -> (gx,gy) GAME|BAR-ignored`.

## If the game does not start (diagnostics, new in 1.0.7)

The plugin writes `Android/data/<game package>/files/hexed_resolution.log` (flushed after every line, so the **last line
shows where it died**) and has a crash guard:

| Stage | What is active |
|---|---|
| 0 | nothing (plugin loads and does nothing) |
| 1 | scans libGTASA for the natives, no hooks |
| 2 | + hook `setWindowSize` (resolution works, touch is not remapped) |
| 3 | full (default) |

A start that does not survive 15 s leaves `hexed_resolution.boot`. Closing the game early does the same, so ONE leftover only
retries the same stage; two failed starts in a row drop one stage and write it to `hexed_resolution.stage`. A stage file from another
plugin version is ignored, so every new build starts at full (3). Delete `hexed_resolution.stage` to go back to full at any time.
The Status tab and the menu show a warning when the touch hooks are off (stage below 3).
Send `hexed_resolution.log` (and `hexed_resolution.stage`) to pinpoint a crash.

## Use

`/hxdres` opens the menu (tabs: Resolution / Touch / Status).
Commands: `/hxdres_set 1280 720` (picture box), `/hxdres_bars 0|1`, `/hxdres_h 720` (height, width follows the screen), `/hxdres_pct 25-100`,
`/hxdres_set <w> <h>`, `/hxdres_reset`, `/hxdres_touch [0|1]`.

Use heights/percent (screen-shaped sizes) to avoid stretching. A custom size with a different shape is stretched
to fill the screen (no black bars in this method).

**Safe mode:** a setting is "unconfirmed" for 10 s after it is applied or loaded. If the game is closed in that window
(unusable setting, crash) the next launch starts at native resolution and clears the saved setting.

## Files

| File | Role |
|---|---|
| `src/main.cpp` | mod entry, config + safe mode, apply/reset, exported `HEXED_*` C API |
| `src/surface.cpp` | JNI: activity, SurfaceView/Surface, `ANativeWindow_setBuffersGeometry` |
| `src/ui.cpp`, `src/uidex.h`, `tools/gen_uidex.py` | UI-thread dispatcher (generated Runnable DEX) |
| `src/natives.cpp` | finds + hooks `setWindowSize`, `touchEvent`, `multiTouchEvent` via the JNI table |
| `src/calc.h`, `src/scan.h` | pure logic (size math, touch mapping, table scan) - unit-tested on a PC |
| `lua/hexed_resolution.lua` | HEXED-style menu over `ffi` |
| `docs/NOTES.md` | evidence from the APK (addresses, bytes, Java layout) |

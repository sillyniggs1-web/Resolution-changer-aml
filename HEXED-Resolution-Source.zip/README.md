# HEXED Resolution (beta)

AML plugin + MonetLoader Lua menu that changes **game-internal** rendering resolution
on SA-MP Nezuko v1.0.3 (TESTING). Does **not** change Android system DPI or display resolution.

## GitHub Actions usage (ZIP → .so)

1. Create a new GitHub repository.
2. Commit only:
   - `.github/workflows/build.yml` (from this project)
   - `HEXED-Resolution-Source.zip` (the source package) in the **repository root**
3. Push. The workflow runs automatically (or trigger it with “Run workflow”).
4. Download the artifact `HEXED-Resolution-armeabi-v7a` from the Actions run.

The workflow:
- Finds the newest `.zip` in the repo root
- Extracts it and locates `jni/Android.mk`
- Ensures official AML mod headers (pinned commit) if missing
- Builds with NDK r26d for `armeabi-v7a`
- Validates the `.so` (ELF 32-bit ARM + required symbols)
- Publishes the `.so`, Lua script, README and install notes

## Local build (optional)

```bash
export ANDROID_NDK_HOME=/path/to/ndk-r26d
ndk-build -C jni NDK_LIBS_OUT=./libs NDK_OUT=./obj
```

## Install on device

1. `libHEXED_Resolution.so` → AML mods folder
2. `lua/hexed_resolution.lua` → MonetLoader scripts folder
3. `adb logcat -s HEXED_Resolution`

Commands: `/hxdres` (menu), `/hxdres_pct 0-100`, `/hxdres_set <w> <h>`, `/hxdres_reset`,
`/hxdres_center [0|1]`, `/hxdres_fit [0|1]`

## Centered view with black bars (0.5.0)

When a resolution override is active, the picture is kept in the middle of the
real screen and everything around it is painted black, so you only see the aspect
ratio of the resolution you picked.

- `Center: ON/OFF` (`/hxdres_center`) - on by default, saved in the config file.
- `Mode: Fit screen` (default) scales the picture up as far as the screen allows,
  keeping the aspect ratio. `Mode: 1:1 pixels` never upscales, so bars are bigger
  (`/hxdres_fit 1`).
- Implemented in `src/center.cpp`: patches the GL/EGL imports (glViewport, glScissor,
  glEnable/glDisable, glBindFramebuffer, eglSwapBuffers, eglGetProcAddress) of
  libGTASA / libsamp / libNezukoSA. libmonetloader (the Lua menu) is deliberately
  left alone so the menu always draws on the full screen.
- logcat (`adb logcat -s HEXED_Resolution`) prints which imports were patched
  (`hookMask`) and the surface / frame / target rectangles (`S=`, `F=`, `T=`).

## Symbols used (from Nezuko APK)

- `RsGlobal` (maximumWidth / maximumHeight)
- `renderWidth` / `renderHeight`

See `docs/LIMITATIONS.md`.

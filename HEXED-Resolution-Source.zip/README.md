# HEXED Resolution 1.0.3 (picture box + black bars)

AML plugin + MonetLoader Lua menu that changes the **game's render resolution** on
SA-MP Nezuko v1.0.3 (TESTING), `armeabi-v7a`. Android's display size / DPI is never touched.

> Status: built from static analysis of the APK + host tests. **Not yet run on a device.**
> See `docs/LIMITATIONS.md` for what is verified vs. inferred.

## 1.0.3: smaller picture with black bars (like the reference video)

Pick a size and the game picture becomes a centered box of that shape with black bars around it; the game sees that size
as its screen and touch follows the box. Examples on a 1612x720 phone: 1920x1080 -> 16:9 box 1280x720 (bars at the sides),
1113x434 -> full width, bars above and below. The game renders at the requested resolution inside the box.

How: the game's SurfaceView lives in a plain `FrameLayout` (verified in the APK). The plugin gives it a fixed size + CENTER
gravity and paints the FrameLayout black (UI thread only, see `src/ui.cpp`: a 476-byte generated `Runnable` class loaded with
InMemoryDexClassLoader; fallback = applied on the next touch). Android then reports the new size to the game and
delivers touches in box coordinates. Menu: *Picture size* presets + custom size; `Black bars` toggle (OFF = stretch to fill).

## What changed from 0.5.x (and why the screen showed a repeated pattern)

0.5.x told the game "the screen is smaller" but the real EGL surface stayed 2000x1200, so the game drew
into a corner and the rest of the surface showed stale GPU tiles (your screenshot). The GL "present pass"
that tried to repair this never ran. 1.0.0 fixes the cause:

1. **Surface is the picture.** `ANativeWindow_setBuffersGeometry` shrinks the buffers of the game's own
   SurfaceView; Android scales them to the screen. Nothing is left over to clear.
2. **The game's own resize path.** Java `surfaceChanged -> setWindowSize(w,h)` (native, hooked) posts the
   game's window-size event. While an override is active the game is told *our* size, and the plugin posts
   the same event at runtime. (`OS_ScreenSetResolution` is an empty `bx lr` stub in this build.)
3. **Touch remap.** `touchEvent` / `multiTouchEvent` get raw screen pixels; they are scaled to the game size.

## Build

ndk-build (what the GitHub workflow uses):

    export ANDROID_NDK_HOME=/path/to/ndk-r26d
    ndk-build -C jni NDK_LIBS_OUT=./libs NDK_OUT=./obj

CMake:

    cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake \
          -DANDROID_ABI=armeabi-v7a -DANDROID_PLATFORM=android-21 -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
    cmake --build build -j

GitHub Actions: commit `.github/workflows/build.yml` + the source `.zip` in the repo root (unchanged flow).

## Install

1. `libHEXED_Resolution.so` -> AML mods folder
2. `lua/hexed_resolution.lua` -> MonetLoader scripts folder
3. `adb logcat -s HEXED_Resolution` -> expect `hooked setWindowSize`, `hooked touchEvent`, `hooked multiTouchEvent`, `Ready. native=...`

## If the game does not start (diagnostics, new in 1.0.3)

The plugin writes `Android/data/<game package>/files/hexed_resolution.log` (flushed after every line, so the **last line
shows where it died**) and has a crash guard:

| Stage | What is active |
|---|---|
| 0 | nothing (plugin loads and does nothing) |
| 1 | scans libGTASA for the natives, no hooks |
| 2 | + hook `setWindowSize` (resolution works, touch is not remapped) |
| 3 | full (default) |

If a start does not survive 15 s, the next start automatically runs one stage lower and writes the new stage to
`hexed_resolution.stage` (delete that file, or put `3` in it, to try full again). So after one failed launch the game starts again by itself.
Send the contents of `hexed_resolution.log` (and `hexed_resolution.stage`) to pinpoint the crash.
To force a stage, create `hexed_resolution.stage` containing 0-3 in the same folder.

## Use

`/hxdres` opens the menu (tabs: Resolution / Touch / Status).
Commands: `/hxdres_set 1280 720` (picture box), `/hxdres_bars 0|1`, `/hxdres_h 720` (height, width follows the screen), `/hxdres_pct 25-100`,
`/hxdres_set <w> <h>`, `/hxdres_reset`, `/hxdres_touch [0|1]`.

Use heights/percent (screen-shaped sizes) to avoid stretching. A custom size with a different shape is stretched
to fill the screen (no black bars in this method).

**Safe mode:** a setting is "unconfirmed" for 10 s after it is applied or loaded. If the game is closed in that window
(unusable setting, crash) the next launch starts at native resolution and clears the saved setting.

## Files

| File | Role |
|---|---|
| `src/main.cpp` | mod entry, config + safe mode, apply/reset, exported `HEXED_*` C API |
| `src/surface.cpp` | JNI: activity, SurfaceView/Surface, `ANativeWindow_setBuffersGeometry` |
| `src/ui.cpp`, `src/uidex.h`, `tools/gen_uidex.py` | UI-thread dispatcher (generated Runnable DEX) |
| `src/natives.cpp` | finds + hooks `setWindowSize`, `touchEvent`, `multiTouchEvent` via the JNI table |
| `src/calc.h`, `src/scan.h` | pure logic (size math, touch mapping, table scan) - unit-tested on a PC |
| `lua/hexed_resolution.lua` | HEXED-style menu over `ffi` |
| `docs/NOTES.md` | evidence from the APK (addresses, bytes, Java layout) |

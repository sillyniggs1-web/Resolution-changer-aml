# HEXED Resolution (beta)

AML plugin + MonetLoader Lua menu that changes **game-internal** rendering resolution
on SA-MP Nezuko v1.0.3 (TESTING). Does **not** change Android system DPI or display resolution.

## GitHub Actions usage (ZIP → .so)

1. Create a new GitHub repository.
2. Commit only:
   - `.github/workflows/build.yml` (from this project)
   - `HEXED-Resolution-Source.zip` (the source package) in the **repository root**
3. Push. The workflow runs automatically (or trigger it with “Run workflow”).
4. Download the artifact `HEXED-Resolution-armeabi-v7a` from the Actions run.

The workflow:
- Finds the newest `.zip` in the repo root
- Extracts it and locates `jni/Android.mk`
- Ensures official AML mod headers (pinned commit) if missing
- Builds with NDK r26d for `armeabi-v7a`
- Validates the `.so` (ELF 32-bit ARM + required symbols)
- Publishes the `.so`, Lua script, README and install notes

## Local build (optional)

```bash
export ANDROID_NDK_HOME=/path/to/ndk-r26d
ndk-build -C jni NDK_LIBS_OUT=./libs NDK_OUT=./obj
```

## Install on device

1. `libHEXED_Resolution.so` → AML mods folder
2. `lua/hexed_resolution.lua` → MonetLoader scripts folder
3. `adb logcat -s HEXED_Resolution`

Commands: `/hexed`, `/hexed_apply <w> <h>`, `/hexed_reset`

## Symbols used (from Nezuko APK)

- `RsGlobal` (maximumWidth / maximumHeight)
- `renderWidth` / `renderHeight`

See `docs/LIMITATIONS.md`.

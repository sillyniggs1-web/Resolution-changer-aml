#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ -z "$ANDROID_NDK_HOME" ] && [ -z "$NDK_ROOT" ]; then
    echo "Set ANDROID_NDK_HOME or NDK_ROOT"
    exit 1
fi

NDK="${ANDROID_NDK_HOME:-$NDK_ROOT}"
echo "Using NDK: $NDK"

"$NDK/ndk-build" -C jni \
    NDK_LIBS_OUT="$(pwd)/libs" \
    NDK_OUT="$(pwd)/obj" \
    -j"$(nproc 2>/dev/null || echo 4)"

echo ""
echo "Built:"
find libs -name "*.so" -exec ls -la {} \;
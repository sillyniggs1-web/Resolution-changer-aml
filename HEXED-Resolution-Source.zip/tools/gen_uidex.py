#!/usr/bin/env python3
"""Generates src/uidex.h: a tiny DEX with two classes whose methods are native (registered by HEXED at runtime):

    public class hexed.UiPost    implements java.lang.Runnable             { public native void run(); }
    public class hexed.TouchGate implements android.view.View.OnTouchListener
                                                                           { public native boolean onTouch(View, MotionEvent); }

UiPost is posted with Activity.runOnUiThread() (native code cannot reach the UI thread otherwise). TouchGate is installed on the
game's SurfaceView and the content root so touches reach the game in picture coordinates and touches in the black bars are dropped.
Run:  python3 tools/gen_uidex.py > src/uidex.h        (python3 tools/gen_uidex.py --raw > x.dex  for the binary)
"""
import struct, hashlib, zlib, sys

def uleb(v):
    out = bytearray()
    while True:
        b = v & 0x7f; v >>= 7
        if v: out.append(b | 0x80)
        else: out.append(b); return bytes(out)

OBJ, RUN, OTL = "Ljava/lang/Object;", "Ljava/lang/Runnable;", "Landroid/view/View$OnTouchListener;"
VIEW, MEV = "Landroid/view/View;", "Landroid/view/MotionEvent;"
UIPOST, GATE = "Lhexed/UiPost;", "Lhexed/TouchGate;"

# classes: (descriptor, interface, [(name, proto, flags, has_code)])  proto = (return, (params...))
classes = [
    (UIPOST, RUN, [("<init>", ("V", ()), 0x10001, True), ("run", ("V", ()), 0x101, False)]),
    (GATE,   OTL, [("<init>", ("V", ()), 0x10001, True), ("onTouch", ("Z", (VIEW, MEV)), 0x101, False)]),
]

def shorty(proto):
    r, ps = proto
    return r[0] if r[0] != 'L' else 'L'  # return char
def shorty_str(proto):
    r, ps = proto
    return (r if len(r) == 1 else 'L') + ''.join(p if len(p) == 1 else 'L' for p in ps)

# ---- tables ----
protos_used = {("V", ()), ("Z", (VIEW, MEV))}
strings = set(["<init>", OBJ])
types = set([OBJ, "V", "Z"])
for d, itf, ms in classes:
    strings |= {d, itf}; types |= {d, itf}
    for n, p, fl, hc in ms:
        strings.add(n)
for p in protos_used:
    strings.add(shorty_str(p)); types.add(p[0]); strings.add(p[0])
    for x in p[1]: types.add(x); strings.add(x)
for t in types: strings.add(t)
strings = sorted(strings, key=lambda s: s.encode())
S = {s: i for i, s in enumerate(strings)}
types = sorted(types, key=lambda t: S[t])
T = {t: i for i, t in enumerate(types)}
protos = sorted(protos_used, key=lambda p: (T[p[0]], tuple(T[x] for x in p[1])))
P = {p: i for i, p in enumerate(protos)}

methods = [(UIPOST, "<init>", ("V", ())), (UIPOST, "run", ("V", ())), (GATE, "<init>", ("V", ())), (GATE, "onTouch", ("Z", (VIEW, MEV))),
           (OBJ, "<init>", ("V", ()))]
methods = sorted(methods, key=lambda m: (T[m[0]], S[m[1]], P[m[2]]))
M = {m: i for i, m in enumerate(methods)}

HDR = 0x70
off_str = HDR; off_type = off_str + 4*len(strings); off_proto = off_type + 4*len(types)
off_meth = off_proto + 12*len(protos); off_cls = off_meth + 8*len(methods); off_data = off_cls + 32*len(classes)
assert off_data % 4 == 0

data = bytearray()
def align4():
    while (off_data + len(data)) % 4: data.append(0)
def here(): return off_data + len(data)

# type_lists: one per interface list and one per proto with params
tl_off = {}
for d, itf, ms in classes:
    align4(); tl_off[("itf", d)] = here(); data += struct.pack('<IH', 1, T[itf])
for p in protos:
    if p[1]:
        align4(); tl_off[("par", p)] = here()
        data += struct.pack('<I', len(p[1])) + b''.join(struct.pack('<H', T[x]) for x in p[1])
# code items (constructors): invoke-direct {v0}, Object.<init> ; return-void
code_off = {}
for d, itf, ms in classes:
    align4(); code_off[d] = here()
    insns = [0x1070, M[(OBJ, "<init>", ("V", ()))], 0x0000, 0x000e]
    data += struct.pack('<HHHHII', 1, 1, 1, 0, 0, len(insns)) + b''.join(struct.pack('<H', x) for x in insns)
str_offs = []
for s in strings:
    str_offs.append(here()); b = s.encode(); data += uleb(len(s)) + b + b'\0'
cdata_off = {}
for d, itf, ms in classes:
    cdata_off[d] = here()
    direct = sorted([(M[(d, n, p)], fl, hc) for n, p, fl, hc in ms if n == "<init>"])
    virt = sorted([(M[(d, n, p)], fl, hc) for n, p, fl, hc in ms if n != "<init>"])
    data += uleb(0) + uleb(0) + uleb(len(direct)) + uleb(len(virt))
    for lst in (direct, virt):
        prev = 0
        for idx, fl, hc in lst:
            data += uleb(idx - prev) + uleb(fl) + uleb(code_off[d] if hc else 0); prev = idx
align4(); off_map = here()
map_items = [(0x0000, 1, 0), (0x0001, len(strings), off_str), (0x0002, len(types), off_type), (0x0003, len(protos), off_proto),
             (0x0005, len(methods), off_meth), (0x0006, len(classes), off_cls),
             (0x1001, len(tl_off), min(tl_off.values())), (0x2001, len(code_off), min(code_off.values())),
             (0x2002, len(strings), str_offs[0]), (0x2000, len(cdata_off), min(cdata_off.values())), (0x1000, 1, off_map)]
assert [m[2] for m in map_items] == sorted(m[2] for m in map_items), map_items
data += struct.pack('<I', len(map_items)) + b''.join(struct.pack('<HHII', t, 0, n, o) for t, n, o in map_items)
file_size = off_data + len(data)

body = bytearray()
body += b''.join(struct.pack('<I', o) for o in str_offs)
body += b''.join(struct.pack('<I', S[t]) for t in types)
for p in protos:
    body += struct.pack('<III', S[shorty_str(p)], T[p[0]], tl_off.get(("par", p), 0))
for (c, n, p) in methods:
    body += struct.pack('<HHI', T[c], P[p], S[n])
for d, itf, ms in classes:
    body += struct.pack('<IIIIIIII', T[d], 1, T[OBJ], tl_off[("itf", d)], 0xFFFFFFFF, 0, cdata_off[d], 0)

header = bytearray(HDR)
header[0:8] = b'dex\n035\0'
struct.pack_into('<I', header, 32, file_size); struct.pack_into('<I', header, 36, HDR); struct.pack_into('<I', header, 40, 0x12345678)
struct.pack_into('<II', header, 44, 0, 0); struct.pack_into('<I', header, 52, off_map)
struct.pack_into('<II', header, 56, len(strings), off_str); struct.pack_into('<II', header, 64, len(types), off_type)
struct.pack_into('<II', header, 72, len(protos), off_proto); struct.pack_into('<II', header, 80, 0, 0)
struct.pack_into('<II', header, 88, len(methods), off_meth); struct.pack_into('<II', header, 96, len(classes), off_cls)
struct.pack_into('<II', header, 104, file_size - off_data, off_data)

dex = bytearray(header) + body + data
assert len(dex) == file_size, (len(dex), file_size)
dex[12:32] = hashlib.sha1(bytes(dex[32:])).digest()
struct.pack_into('<I', dex, 8, zlib.adler32(bytes(dex[12:])) & 0xffffffff)

if len(sys.argv) > 1 and sys.argv[1] == '--raw':
    sys.stdout.buffer.write(dex)
else:
    print("// GENERATED by tools/gen_uidex.py - do not edit.")
    print("#ifndef HEXED_UIDEX_H\n#define HEXED_UIDEX_H\n")
    print("alignas(8) static const unsigned char kUiDex[] = {")
    for i in range(0, len(dex), 12):
        print("    " + ", ".join("0x%02x" % b for b in dex[i:i+12]) + ",")
    print("};\n#endif")

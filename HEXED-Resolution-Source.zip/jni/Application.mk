APP_ABI          := armeabi-v7a
APP_PLATFORM     := android-21
APP_STL          := c++_static
APP_CPPFLAGS     += -std=c++17 -fno-exceptions -fno-rtti
APP_CFLAGS       += -Wno-error=format-security -Wno-format-security
APP_OPTIM        := release

LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE            := HEXED_Resolution
LOCAL_SRC_FILES         := ../src/main.cpp \
                           ../mod/logger.cpp

LOCAL_C_INCLUDES        += $(LOCAL_PATH)/..
LOCAL_C_INCLUDES        += $(LOCAL_PATH)/../mod

LOCAL_LDLIBS            := -llog -ldl
LOCAL_CFLAGS            += -O2 -fvisibility=hidden -DNDEBUG -Wno-error=format-security
LOCAL_CPPFLAGS          += -std=c++17 -fvisibility=hidden -fno-exceptions -fno-rtti -DNDEBUG -Wno-error=format-security
LOCAL_ARM_MODE          := arm

include $(BUILD_SHARED_LIBRARY)

/*
 * HEXED Resolution — Lua/native command-file bridge implementation.
 *
 * Protocol documented in lua_bridge.h and README.md. Project-owned code
 * (see LICENSES.md).
 */
#include "lua_bridge.h"

#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <mutex>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>

#include <mod/amlmod.h>
#include <mod/logger.h>

#include "config.h"
#include "hexed_interface.h"
#include "logging.h"
#include "resolution_api.h"

namespace hxbridge
{
    namespace
    {
        const char* kCmdName = "bridge_cmd.txt";
        const char* kOutName = "bridge_out.txt";

        std::string g_dir;          /* .../files/hexed          */
        std::string g_cmdPath;
        std::string g_outPath;

        std::atomic<bool>   g_run{false};
        std::thread         g_worker;
        long                g_lastCmdSize = -1;

        const long kMaxCmdFile = 4096;   /* bytes; larger files are refused */
        const int  kMaxLinesPerPoll = 32;

        std::string ApplyCodeName(int code)
        {
            switch(code)
            {
                case 0:  return "OK";
                case 1:  return "QUEUED";
                case 2:  return "INVALID";
                case 3:  return "UNSUPPORTED";
                case 4:  return "FAILED";
                case 5:  return "DISABLED";
                default: return "INFO";
            }
        }

        std::string Trim(const std::string& s)
        {
            size_t b = 0, e = s.size();
            while(b < e && isspace((unsigned char)s[b])) ++b;
            while(e > b && isspace((unsigned char)s[e - 1])) --e;
            return s.substr(b, e - b);
        }

        void WriteOut(const std::string& line)
        {
            FILE* f = fopen(g_outPath.c_str(), "a");
            if(!f) return;
            fprintf(f, "%s\n", line.c_str());
            fclose(f);
        }

        void Respond(const std::string& cmd, int code, int w, int h, const std::string& text)
        {
            /* One line: CMD|CODE|w|h|text  (text may not contain newlines) */
            std::string t = text;
            for(size_t i = 0; i < t.size(); ++i)
                if(t[i] == '\n' || t[i] == '\r' || t[i] == '|') t[i] = ' ';
            WriteOut(cmd + "|" + ApplyCodeName(code) + "|" +
                     std::to_string(w) + "|" + std::to_string(h) + "|" + t);
        }

        int PresetFromName(const char* name)
        {
            if(!name || !name[0]) return hxres::PRESET_NONE;
            if(!strcmp(name, "p720"))    return hxres::PRESET_1280x720;
            if(!strcmp(name, "p540"))    return hxres::PRESET_960x540;
            if(!strcmp(name, "p450"))    return hxres::PRESET_800x450;
            if(!strcmp(name, "custom"))  return hxres::PRESET_CUSTOM;
            return hxres::PRESET_NONE;
        }

        bool ParseInt(const char*& p, int& out)
        {
            while(*p == ' ') ++p;
            if(!isdigit((unsigned char)*p) && *p != '-') return false;
            char* end = NULL;
            long v = strtol(p, &end, 10);
            if(end == p) return false;
            out = (int)v;
            p = end;
            return true;
        }

        void HandleLine(const std::string& raw)
        {
            std::string line = Trim(raw);
            if(line.empty() || line[0] == '#') return;

            hxlog::I("bridge: cmd '%s'", line.c_str());

            if(line == "status")
            {
                char buf[256];
                hxres::ResolutionAPI::Get().BuildStatusLine(buf, sizeof(buf));
                Respond("status", 6, 0, 0, buf);
            }
            else if(line == "probe")
            {
                hxres::RenderProbe p;
                hxres::RenderBackend::Get().Probe(p);
                char buf[192];
                snprintf(buf, sizeof(buf),
                         "RsGlobal %dx%d | surface %dx%d | vp %dx%d | gl %.24s",
                         p.rsValid ? p.rsWidth : -1, p.rsValid ? p.rsHeight : -1,
                         p.eglValid ? p.eglWidth : -1, p.eglValid ? p.eglHeight : -1,
                         p.glValid ? p.glViewport[2] : -1, p.glValid ? p.glViewport[3] : -1,
                         p.glRenderer[0] ? p.glRenderer : "n/a");
                Respond("probe", 6, 0, 0, buf);
            }
            else if(line.rfind("apply", 0) == 0)
            {
                const char* p = line.c_str() + 5;
                int w = 0, h = 0;
                if(!ParseInt(p, w) || !ParseInt(p, h))
                {
                    Respond("apply", 2, 0, 0, "usage: apply <width> <height> [preset]");
                    return;
                }
                while(*p == ' ') ++p;
                char presetName[24] = "";
                if(*p) snprintf(presetName, sizeof(presetName), "%s", p);
                else
                {
                    /* infer a preset name for bookkeeping */
                    if(w == 1280 && h == 720) snprintf(presetName, sizeof(presetName), "p720");
                    else if(w == 960 && h == 540) snprintf(presetName, sizeof(presetName), "p540");
                    else if(w == 800 && h == 450) snprintf(presetName, sizeof(presetName), "p450");
                    else snprintf(presetName, sizeof(presetName), "custom");
                }
                hxres::RequestResult r = hxres::ResolutionAPI::Get().Apply(w, h, PresetFromName(presetName));
                Respond("apply", (int)r.code, r.width, r.height, r.message);
            }
            else if(line == "reset")
            {
                hxres::RequestResult r = hxres::ResolutionAPI::Get().Reset();
                Respond("reset", (int)r.code, r.width, r.height, r.message);
            }
            else if(line.rfind("enable", 0) == 0)
            {
                const char* p = line.c_str() + 6;
                int on = 0;
                if(!ParseInt(p, on)) on = 1;
                hxres::RequestResult r = hxres::ResolutionAPI::Get().Enable(on != 0);
                Respond("enable", (int)r.code, 0, 0, r.message);
            }
            else if(line.rfind("save", 0) == 0)
            {
                const char* p = line.c_str() + 4;
                int w = 0, h = 0;
                char presetName[24] = "";
                if(ParseInt(p, w) && ParseInt(p, h))
                {
                    while(*p == ' ') ++p;
                    if(*p) snprintf(presetName, sizeof(presetName), "%s", p);
                }
                int preset = PresetFromName(presetName);
                if(preset == hxres::PRESET_NONE)
                {
                    Respond("save", 2, 0, 0, "usage: save <width> <height> <p720|p540|p450|custom>");
                    return;
                }
                hxres::RequestResult r = hxres::ResolutionAPI::Get().SaveSelection(w, h, preset);
                Respond("save", (int)r.code, w, h, r.message);
            }
            else if(line == "restore")
            {
                hxres::RequestResult r = hxres::ResolutionAPI::Get().RestoreSelection();
                Respond("restore", (int)r.code, r.width, r.height, r.message);
            }
            else if(line.rfind("log", 0) == 0)
            {
                const char* p = line.c_str() + 3;
                int n = 10;
                ParseInt(p, n);
                if(n < 1) n = 1;
                if(n > 32) n = 32;
                char buf[2048];
                hxlog::RecentLines(buf, sizeof(buf), n);
                for(size_t i = 0; i < strlen(buf); ++i)
                    if(buf[i] == '\n' || buf[i] == '\r') buf[i] = ' ';   /* keep one-line protocol */
                WriteOut(std::string("log|INFO|0|0|") + buf);
            }
            else if(line == "last")
            {
                hxres::RequestResult r;
                hxres::ResolutionAPI::Get().LastResult(r);
                if(!r.message[0])
                    Respond("last", 6, 0, 0, "no command executed yet this session");
                else
                    Respond("last", (int)r.code, r.width, r.height, r.message);
            }
            else if(line == "help")
            {
                WriteOut("help|INFO|0|0|commands: status, probe, apply <w> <h> [preset], "
                         "reset, enable <0|1>, save <w> <h> <preset>, restore, last, log [n], help");
            }
            else
            {
                Respond(line.substr(0, 16), 2, 0, 0, "unknown command; send 'help'");
            }
        }

        void WorkerLoop()
        {
            int tick = 0;
            while(g_run.load())
            {
                usleep(200 * 1000);   /* 200 ms poll — negligible impact */

                FILE* f = fopen(g_cmdPath.c_str(), "rb");
                if(!f) { g_lastCmdSize = -1; continue; }

                fseek(f, 0, SEEK_END);
                long size = ftell(f);
                fseek(f, 0, SEEK_SET);

                if(size <= 0 || size > kMaxCmdFile)
                {
                    fclose(f);
                    if(size > kMaxCmdFile)
                    {
                        remove(g_cmdPath.c_str());
                        Respond("error", 2, 0, 0, "command file too large; ignored and cleared");
                        g_lastCmdSize = -1;
                    }
                    continue;
                }

                /* Only process when the file is new or has grown. */
                if(size != g_lastCmdSize)
                {
                    g_lastCmdSize = size;
                    std::vector<char> buf(size + 1, 0);
                    size_t rd = fread(buf.data(), 1, size, f);
                    fclose(f);
                    buf[rd] = '\0';

                    int lines = 0;
                    char* ctx = NULL;
                    char* tok = strtok_r(buf.data(), "\n", &ctx);
                    while(tok && lines < kMaxLinesPerPoll)
                    {
                        HandleLine(tok);
                        ++lines;
                        tok = strtok_r(NULL, "\n", &ctx);
                    }

                    /* Consume: clear the command file so commands run once. */
                    FILE* c = fopen(g_cmdPath.c_str(), "wb");
                    if(c) fclose(c);
                    g_lastCmdSize = 0;
                }
                else
                {
                    fclose(f);
                }

                ++tick;
            }
        }
    }

    bool Start(const char* androidDataPath)
    {
        if(g_run.load()) return true;
        if(!androidDataPath || !androidDataPath[0]) return false;

        g_dir = std::string(androidDataPath) + "/hexed";
        g_cmdPath = g_dir + "/" + kCmdName;
        g_outPath = g_dir + "/" + kOutName;

        if(!aml->CreateDirRecursive(g_dir.c_str()))
        {
            hxlog::E("bridge: cannot create %s", g_dir.c_str());
            return false;
        }

        /* Truncate stale output; commands from a previous session are cleared. */
        FILE* o = fopen(g_outPath.c_str(), "wb");
        if(o)
        {
            fprintf(o, "hello|INFO|0|0|HEXED Resolution bridge online. Send 'help' to bridge_cmd.txt\n");
            fclose(o);
        }
        FILE* c = fopen(g_cmdPath.c_str(), "wb");
        if(c) fclose(c);
        g_lastCmdSize = 0;

        g_run = true;
        g_worker = std::thread(WorkerLoop);
        hxlog::I("bridge: online (%s)", g_dir.c_str());
        return true;
    }

    void Stop()
    {
        if(!g_run.load()) return;
        g_run = false;
        if(g_worker.joinable()) g_worker.join();
        hxlog::I("bridge: stopped");
    }

    const char* CmdPath() { return g_cmdPath.c_str(); }
    const char* OutPath() { return g_outPath.c_str(); }
}

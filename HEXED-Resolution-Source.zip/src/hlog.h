// HEXED Resolution - file log with a flush after every line (the last line before a crash shows where it died),
// plus tiny helpers for the stage / boot files used by the crash guard.
#ifndef HEXED_HLOG_H
#define HEXED_HLOG_H

namespace hexed {

const char* DataDir();                       // private writable dir (config); null if none
const char* PublicDir();                     // user-visible dir (log, stage); falls back to DataDir()
void        HLog(const char* fmt, ...);      // logcat (tag HEXED_Resolution) + <PublicDir>/hexed_resolution.log
bool        ReadIntFile(const char* name, int* v);    // in PublicDir()
bool        WriteIntFile(const char* name, int v);
void        RemoveFile(const char* name);

}

#endif

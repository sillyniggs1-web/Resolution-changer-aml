#include "hlog.h"
#include <mod/logger.h>

#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

namespace hexed {

static char g_pkg[128] = "";

static const char* Pkg()
{
    if (g_pkg[0]) return g_pkg;
    if (FILE* f = fopen("/proc/self/cmdline", "r")) {
        size_t n = fread(g_pkg, 1, sizeof(g_pkg) - 1, f);
        fclose(f);
        g_pkg[n] = 0;                          // first argument is NUL terminated
    }
    char* colon = strchr(g_pkg, ':'); if (colon) *colon = 0;
    return g_pkg;
}

static const char* PickDir(char* out, size_t n, const char* const* fmts, int count)
{
    if (out[0]) return out;
    const char* pkg = Pkg();
    if (!pkg[0]) return nullptr;
    for (int i = 0; i < count; ++i) {
        char p[256]; snprintf(p, sizeof(p), fmts[i], pkg);
        mkdir(p, 0771);
        if (access(p, W_OK) == 0) { snprintf(out, n, "%s", p); return out; }
    }
    return nullptr;
}

const char* DataDir()
{
    static char dir[256]; static bool tried = false;
    static const char* const f[] = { "/data/data/%s/files", "/data/user/0/%s/files", "/sdcard/Android/data/%s/files" };
    if (!tried) { tried = true; PickDir(dir, sizeof(dir), f, 3); }
    return dir[0] ? dir : nullptr;
}

const char* PublicDir()
{
    static char dir[256]; static bool tried = false;
    static const char* const f[] = { "/sdcard/Android/data/%s/files", "/storage/emulated/0/Android/data/%s/files" };
    if (!tried) { tried = true; PickDir(dir, sizeof(dir), f, 2); }
    return dir[0] ? dir : DataDir();
}

static bool PublicPath(char* out, size_t n, const char* file)
{
    const char* d = PublicDir();
    if (!d) return false;
    snprintf(out, n, "%s/%s", d, file);
    return true;
}

void HLog(const char* fmt, ...)
{
    char msg[512];
    va_list ap; va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    logger->Info("%s", msg);

    char p[300];
    if (!PublicPath(p, sizeof(p), "hexed_resolution.log")) return;
    int fd = open(p, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd < 0) return;
    char line[560];
    int n = snprintf(line, sizeof(line), "[%ld] %s\n", (long)time(nullptr) % 100000, msg);
    if (n > 0) { if (write(fd, line, (size_t)n) < 0) {} fsync(fd); }
    close(fd);
}

bool ReadIntFile(const char* name, int* v)
{
    char p[300]; if (!PublicPath(p, sizeof(p), name)) return false;
    FILE* f = fopen(p, "r"); if (!f) return false;
    int x = 0; bool ok = fscanf(f, "%d", &x) == 1;
    fclose(f);
    if (ok) *v = x;
    return ok;
}

bool WriteIntFile(const char* name, int v)
{
    char p[300]; if (!PublicPath(p, sizeof(p), name)) return false;
    FILE* f = fopen(p, "w"); if (!f) return false;
    fprintf(f, "%d\n", v);
    fflush(f); fsync(fileno(f));
    fclose(f);
    return true;
}

void RemoveFile(const char* name) { char p[300]; if (PublicPath(p, sizeof(p), name)) unlink(p); }

} // namespace hexed

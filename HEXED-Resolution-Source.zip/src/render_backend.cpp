/*
 * HEXED Resolution — rendering backend implementation.
 *
 * Verified mechanism (see render_backend.h header comment for the full
 * safety model). PSDK pin values and struct layout come from the vendored
 * aml-psdk headers (GPL-3.0) — no offsets in this file are invented by the
 * HEXED project; the only user-suppliable offsets come from the INI profile
 * and are gated behind UseCustomProfile=true plus the same plausibility
 * checks.
 *
 * Project-owned code (see LICENSES.md).
 */
#include "render_backend.h"

#include <EGL/egl.h>
#include <GLES2/gl2.h>

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <aml-psdk/game_sa/engine/RsGlobal.h>   /* RsGlobalType + pinned pointer */

#include "logging.h"

namespace hxres
{
    static const int    kPlausibleMin = 256;
    static const int    kPlausibleMax = 7680;

    RenderBackend& RenderBackend::Get()
    {
        static RenderBackend inst;
        return inst;
    }

    RenderBackend::RenderBackend()
        : m_libBase(0), m_libLength(0)
        , m_rsGlobalPtrAddr(0), m_rsGlobalAddr(0)
        , m_compat(COMPAT_UNCHECKED)
        , m_pinVersionMask(0)
        , m_origW(0), m_origH(0), m_origValid(0)
        , m_applied(false), m_appliedW(0), m_appliedH(0)
    {
        m_compatReason[0] = '\0';
    }

    void RenderBackend::InitCompat(uintptr_t libBase, size_t libLength,
                                   bool useCustomProfile,
                                   int64_t customPtrOffset32, int64_t customPtrOffset64)
    {
        if(m_compat == COMPAT_OK) return;   /* no re-running after success */

        m_libBase = libBase;
        m_libLength = libLength;

        if(!libBase || !libLength)
        {
            m_compat = COMPAT_UNSUPPORTED;
            snprintf(m_compatReason, sizeof(m_compatReason),
                     "game library libGTASA.so not found");
            hxlog::E("compat: %s", m_compatReason);
            return;
        }

        hxlog::I("compat: libGTASA.so base=" PTRFMT " len=" PTRNUMFMT, libBase, libLength);

        /* Choose the pointer-offset profile. */
        uint32_t offset = 0;
        if(useCustomProfile && customPtrOffset32 > 0 && customPtrOffset64 > 0)
        {
            offset = (uint32_t)BYBIT(customPtrOffset32, customPtrOffset64);
            m_pinVersionMask = 0x4;
            hxlog::W("compat: using CUSTOM offset profile (0x%X) — provided by user config", offset);
        }
        else
        {
            /* Vendored aml-psdk pins: RsGlobal pointer for SA v2.00 (32-bit)
             * and v2.10 (64-bit). */
            offset = (uint32_t)BYBIT(0x67910C, 0x850240);
            m_pinVersionMask = BYBIT(0x1, 0x2);
#ifdef AML32
            hxlog::I("compat: PSDK profile GTA:SA v2.00 (armeabi-v7a), RsGlobal ptr offset 0x%X", offset);
#else
            hxlog::I("compat: PSDK profile GTA:SA v2.10 (arm64-v8a), RsGlobal ptr offset 0x%X", offset);
#endif
        }

        if((uint64_t)offset + sizeof(uintptr_t) > (uint64_t)libLength)
        {
            m_compat = COMPAT_UNSUPPORTED;
            snprintf(m_compatReason, sizeof(m_compatReason),
                     "RsGlobal pointer offset 0x%X outside mapped library (unsupported build?)", offset);
            hxlog::E("compat: %s", m_compatReason);
            return;
        }

        m_rsGlobalPtrAddr = libBase + offset;
        if(ResolveRsGlobal())
        {
            m_compat = COMPAT_OK;
            snprintf(m_compatReason, sizeof(m_compatReason), "RsGlobal located and validated");
            hxlog::I("compat: RsGlobal OK at " PTRFMT " (current %dx%d)",
                     m_rsGlobalAddr, m_origW, m_origH);
        }
        else
        {
            m_compat = COMPAT_UNSUPPORTED;
            /* m_compatReason already set by ResolveRsGlobal */
            hxlog::E("compat: %s", m_compatReason);
        }
    }

    bool RenderBackend::ResolveRsGlobal()
    {
        /* Read-only audit. Never writes. Dereferences only addresses that
         * are proven to be inside the mapped library. */
#ifdef AML32
        uintptr_t ptrVal = (uintptr_t)aml->Read32(m_rsGlobalPtrAddr);
#else
        uintptr_t ptrVal = (uintptr_t)aml->Read64(m_rsGlobalPtrAddr);
#endif
        if(ptrVal < m_libBase || ptrVal + sizeof(RsGlobalType) > m_libBase + m_libLength)
        {
            snprintf(m_compatReason, sizeof(m_compatReason),
                     "RsGlobal pointer " PTRFMT " outside libGTASA mapping (unsupported game build; "
                     "supply a verified offset profile in HexedResolution.ini)", ptrVal);
            return false;
        }
        m_rsGlobalAddr = ptrVal;

        int w = aml->Read32(m_rsGlobalAddr + offsetof(RsGlobalType, maximumWidth));
        int h = aml->Read32(m_rsGlobalAddr + offsetof(RsGlobalType, maximumHeight));
        if(w < kPlausibleMin || w > kPlausibleMax || h < kPlausibleMin || h > kPlausibleMax)
        {
            snprintf(m_compatReason, sizeof(m_compatReason),
                     "RsGlobal dimensions %dx%d failed plausibility check (unsupported game build)", w, h);
            return false;
        }

        m_origW = w;
        m_origH = h;
        m_origValid = 1;
        return true;
    }

    bool RenderBackend::ReadRsGlobal(int& w, int& h)
    {
        if(m_compat != COMPAT_OK) return false;
        w = aml->Read32(m_rsGlobalAddr + offsetof(RsGlobalType, maximumWidth));
        h = aml->Read32(m_rsGlobalAddr + offsetof(RsGlobalType, maximumHeight));
        return (w > 0 && h > 0);
    }

    bool RenderBackend::WriteRsGlobal(int w, int h)
    {
        if(m_compat != COMPAT_OK) return false;
        uintptr_t aW = m_rsGlobalAddr + offsetof(RsGlobalType, maximumWidth);
        uintptr_t aH = m_rsGlobalAddr + offsetof(RsGlobalType, maximumHeight);
        aml->Write32(aW, (uint32_t)w);
        aml->Write32(aH, (uint32_t)h);
        int rw = aml->Read32(aW), rh = aml->Read32(aH);
        return (rw == w && rh == h);
    }

    void RenderBackend::Probe(RenderProbe& out)
    {
        memset(&out, 0, sizeof(out));

        out.rsValid = ReadRsGlobal(out.rsWidth, out.rsHeight);
        if(!out.rsValid) { out.rsWidth = 0; out.rsHeight = 0; }

        /* EGL/GLES diagnostics — valid only on a thread with the game's
         * context current (the game thread). Guarded, never fatal. */
        EGLDisplay dpy = eglGetCurrentDisplay();
        EGLSurface surf = (dpy != EGL_NO_DISPLAY) ? eglGetCurrentSurface(EGL_DRAW) : EGL_NO_SURFACE;
        if(dpy != EGL_NO_DISPLAY && surf != EGL_NO_SURFACE)
        {
            EGLint sw = 0, sh = 0;
            if(eglQuerySurface(dpy, surf, EGL_WIDTH, &sw) &&
               eglQuerySurface(dpy, surf, EGL_HEIGHT, &sh))
            {
                out.eglValid = true;
                out.eglWidth = (int)sw;
                out.eglHeight = (int)sh;
            }
        }

        if(eglGetCurrentContext() != EGL_NO_CONTEXT)
        {
            GLint vp[4] = {0, 0, 0, 0};
            glGetError();                       /* clear pending GL errors   */
            glGetIntegerv(GL_VIEWPORT, vp);
            if(glGetError() == GL_NO_ERROR)     /* GL query actually worked  */
            {
                out.glValid = true;
                for(int i = 0; i < 4; ++i) out.glViewport[i] = (int)vp[i];
            }
            const GLubyte* r = glGetString(GL_RENDERER);
            const GLubyte* v = glGetString(GL_VERSION);
            if(r) snprintf(out.glRenderer, sizeof(out.glRenderer), "%s", (const char*)r);
            if(v) snprintf(out.glVersion, sizeof(out.glVersion), "%s", (const char*)v);
        }
    }

    ApplyResult RenderBackend::Apply(int w, int h)
    {
        ApplyResult r; r.code = APPLY_FAILED; r.width = 0; r.height = 0; r.message[0] = '\0';

        if(m_compat != COMPAT_OK)
        {
            r.code = APPLY_UNSUPPORTED;
            snprintf(r.message, sizeof(r.message), "%s", m_compatReason);
            return r;
        }
        if(!m_origValid)
        {
            r.code = APPLY_UNSUPPORTED;
            snprintf(r.message, sizeof(r.message), "original dimensions unknown; cannot modify safely");
            return r;
        }

        if(!WriteRsGlobal(w, h))
        {
            r.code = APPLY_FAILED;
            snprintf(r.message, sizeof(r.message),
                     "write rejected or read-back mismatch (memory protected?)");
            hxlog::E("apply: %s", r.message);
            return r;
        }

        if(!m_applied)
        {
            m_applied = true;   /* originals were captured in ResolveRsGlobal */
        }
        m_appliedW = w;
        m_appliedH = h;

        r.code = APPLY_OK;
        r.width = w;
        r.height = h;
        snprintf(r.message, sizeof(r.message),
                 "RsGlobal set to %dx%d (was %dx%d)", w, h, m_origW, m_origH);
        hxlog::I("apply: %s", r.message);
        return r;
    }

    ApplyResult RenderBackend::Reset()
    {
        ApplyResult r; r.code = APPLY_FAILED; r.width = 0; r.height = 0; r.message[0] = '\0';

        if(m_compat != COMPAT_OK)
        {
            r.code = APPLY_UNSUPPORTED;
            snprintf(r.message, sizeof(r.message), "%s", m_compatReason);
            return r;
        }
        if(!m_origValid || !m_applied)
        {
            r.code = APPLY_OK;
            snprintf(r.message, sizeof(r.message), "nothing to reset (no successful apply)");
            return r;
        }

        if(!WriteRsGlobal(m_origW, m_origH))
        {
            r.code = APPLY_FAILED;
            snprintf(r.message, sizeof(r.message), "reset write failed");
            hxlog::E("reset: %s", r.message);
            return r;
        }

        r.code = APPLY_OK;
        r.width = m_origW;
        r.height = m_origH;
        snprintf(r.message, sizeof(r.message), "restored original %dx%d", m_origW, m_origH);
        hxlog::I("reset: %s", r.message);
        m_applied = false;
        m_appliedW = 0;
        m_appliedH = 0;
        return r;
    }

    bool RenderBackend::Drifted()
    {
        if(!m_applied) return false;
        int w = 0, h = 0;
        if(!ReadRsGlobal(w, h)) return false;
        return (w != m_appliedW || h != m_appliedH);
    }
}

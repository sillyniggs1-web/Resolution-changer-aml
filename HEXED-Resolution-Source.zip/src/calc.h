// HEXED Resolution - pure math helpers (no Android / AML dependencies, unit-testable on a PC).
#ifndef HEXED_CALC_H
#define HEXED_CALC_H

#include <stdint.h>

namespace hexed { namespace calc {

static const int MIN_W    = 320;
static const int MIN_H    = 180;
static const int MAX_SIDE = 4096;

enum Mode {
    MODE_NONE   = 0,   // native resolution, no override
    MODE_SCALE  = 1,   // percent of the native size
    MODE_HEIGHT = 2,   // target height, width follows the screen shape
    MODE_SIZE   = 3    // explicit width x height
};

inline int  Even(int v)            { return v & ~1; }
inline bool IsSane(int w, int h)   { return w >= MIN_W && h >= MIN_H && w <= MAX_SIDE && h <= MAX_SIDE; }

// Size the game should render at for the requested mode. False if it cannot be satisfied.
inline bool Compute(int mode, int pct, int reqW, int reqH, int nativeW, int nativeH, int* outW, int* outH)
{
    if (nativeW <= 0 || nativeH <= 0 || !outW || !outH) return false;
    int w = 0, h = 0;
    switch (mode) {
    case MODE_SCALE:
        if (pct <= 0 || pct > 100) return false;
        w = Even((int)((int64_t)nativeW * pct / 100));
        h = Even((int)((int64_t)nativeH * pct / 100));
        if (w < MIN_W) w = MIN_W;
        if (h < MIN_H) h = MIN_H;
        break;
    case MODE_HEIGHT:
        h = Even(reqH);
        if (h < MIN_H) return false;
        w = Even((int)(((int64_t)h * nativeW + nativeH / 2) / nativeH));
        break;
    case MODE_SIZE:
        w = reqW;
        h = reqH;
        break;
    default:
        return false;
    }
    if (!IsSane(w, h)) return false;
    *outW = w;
    *outH = h;
    return true;
}

// Android touch space (nativeSize pixels) -> game window space (activeSize pixels).
// Negative values are "no pointer" sentinels in the multi-touch call, so they pass through.
inline int MapCoord(int v, int nativeSize, int activeSize)
{
    if (v < 0 || nativeSize <= 0 || activeSize <= 0 || nativeSize == activeSize) return v;
    int64_t m = ((int64_t)v * activeSize + nativeSize / 2) / nativeSize;
    if (m >= activeSize) m = activeSize - 1;
    return (int)m;
}

}} // namespace hexed::calc

#endif

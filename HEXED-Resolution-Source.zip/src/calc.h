// HEXED Resolution - pure math helpers (no Android / AML dependencies, unit-testable on a PC).
#ifndef HEXED_CALC_H
#define HEXED_CALC_H

#include <stdint.h>

namespace hexed { namespace calc {

static const int MIN_W    = 320;
static const int MIN_H    = 180;
static const int MAX_SIDE = 4096;

enum Mode {
    MODE_NONE   = 0,   // native resolution, no override
    MODE_SCALE  = 1,   // percent of the native size
    MODE_HEIGHT = 2,   // target height, width follows the screen shape
    MODE_SIZE   = 3    // explicit width x height
};

inline int  Even(int v)            { return v & ~1; }
inline bool IsSane(int w, int h)   { return w >= MIN_W && h >= MIN_H && w <= MAX_SIDE && h <= MAX_SIDE; }

// Size the game should render at for the requested mode. False if it cannot be satisfied.
inline bool Compute(int mode, int pct, int reqW, int reqH, int nativeW, int nativeH, int* outW, int* outH)
{
    if (nativeW <= 0 || nativeH <= 0 || !outW || !outH) return false;
    int w = 0, h = 0;
    switch (mode) {
    case MODE_SCALE:
        if (pct <= 0 || pct > 100) return false;
        w = Even((int)((int64_t)nativeW * pct / 100));
        h = Even((int)((int64_t)nativeH * pct / 100));
        if (w < MIN_W) w = MIN_W;
        if (h < MIN_H) h = MIN_H;
        break;
    case MODE_HEIGHT:
        h = Even(reqH);
        if (h < MIN_H) return false;
        w = Even((int)(((int64_t)h * nativeW + nativeH / 2) / nativeH));
        break;
    case MODE_SIZE:
        w = reqW;
        h = reqH;
        break;
    default:
        return false;
    }
    if (!IsSane(w, h)) return false;
    *outW = w;
    *outH = h;
    return true;
}

// Largest box with the aspect ratio of (w x h) that fits inside the screen (letter/pillar boxed, centered).
// Result within 2 px of the screen size snaps to it, so a screen-shaped request leaves no bars.
inline void FitBox(int w, int h, int screenW, int screenH, int* boxW, int* boxH)
{
    if (w <= 0 || h <= 0 || screenW <= 0 || screenH <= 0) { *boxW = screenW; *boxH = screenH; return; }
    int64_t a = (int64_t)screenW * h, b = (int64_t)screenH * w;     // screenW/w <= screenH/h  <=>  a <= b
    int bw, bh;
    if (a <= b) { bw = screenW; bh = (int)(((int64_t)h * screenW + w / 2) / w); }
    else        { bh = screenH; bw = (int)(((int64_t)w * screenH + h / 2) / h); }
    if (bw > screenW - 3) bw = screenW;
    if (bh > screenH - 3) bh = screenH;
    *boxW = bw; *boxH = bh;
}

// A real window of exactly w x h pixels when it fits; larger requests are scaled down (shape kept) to fit the screen.
inline void FitDown(int w, int h, int screenW, int screenH, int* boxW, int* boxH)
{
    if (w > 0 && h > 0 && w <= screenW && h <= screenH) { *boxW = w; *boxH = h; return; }
    FitBox(w, h, screenW, screenH, boxW, boxH);
}

// Android touch space (nativeSize pixels) -> game window space (activeSize pixels).
// Negative values are "no pointer" sentinels in the multi-touch call, so they pass through.
inline int MapCoord(int v, int nativeSize, int activeSize)
{
    if (v < 0 || nativeSize <= 0 || activeSize <= 0 || nativeSize == activeSize) return v;
    int64_t m = ((int64_t)v * activeSize + nativeSize / 2) / nativeSize;
    if (m >= activeSize) m = activeSize - 1;
    return (int)m;
}

// Window coordinates (x, y) -> game coordinates. Subtract the box origin, clamp into the box, scale view size -> render size.
// Returns false when the point is outside the box (in the black bars).
inline bool MapTouch(int x, int y, int offX, int offY, int viewW, int viewH, int actW, int actH, int* ox, int* oy)
{
    if (viewW <= 0 || viewH <= 0 || actW <= 0 || actH <= 0) { *ox = x; *oy = y; return true; }
    int lx = x - offX, ly = y - offY;
    const bool inside = lx >= 0 && ly >= 0 && lx < viewW && ly < viewH;
    if (lx < 0) lx = 0;
    if (lx >= viewW) lx = viewW - 1;
    if (ly < 0) ly = 0;
    if (ly >= viewH) ly = viewH - 1;
    *ox = MapCoord(lx, viewW, actW);
    *oy = MapCoord(ly, viewH, actH);
    return inside;
}

}} // namespace hexed::calc

#endif

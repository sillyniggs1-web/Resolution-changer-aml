// HEXED Resolution - locate JNI natives registered through a static JNINativeMethod table.
// Pure logic (no AML / Android calls) so it can be unit-tested on a PC against the real libGTASA.so image.
#ifndef HEXED_SCAN_H
#define HEXED_SCAN_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace hexed { namespace scan {

struct Seg { uintptr_t b, e; unsigned flags; };       // loaded PT_LOAD range [b, e) + p_flags
static const unsigned F_X = 1, F_W = 2, F_R = 4;      // same values as PF_X / PF_W / PF_R

inline bool In(const Seg* s, int n, uintptr_t a, size_t len, unsigned need = 0)
{
    for (int i = 0; i < n; ++i)
        if (a >= s[i].b && a + len <= s[i].e && (s[i].flags & need) == need) return true;
    return false;
}

// Finds {const char* name; const char* sig; void* fn;} and returns fn (thumb bit kept).
// Both strings must match exactly and fn must point into an executable segment.
// W is the table word type (uintptr_t on the device; uint32_t lets a PC test a 32-bit image).
template <typename W>
inline bool FindNativeT(const Seg* s, int n, const char* name, const char* sig, uintptr_t* fnOut)
{
    const size_t nl = strlen(name) + 1, sl = strlen(sig) + 1, ws = sizeof(W);
    for (int pass = 0; pass < 2; ++pass) {             // pass 0: writable data only, pass 1: everything
        for (int i = 0; i < n; ++i) {
            if (pass == 0 && !(s[i].flags & F_W)) continue;
            for (uintptr_t p = (s[i].b + ws - 1) & ~(uintptr_t)(ws - 1); p + 3 * ws <= s[i].e; p += ws) {
                const W* w = (const W*)p;
                if (!In(s, n, (uintptr_t)w[0], nl))                 continue;
                if (memcmp((const void*)(uintptr_t)w[0], name, nl)) continue;
                if (!In(s, n, (uintptr_t)w[1], sl))                 continue;
                if (memcmp((const void*)(uintptr_t)w[1], sig, sl))  continue;
                if (!In(s, n, (uintptr_t)w[2] & ~(uintptr_t)1, 2, F_X)) continue;
                *fnOut = (uintptr_t)w[2];
                return true;
            }
        }
    }
    return false;
}
inline bool FindNative(const Seg* s, int n, const char* name, const char* sig, uintptr_t* fnOut)
{
    return FindNativeT<uintptr_t>(s, n, name, sig, fnOut);
}

// Compare the first `cnt` Thumb halfwords of a function with the bytes seen in the reference build.
inline bool Prologue(uintptr_t fn, const uint16_t* expect, int cnt)
{
    const uint16_t* c = (const uint16_t*)(fn & ~(uintptr_t)1);
    for (int i = 0; i < cnt; ++i) if (c[i] != expect[i]) return false;
    return true;
}

}} // namespace hexed::scan

#endif

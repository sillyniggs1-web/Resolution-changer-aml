/*
 * HEXED Resolution 0.3.0
 * Target: SA-MP Nezuko v1.0.3 (TESTING) — armeabi-v7a
 *
 * Matches Lua 4.0.0 API surface:
 *   Scale mode (recommended): percent of native render size
 *   Window mode (experimental): OS_ScreenSetResolution path
 *
 * Real symbols from libGTASA.so:
 *   OS_ScreenSetResolution / OS_ScreenGetWidth / OS_ScreenGetHeight
 *   RsGlobal, renderWidth, renderHeight
 *   CDraw::ms_fAspectRatio / CalculateAspectRatio
 */

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <unistd.h>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 0.3.0, HEXED)

#pragma pack(push, 1)
struct RsGlobalType {
    const char* appName;
    int32_t     maximumWidth;
    int32_t     maximumHeight;
    int32_t     maxFPS;
    int32_t     quit;
    void*       ps;
};
#pragma pack(pop)

typedef void (*OS_ScreenSetResolution_t)(unsigned int, unsigned int);
typedef int  (*OS_ScreenGetWidth_t)();
typedef int  (*OS_ScreenGetHeight_t)();
typedef void (*CalculateAspectRatio_t)();

static uintptr_t pGTASA = 0;

static RsGlobalType* g_RsGlobal     = nullptr;
static int32_t*      g_renderWidth  = nullptr;
static int32_t*      g_renderHeight = nullptr;
static float*        g_aspectRatio  = nullptr;

static OS_ScreenSetResolution_t  OS_ScreenSetResolution = nullptr;
static OS_ScreenGetWidth_t       OS_ScreenGetWidth      = nullptr;
static OS_ScreenGetHeight_t      OS_ScreenGetHeight     = nullptr;
static CalculateAspectRatio_t    CalculateAspectRatio   = nullptr;

// Native (device / game) size captured once
static int32_t g_nativeW = 0;
static int32_t g_nativeH = 0;
static bool    g_ready   = false;

// Active overrides
static bool    g_scaleOverride  = false;
static bool    g_windowOverride = false;
static int32_t g_scalePercent   = 100;   // 0-100
static int32_t g_activeW        = 0;
static int32_t g_activeH        = 0;

// Safe-mode: marker written before risky apply, cleared after success
static bool    g_wasSafeMode = false;

static const int MIN_W = 320;
static const int MIN_H = 180;
static const int MAX_SIDE = 4096;

// ---------- helpers ----------

static bool IsSane(int w, int h)
{
    return w >= MIN_W && h >= MIN_H && w <= MAX_SIDE && h <= MAX_SIDE;
}

static int ReadScreenW()
{
    if (OS_ScreenGetWidth) {
        int w = OS_ScreenGetWidth();
        if (w > 0) return w;
    }
    if (g_RsGlobal && g_RsGlobal->maximumWidth > 0)
        return g_RsGlobal->maximumWidth;
    if (g_renderWidth && *g_renderWidth > 0)
        return *g_renderWidth;
    return 0;
}

static int ReadScreenH()
{
    if (OS_ScreenGetHeight) {
        int h = OS_ScreenGetHeight();
        if (h > 0) return h;
    }
    if (g_RsGlobal && g_RsGlobal->maximumHeight > 0)
        return g_RsGlobal->maximumHeight;
    if (g_renderHeight && *g_renderHeight > 0)
        return *g_renderHeight;
    return 0;
}

static void WriteGlobals(int w, int h)
{
    if (g_RsGlobal) {
        aml->Unprot(reinterpret_cast<uintptr_t>(g_RsGlobal), sizeof(RsGlobalType));
        aml->Write32(reinterpret_cast<uintptr_t>(&g_RsGlobal->maximumWidth),  (uint32_t)w);
        aml->Write32(reinterpret_cast<uintptr_t>(&g_RsGlobal->maximumHeight), (uint32_t)h);
        g_RsGlobal->maximumWidth  = w;
        g_RsGlobal->maximumHeight = h;
    }
    if (g_renderWidth) {
        aml->Unprot(reinterpret_cast<uintptr_t>(g_renderWidth), 8);
        aml->Write32(reinterpret_cast<uintptr_t>(g_renderWidth), (uint32_t)w);
        *g_renderWidth = w;
    }
    if (g_renderHeight) {
        aml->Write32(reinterpret_cast<uintptr_t>(g_renderHeight), (uint32_t)h);
        *g_renderHeight = h;
    }
    if (g_aspectRatio && h > 0) {
        float ar = (float)w / (float)h;
        aml->Unprot(reinterpret_cast<uintptr_t>(g_aspectRatio), sizeof(float));
        aml->WriteFloat(reinterpret_cast<uintptr_t>(g_aspectRatio), ar);
        *g_aspectRatio = ar;
    }
    if (CalculateAspectRatio)
        CalculateAspectRatio();
}

static bool ApplyResolution(int w, int h)
{
    if (!IsSane(w, h)) {
        logger->Error("Reject %dx%d", w, h);
        return false;
    }
    if (OS_ScreenSetResolution) {
        OS_ScreenSetResolution((unsigned)w, (unsigned)h);
        logger->Info("OS_ScreenSetResolution(%d, %d)", w, h);
    } else {
        logger->Error("OS_ScreenSetResolution missing");
        return false;
    }
    WriteGlobals(w, h);
    g_activeW = w;
    g_activeH = h;
    return true;
}

// Config paths (Nezuko + common)
static const char* CFG_PATHS[] = {
    "/sdcard/Android/data/com.nezukosamp.game/files/hexed_resolution.cfg",
    "/sdcard/Android_unprotected/data/com.nezukosamp.game/files/hexed_resolution.cfg",
    "/sdcard/Android/data/com.rockstargames.gtasa/files/hexed_resolution.cfg",
    "/sdcard/hexed_resolution.cfg",
    nullptr
};
static const char* MARKER_PATHS[] = {
    "/sdcard/Android/data/com.nezukosamp.game/files/hexed_resolution.pending",
    "/sdcard/Android_unprotected/data/com.nezukosamp.game/files/hexed_resolution.pending",
    "/sdcard/hexed_resolution.pending",
    nullptr
};

static void WriteMarker()
{
    for (int i = 0; MARKER_PATHS[i]; ++i) {
        FILE* f = fopen(MARKER_PATHS[i], "w");
        if (f) { fputs("1\n", f); fclose(f); return; }
    }
}

static void ClearMarker()
{
    for (int i = 0; MARKER_PATHS[i]; ++i)
        unlink(MARKER_PATHS[i]);
}

static bool MarkerExists()
{
    for (int i = 0; MARKER_PATHS[i]; ++i) {
        FILE* f = fopen(MARKER_PATHS[i], "r");
        if (f) { fclose(f); return true; }
    }
    return false;
}

static void SaveConfig()
{
    for (int i = 0; CFG_PATHS[i]; ++i) {
        FILE* f = fopen(CFG_PATHS[i], "w");
        if (f) {
            // format: scalePercent windowOverrideW windowOverrideH
            fprintf(f, "%d %d %d\n",
                    g_scaleOverride ? g_scalePercent : 100,
                    g_windowOverride ? g_activeW : 0,
                    g_windowOverride ? g_activeH : 0);
            fclose(f);
            return;
        }
    }
}

static void LoadConfig()
{
    for (int i = 0; CFG_PATHS[i]; ++i) {
        FILE* f = fopen(CFG_PATHS[i], "r");
        if (!f) continue;
        int pct = 100, ww = 0, wh = 0;
        if (fscanf(f, "%d %d %d", &pct, &ww, &wh) >= 1) {
            if (pct < 0) pct = 0;
            if (pct > 100) pct = 100;
            g_scalePercent = pct;
            if (pct != 100) g_scaleOverride = true;
            if (ww > 0 && wh > 0 && IsSane(ww, wh)) {
                g_windowOverride = true;
                g_activeW = ww;
                g_activeH = wh;
            }
        }
        fclose(f);
        return;
    }
}

static void TryBecomeReady()
{
    if (g_ready) return;
    int w = ReadScreenW();
    int h = ReadScreenH();
    if (!IsSane(w, h)) return;

    g_nativeW = w;
    g_nativeH = h;
    g_activeW = w;
    g_activeH = h;
    g_ready = true;
    logger->Info("Ready. native=%dx%d", g_nativeW, g_nativeH);

    // Safe mode: previous run crashed while applying
    if (MarkerExists()) {
        logger->Error("Safe mode: pending marker found – clearing saved setting");
        g_wasSafeMode = true;
        ClearMarker();
        g_scaleOverride = false;
        g_windowOverride = false;
        g_scalePercent = 100;
        // wipe config
        for (int i = 0; CFG_PATHS[i]; ++i) unlink(CFG_PATHS[i]);
        return;
    }

    LoadConfig();

    // Auto-apply saved scale or window
    if (g_windowOverride && IsSane(g_activeW, g_activeH)) {
        WriteMarker();
        if (ApplyResolution(g_activeW, g_activeH)) {
            ClearMarker();
            logger->Info("Restored window %dx%d", g_activeW, g_activeH);
        } else {
            ClearMarker();
            g_windowOverride = false;
        }
    } else if (g_scaleOverride && g_scalePercent != 100) {
        int tw = (g_nativeW * g_scalePercent) / 100;
        int th = (g_nativeH * g_scalePercent) / 100;
        if (tw < MIN_W) tw = MIN_W;
        if (th < MIN_H) th = MIN_H;
        WriteMarker();
        if (ApplyResolution(tw, th)) {
            ClearMarker();
            logger->Info("Restored scale %d%% -> %dx%d", g_scalePercent, tw, th);
        } else {
            ClearMarker();
            g_scaleOverride = false;
            g_scalePercent = 100;
        }
    }
}

// ---------- exported API (Lua 4.0.0) ----------

extern "C" {

__attribute__((visibility("default")))
int HEXED_IsReady()
{
    if (!g_ready) TryBecomeReady();
    return g_ready ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_GetOverride()
{
    return (g_scaleOverride || g_windowOverride) ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_WasSafeMode()
{
    return g_wasSafeMode ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_GetNativeW() { return g_nativeW; }

__attribute__((visibility("default")))
int HEXED_GetNativeH() { return g_nativeH; }

__attribute__((visibility("default")))
int HEXED_GetCurrentW() { return ReadScreenW(); }

__attribute__((visibility("default")))
int HEXED_GetCurrentH() { return ReadScreenH(); }

__attribute__((visibility("default")))
int HEXED_GetActiveW() { return g_activeW; }

__attribute__((visibility("default")))
int HEXED_GetActiveH() { return g_activeH; }

__attribute__((visibility("default")))
int HEXED_GetMaxSide() { return MAX_SIDE; }

__attribute__((visibility("default")))
int HEXED_GetMinW() { return MIN_W; }

__attribute__((visibility("default")))
int HEXED_GetMinH() { return MIN_H; }

// Window size path (experimental)
__attribute__((visibility("default")))
int HEXED_SetSize(int w, int h)
{
    if (!g_ready) TryBecomeReady();
    if (!g_ready) return 0;
    if (!IsSane(w, h)) return 0;

    WriteMarker();
    if (!ApplyResolution(w, h)) {
        ClearMarker();
        return 0;
    }
    ClearMarker();
    g_windowOverride = true;
    g_scaleOverride  = false;
    g_scalePercent   = 100;
    SaveConfig();
    return 1;
}

__attribute__((visibility("default")))
int HEXED_Reset()
{
    if (!g_ready) return 0;
    WriteMarker();
    if (!ApplyResolution(g_nativeW, g_nativeH)) {
        ClearMarker();
        return 0;
    }
    ClearMarker();
    g_windowOverride = false;
    g_scaleOverride  = false;
    g_scalePercent   = 100;
    g_activeW = g_nativeW;
    g_activeH = g_nativeH;
    SaveConfig();
    return 1;
}

// Scale path (recommended)
__attribute__((visibility("default")))
int HEXED_ScaleAvailable()
{
    return (g_ready && OS_ScreenSetResolution) ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_GetScaleOverride()
{
    return g_scaleOverride ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_GetScalePercent()
{
    return g_scalePercent;
}

__attribute__((visibility("default")))
int HEXED_GetScaleOriginal()
{
    return 100;
}

__attribute__((visibility("default")))
int HEXED_PercentToWidth(int p)
{
    if (p < 0) p = 0;
    if (p > 100) p = 100;
    if (!g_ready || g_nativeW <= 0) return 0;
    int w = (g_nativeW * p) / 100;
    if (w < MIN_W) w = MIN_W;
    return w;
}

__attribute__((visibility("default")))
int HEXED_PercentToHeight(int p)
{
    if (p < 0) p = 0;
    if (p > 100) p = 100;
    if (!g_ready || g_nativeH <= 0) return 0;
    int h = (g_nativeH * p) / 100;
    if (h < MIN_H) h = MIN_H;
    return h;
}

__attribute__((visibility("default")))
int HEXED_WidthToPercent(int w)
{
    if (!g_ready || g_nativeW <= 0) return -1;
    if (w <= 0) return 0;
    int p = (w * 100) / g_nativeW;
    if (p < 0) p = 0;
    if (p > 100) p = 100;
    return p;
}

__attribute__((visibility("default")))
int HEXED_SetScale(int p)
{
    if (!g_ready) TryBecomeReady();
    if (!g_ready) return 0;
    if (p < 0 || p > 100) return 0;

    int tw = HEXED_PercentToWidth(p);
    int th = HEXED_PercentToHeight(p);

    WriteMarker();
    if (!ApplyResolution(tw, th)) {
        ClearMarker();
        return 0;
    }
    ClearMarker();
    g_scalePercent   = p;
    g_scaleOverride  = (p != 100);
    g_windowOverride = false;
    SaveConfig();
    logger->Info("Scale %d%% -> %dx%d", p, tw, th);
    return 1;
}

__attribute__((visibility("default")))
int HEXED_ResetScale()
{
    return HEXED_SetScale(100);
}

// Legacy aliases (older Lua / chat commands)
__attribute__((visibility("default")))
int HEXED_Apply(int width, int height) { return HEXED_SetSize(width, height); }

__attribute__((visibility("default")))
int HEXED_GetCurrentWidth()  { return HEXED_GetCurrentW(); }

__attribute__((visibility("default")))
int HEXED_GetCurrentHeight() { return HEXED_GetCurrentH(); }

__attribute__((visibility("default")))
int HEXED_GetOriginalWidth()  { return HEXED_GetNativeW(); }

__attribute__((visibility("default")))
int HEXED_GetOriginalHeight() { return HEXED_GetNativeH(); }

__attribute__((visibility("default")))
int HEXED_IsApplied() { return HEXED_GetOverride(); }

__attribute__((visibility("default")))
int HEXED_SaveSettings(int w, int h)
{
    if (!IsSane(w, h)) return 0;
    g_windowOverride = true;
    g_scaleOverride  = false;
    g_activeW = w;
    g_activeH = h;
    SaveConfig();
    return 1;
}

__attribute__((visibility("default")))
int HEXED_LoadSettings(int* outW, int* outH)
{
    if (!outW || !outH) return 0;
    if (g_windowOverride && IsSane(g_activeW, g_activeH)) {
        *outW = g_activeW;
        *outH = g_activeH;
        return 1;
    }
    return 0;
}

} // extern "C"

// ---------- mod entry ----------

ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    logger->Info("HEXED Resolution 0.3.0 loading...");

    pGTASA = aml->GetLib("libGTASA.so");
    if (!pGTASA) {
        logger->Error("libGTASA.so not found");
        return;
    }

    g_RsGlobal     = (RsGlobalType*)aml->GetSym(pGTASA, "RsGlobal");
    g_renderWidth  = (int32_t*)aml->GetSym(pGTASA, "renderWidth");
    g_renderHeight = (int32_t*)aml->GetSym(pGTASA, "renderHeight");
    g_aspectRatio  = (float*)aml->GetSym(pGTASA, "_ZN5CDraw15ms_fAspectRatioE");

    OS_ScreenSetResolution = (OS_ScreenSetResolution_t)aml->GetSym(pGTASA, "_Z22OS_ScreenSetResolutionjj");
    OS_ScreenGetWidth      = (OS_ScreenGetWidth_t)aml->GetSym(pGTASA, "_Z17OS_ScreenGetWidthv");
    OS_ScreenGetHeight     = (OS_ScreenGetHeight_t)aml->GetSym(pGTASA, "_Z18OS_ScreenGetHeightv");
    CalculateAspectRatio   = (CalculateAspectRatio_t)aml->GetSym(pGTASA, "_ZN5CDraw20CalculateAspectRatioEv");

    logger->Info("RsGlobal=%p renderW=%p renderH=%p aspect=%p",
                 (void*)g_RsGlobal, (void*)g_renderWidth, (void*)g_renderHeight, (void*)g_aspectRatio);
    logger->Info("SetRes=%p GetW=%p GetH=%p CalcAR=%p",
                 (void*)OS_ScreenSetResolution, (void*)OS_ScreenGetWidth,
                 (void*)OS_ScreenGetHeight, (void*)CalculateAspectRatio);

    if (!OS_ScreenSetResolution)
        logger->Error("OS_ScreenSetResolution NOT FOUND");

    // May not be ready yet (game still booting); Lua will poll HEXED_IsReady
    TryBecomeReady();
    logger->Info("Load finished. ready=%d native=%dx%d", g_ready ? 1 : 0, g_nativeW, g_nativeH);
}

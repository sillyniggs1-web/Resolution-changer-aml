/*
 * HEXED Resolution — native AML plugin entry point.
 *
 * Target: AndroidModLoader (AML) 1.4.x mods directory loading.
 * Conventions follow the official AML documentation and the vendored
 * aml-psdk / mod headers (see LICENSES.md for upstream notices).
 *
 * Safety architecture (per project requirements):
 *  - Compatibility audit runs BEFORE any game-specific address is used.
 *  - Every PSDK event hook in this file is gated behind COMPAT_OK; when the
 *    audit fails the plugin loads in diagnostic-only mode with zero hooks
 *    and zero game-memory writes.
 *  - No Android system display settings are touched (no wm/settings/Shizuku;
 *    the plugin does not even link against the frameworks that would allow
 *    it beyond the standard EGL/GLES queries it uses on its own process).
 */
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <aml-psdk/game_sa/Events.h>
#include <aml-psdk/game_sa/engine/Font.h>

#include <cstdio>
#include <cstring>

#include "config.h"
#include "hexed_interface.h"
#include "logging.h"
#include "lua_bridge.h"
#include "render_backend.h"
#include "resolution_api.h"

#define HEXED_MOD_GUID    net.hexed.resolution
#define HEXED_MOD_NAME    HEXED Resolution
#define HEXED_MOD_VERSION 1.0.0
#define HEXED_MOD_AUTHOR  HEXED

MYMODCFGNAME(HEXED_MOD_GUID, HEXED_MOD_NAME, HEXED_MOD_VERSION, HEXED_MOD_AUTHOR, HexedResolution)

#if !defined(IAML_VER) || IAML_VER < 01040000
    #error "You need to update your MOD folder (AML mod headers) to 1.4.0+!"
#endif

namespace
{
    bool g_initialized = false;

    /* Cached one-line status for the HUD overlay (refreshed periodically
     * from the drawHudEvent listener; EGL/GL probes only run on that path). */
    char g_hudLine[160] = "HEXED Resolution";
    int  g_hudFrame = 0;

    void RefreshHudLine()
    {
        hxres::RenderBackend& b = hxres::RenderBackend::Get();
        if(b.Compat() != hxres::COMPAT_OK)
        {
            snprintf(g_hudLine, sizeof(g_hudLine), "HEXED: unsupported build (diagnostic only)");
            return;
        }
        hxres::RenderProbe p;
        b.Probe(p);
        snprintf(g_hudLine, sizeof(g_hudLine), "HEXED %s | res %dx%d%s",
                 hxres::ResolutionAPI::Get().Enabled() ? "on" : "off",
                 p.rsValid ? p.rsWidth : 0, p.rsValid ? p.rsHeight : 0,
                 b.HasApplied() ? " [applied]" : "");
    }

    void DrawHudStatus()
    {
        /* Colors: HEXED dark/blue/white identity. */
        CRGBA shadow(0, 0, 0, 200);
        CRGBA white(255, 255, 255, 230);
        CFont::SetScale(0.8f);
        CFont::SetWrapx(100000.0f);
        CFont::SetJustify(0);
        CFont::SetEdge(1);
        CFont::SetFontStyle(FO_FONT_STYLE_STANDARD);
        CFont::SetOrientation(ALIGN_LEFT);
        CFont::SetProportional(1);
        CFont::SetDropColor(shadow);
        CFont::SetColor(white);
        CFont::PrintString(20.0f, 20.0f, g_hudLine);
        CFont::RenderFontBuffer();
    }

    /* ---- IHexedResolution001 implementation (mod-to-mod API) ---- */

    int Iface_Probe(int* rsW, int* rsH, int* eglW, int* eglH, int* glW, int* glH)
    {
        hxres::RenderProbe p;
        hxres::RenderBackend::Get().Probe(p);
        if(rsW)  *rsW  = p.rsValid ? p.rsWidth : -1;
        if(rsH)  *rsH  = p.rsValid ? p.rsHeight : -1;
        if(eglW) *eglW = p.eglValid ? p.eglWidth : -1;
        if(eglH) *eglH = p.eglValid ? p.eglHeight : -1;
        if(glW)  *glW  = p.glValid ? p.glViewport[2] : -1;
        if(glH)  *glH  = p.glValid ? p.glViewport[3] : -1;
        return p.rsValid ? 1 : 0;
    }

    int Iface_Apply(int w, int h)
    {
        hxres::RequestResult r = hxres::ResolutionAPI::Get().Apply(w, h, hxres::PRESET_CUSTOM);
        return (int)r.code;
    }

    int Iface_Reset()
    {
        hxres::RequestResult r = hxres::ResolutionAPI::Get().Reset();
        return (int)r.code;
    }

    int Iface_Enable(int enabled)
    {
        hxres::RequestResult r = hxres::ResolutionAPI::Get().Enable(enabled != 0);
        return (int)r.code;
    }

    void Iface_StatusLine(char* out, int outLen)
    {
        if(!out || outLen <= 0) return;
        hxres::ResolutionAPI::Get().BuildStatusLine(out, outLen);
    }

    IHexedResolution001 g_Interface =
    {
        HEXED_INTERFACE_VERSION,
        Iface_Probe,
        Iface_Apply,
        Iface_Reset,
        Iface_Enable,
        Iface_StatusLine,
    };
}

/* ============================ AML lifecycle ============================ */

ON_MOD_PRELOAD()
{
    if(g_initialized) return;
    logger->SetTag("HEXED-Resolution");
    hxlog::Init(aml ? aml->GetAndroidDataPath() : NULL, false);
    hxlog::I("HEXED Resolution %s (AML interface ver 0x%08X) preload",
             modinfo->VersionString(), (unsigned)IAML_VER);
}

ON_MOD_LOAD()
{
    if(g_initialized)
    {
        hxlog::W("OnModLoad called twice; ignoring");
        return;
    }
    if(!aml)
    {
        logger->Error("AML interface unavailable; HEXED Resolution cannot start");
        return;
    }

    /* ---- Identity / environment report (all read-only) ---- */
    hxlog::I("game pkg: %s (real: %s) | app version: %s",
             aml->GetCurrentGame(), aml->GetRealCurrentGame(),
             aml->GetAppVersionName() ? aml->GetAppVersionName() : "n/a");
    int dispW = 0, dispH = 0;
    aml->GetDisplaySize(&dispW, &dispH);
    hxlog::I("device display: %dx%d | android api %d", dispW, dispH, aml->GetAndroidVersion());
#ifdef AML32
    hxlog::I("plugin ABI: armeabi-v7a");
#else
    hxlog::I("plugin ABI: arm64-v8a");
#endif

    /* ---- Configuration (AML Config -> HexedResolution.ini) ---- */
    hxres::HexedConfig conf;
    hxres::LoadConfig(conf);
    hxlog::I("config dir: %s (file: HexedResolution.ini)", aml->GetConfigPath());
    hxlog::I("config: enabled=%d allowNativeApply=%d preset=%s restoreAtStartup=%d watchdog=%d",
             (int)conf.enabled, (int)conf.allowNativeApply, hxres::PresetName(conf.preset),
             (int)conf.restoreAtStartup, (int)conf.watchdog);

    hxlog::SetVerbose(conf.verboseLogging);

    /* ---- Compatibility audit (read-only) ---- */
    hxres::RenderBackend::Get().InitCompat(
        aml->GetLib("libGTASA.so"), aml->GetLibLength("libGTASA.so"),
        conf.useCustomProfile, conf.customRsGlobalPtrOffset32, conf.customRsGlobalPtrOffset64);

    hxres::ResolutionAPI::Get().Init(conf.enabled, conf.restoreAtStartup,
                                     conf.watchdog, conf.allowNativeApply);

    /* ---- Event wiring: ONLY on a verified-compatible build. On any other
     *       build the plugin stays diagnostic-only (no hooks, no writes). ---- */
    if(hxres::RenderBackend::Get().Compat() == hxres::COMPAT_OK)
    {
        /* Safe lifecycle points, resolved by symbol (runtime-verified): */
        Events::initRwEvent.before += []()
        {
            hxres::ResolutionAPI::Get().OnInitRenderWareBefore();
        };
        Events::initRwEvent.after += []()
        {
            hxres::ResolutionAPI::Get().OnInitRenderWareAfter();
        };
        Events::frameEndEvent.after += [](bool)
        {
            hxres::ResolutionAPI::Get().FrameTick();
        };
        /* drawHudEvent is a PLT-pinned event from the same verified PSDK
         * profile; gated behind the compat audit above. */
        Events::drawHudEvent += []()
        {
            hxres::HexedConfig c;
            hxres::LoadConfig(c);          /* cheap: AML fast getters */
            if(!c.hudStatus) return;
            if((g_hudFrame++ % 60) == 0) RefreshHudLine();
            DrawHudStatus();
        };
        hxlog::I("events: render lifecycle + HUD hooks installed");
    }
    else
    {
        hxlog::W("events: NOT installed — diagnostic-only mode");
    }

    /* ---- Lua command-file bridge ---- */
    if(!hxbridge::Start(aml->GetAndroidDataPath()))
    {
        hxlog::E("bridge failed to start; Lua menu will not be reachable");
    }

    /* ---- Mod-to-mod interface ---- */
    RegisterInterface(HEXED_INTERFACE_NAME, &g_Interface);

    g_initialized = true;
    hxlog::I("HEXED Resolution loaded. Bridge cmd: %s", hxbridge::CmdPath());
}

ON_MOD_UNLOAD()
{
    if(!g_initialized) return;
    hxbridge::Stop();
    hxres::ResolutionAPI::Get().Shutdown(true /* tryRestore */);
    hxlog::Shutdown();
    g_initialized = false;
    logger->Info("HEXED Resolution unloaded");
}

ON_GAME_CRASH()
{
    /* Best-effort forensic note; not guaranteed to run. */
    hxlog::E("game crash: lib=%s sig=%d code=%d libaddr=" PTRFMT,
             library ? library : "?", sig, code, libaddr);
}

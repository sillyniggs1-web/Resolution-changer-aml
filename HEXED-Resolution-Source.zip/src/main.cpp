/*
 * HEXED Resolution v1.0.0 - AML plugin for GTA SA Android
 * Target: SA-MP Nezuko v1.0.3 (TESTING) - armeabi-v7a
 *
 * HOW IT WORKS (verified against libGTASA.so of the 1.0.3 APK)
 * ------------------------------------------------------------
 * Idle() calls  emu_SetAltRenderTarget(w, h)  every frame. The game renders the
 * whole scene into that off-screen target and emu_FlushAltRenderTarget() later
 * stretches it to the real screen. This is the engine's own "resolution scale".
 * emu_glViewport() maps screen coordinates to the target with
 *     x * renderWidth / OS_ScreenGetWidth()
 * so HUD, menus and touch (which all use the real screen size / RsGlobal)
 * keep working untouched.
 *
 * We hook emu_SetAltRenderTarget and replace (w, h) with the size the user
 * picked. We never write RsGlobal / renderWidth / renderHeight / windowSize:
 *   - renderWidth/Height are only a copy of the last SetAltRenderTarget size
 *     (writing them can make the engine skip creating the target),
 *   - windowSize is the real surface size used by touch and the HUD.
 */

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 1.0.0, HEXED)

enum Mode { MODE_OFF = 0, MODE_SCALE = 1, MODE_SIZE = 2 };

typedef int (*GetScreenFn)();

static uintptr_t   pGTASA      = 0;
static GetScreenFn OS_Width    = nullptr;
static GetScreenFn OS_Height   = nullptr;
static int32_t*    g_renderW   = nullptr;   // read only (diagnostics)
static int32_t*    g_renderH   = nullptr;
static bool        g_hooked    = false;

static volatile int g_mode  = MODE_OFF;
static volatile int g_scale = 100;     // percent of real screen width
static volatile int g_sizeW = 1280;
static volatile int g_sizeH = 720;
static volatile int g_lastW = 0;       // last size we passed to the engine
static volatile int g_lastH = 0;


static inline int Round4Up(int v) { return (v + 3) & ~3; }

static int ClampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static bool ComputeTarget(int* ow, int* oh)
{
    int sw = OS_Width  ? OS_Width()  : 0;
    int sh = OS_Height ? OS_Height() : 0;
    if (g_mode == MODE_SCALE) {
        if (sw <= 0 || sh <= 0) return false;
        int pct = ClampInt(g_scale, 25, 200);
        int w = Round4Up(sw * pct / 100);
        int h = Round4Up((int)((long long)sh * w / sw));
        *ow = ClampInt(w, 320, 4096);
        *oh = ClampInt(h, 180, 4096);
        return true;
    }
    if (g_mode == MODE_SIZE) {
        *ow = ClampInt(Round4Up(g_sizeW), 320, 4096);
        *oh = ClampInt(Round4Up(g_sizeH), 180, 4096);
        return true;
    }
    return false;
}

DECL_HOOKv(SetAltRenderTarget, int w, int h)
{
    // (0,0) means "no alt target" (menus, fades): always pass through.
    if (g_mode != MODE_OFF && w > 0 && h > 0) {
        int nw, nh;
        if (ComputeTarget(&nw, &nh)) { w = nw; h = nh; }
    }
    g_lastW = w; g_lastH = h;
    SetAltRenderTarget(w, h);
}

/* ---------------- config file ---------------- */

static std::string CfgPath()
{
    std::string base = aml->GetAndroidDataPath();
    return base + "/HEXED/hexed_resolution.cfg";
}

static void SaveCfg()
{
    std::string p = CfgPath();
    aml->CreateDirRecursive((std::string(aml->GetAndroidDataPath()) + "/HEXED").c_str());
    FILE* f = fopen(p.c_str(), "w");
    if (!f) { logger->Error("Cannot write %s", p.c_str()); return; }
    fprintf(f, "%d %d %d %d\n", (int)g_mode, (int)g_scale, (int)g_sizeW, (int)g_sizeH);
    fclose(f);
}

static void LoadCfg()
{
    FILE* f = fopen(CfgPath().c_str(), "r");
    if (!f) return;
    int m, s, w, h;
    if (fscanf(f, "%d %d %d %d", &m, &s, &w, &h) == 4 && m >= 0 && m <= 2) {
        g_mode = m; g_scale = ClampInt(s, 25, 200);
        g_sizeW = ClampInt(w, 320, 4096); g_sizeH = ClampInt(h, 180, 4096);
        logger->Info("Loaded cfg mode=%d scale=%d size=%dx%d", m, s, w, h);
    }
    fclose(f);
}

/* ---------------- C API for the Lua script ---------------- */

#define HX_EXPORT extern "C" __attribute__((visibility("default")))

HX_EXPORT int  HEXED_IsReady()        { return g_hooked ? 1 : 0; }
HX_EXPORT int  HEXED_GetMode()        { return g_mode; }
HX_EXPORT int  HEXED_GetScale()       { return g_scale; }
HX_EXPORT int  HEXED_GetSizeW()       { return g_sizeW; }
HX_EXPORT int  HEXED_GetSizeH()       { return g_sizeH; }
HX_EXPORT int  HEXED_GetScreenW()     { return OS_Width  ? OS_Width()  : 0; }
HX_EXPORT int  HEXED_GetScreenH()     { return OS_Height ? OS_Height() : 0; }
HX_EXPORT int  HEXED_GetActiveW()     { return g_renderW ? *g_renderW : 0; } // 0 = drawing straight to screen
HX_EXPORT int  HEXED_GetActiveH()     { return g_renderH ? *g_renderH : 0; }
HX_EXPORT int  HEXED_GetLastW()       { return g_lastW; }
HX_EXPORT int  HEXED_GetLastH()       { return g_lastH; }

HX_EXPORT int HEXED_SetScale(int percent)
{
    if (!g_hooked || percent < 25 || percent > 200) return 0;
    g_scale = percent; g_mode = MODE_SCALE; SaveCfg();
    logger->Info("Scale %d%%", percent);
    return 1;
}

HX_EXPORT int HEXED_SetSize(int w, int h)
{
    if (!g_hooked || w < 320 || h < 180 || w > 4096 || h > 4096) return 0;
    g_sizeW = w; g_sizeH = h; g_mode = MODE_SIZE; SaveCfg();
    logger->Info("Size %dx%d", w, h);
    return 1;
}

HX_EXPORT int HEXED_Reset()
{
    g_mode = MODE_OFF; SaveCfg();
    logger->Info("Reset (engine default)");
    return 1;
}

/* ---------------- load ---------------- */

static bool SignatureOK(uintptr_t fn)
{
    // push {r4-r7,lr}; add r7,sp,#12; str fp,[sp,#-4]!; sub sp,#16  (1.0.3 build)
    static const uint8_t sig[] = { 0xf0,0xb5, 0x03,0xaf, 0x4d,0xf8,0x04,0xbd, 0x84,0xb0 };
    return memcmp((const void*)(fn & ~1u), sig, sizeof(sig)) == 0;
}

ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    logger->Info("HEXED Resolution 1.0.0 loading...");

    pGTASA = aml->GetLib("libGTASA.so");
    if (!pGTASA) { logger->Error("libGTASA.so not found"); return; }

    void* h = aml->GetLibHandle("libGTASA.so");
    uintptr_t fn = aml->GetSym(h, "_Z22emu_SetAltRenderTargetii");
    OS_Width  = (GetScreenFn)aml->GetSym(h, "_Z17OS_ScreenGetWidthv");
    OS_Height = (GetScreenFn)aml->GetSym(h, "_Z18OS_ScreenGetHeightv");
    g_renderW = (int32_t*)aml->GetSym(h, "renderWidth");
    g_renderH = (int32_t*)aml->GetSym(h, "renderHeight");

    if (!fn || !OS_Width || !OS_Height) { logger->Error("required symbols missing"); return; }
    if (!SignatureOK(fn)) {
        logger->Error("emu_SetAltRenderTarget bytes differ - unsupported libGTASA build, not hooking");
        return;
    }

    if (!aml->Hook((void*)fn, (void*)&HookOf_SetAltRenderTarget, (void**)&SetAltRenderTarget)) {
        logger->Error("Hook failed");
        return;
    }
    g_hooked = true;
    LoadCfg();
    logger->Info("Hooked. screen %dx%d mode=%d", OS_Width(), OS_Height(), (int)g_mode);
}

/*
 * HEXED Resolution v2.0.0 - AML plugin for GTA SA Android
 * Target: SA-MP Nezuko v1.0.3 (TESTING) - armeabi-v7a
 *
 * ENGINE-NATIVE METHOD - NO CODE HOOKS, NO CODE PATCHES
 * -----------------------------------------------------
 * Verified in libGTASA.so (1.0.3):
 *   Idle() reads  MobileSettings::settings + 0x28  (int, 0..100) every frame and builds
 *     w = 640 + (OS_ScreenGetWidth() - 640) * pct / 100       (GetMaxResWidth == OS_ScreenGetWidth)
 *     h = OS_ScreenGetHeight() * w / OS_ScreenGetWidth()
 *     both rounded up to a multiple of 4, then calls emu_SetAltRenderTarget(w, h).
 * We only change that one int. The engine does the rest (aspect, alignment, fades, menus),
 * so there is nothing to conflict with other mods. 100 = native screen size, the engine's maximum.
 *
 * The value is (re)applied after MobileSettings has loaded (byte MobileSettings::loaded) and is
 * re-asserted while an override is active, because Menu_LoadSettings can overwrite it.
 */

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <pthread.h>
#include <unistd.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 2.0.0, HEXED)

typedef int (*GetScreenFn)();

static GetScreenFn OS_Width  = nullptr;
static GetScreenFn OS_Height = nullptr;
static volatile int*     g_pct    = nullptr;   // MobileSettings::settings + 0x28
static volatile uint8_t* g_loaded = nullptr;   // MobileSettings::loaded
static volatile int32_t* g_renderW = nullptr;  // read only, diagnostics
static volatile int32_t* g_renderH = nullptr;

static volatile int g_ready    = 0;   // sanity checked, original captured
static volatile int g_override = 0;   // 1 = we enforce g_want
static volatile int g_want     = 100;
static volatile int g_orig     = 100;
static volatile int g_wantSaved = 0;  // cfg had an override waiting for settings to load

static inline int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int Round4Up(int v) { return (v + 3) & ~3; }

/* Exactly what Idle() computes */
static void EngineSize(int pct, int* ow, int* oh)
{
    int sw = OS_Width ? OS_Width() : 0, sh = OS_Height ? OS_Height() : 0;
    if (sw <= 0 || sh <= 0) { *ow = *oh = 0; return; }
    int w = (sw > 640) ? 640 + ((sw - 640) * pct) / 100 : sw;
    int h = (int)((long long)sh * w / sw);
    *ow = Round4Up(w); *oh = Round4Up(h);
}

/* ---------------- config ---------------- */
static std::string CfgDir()  { return std::string(aml->GetAndroidDataPath()) + "/HEXED"; }
static std::string CfgPath() { return CfgDir() + "/hexed_resolution.cfg"; }

static void SaveCfg()
{
    aml->CreateDirRecursive(CfgDir().c_str());
    FILE* f = fopen(CfgPath().c_str(), "w");
    if (!f) { logger->Error("Cannot write %s", CfgPath().c_str()); return; }
    fprintf(f, "%d %d\n", (int)g_override, (int)g_want);
    fclose(f);
}

static void LoadCfg()
{
    FILE* f = fopen(CfgPath().c_str(), "r");
    if (!f) return;
    int o, p;
    if (fscanf(f, "%d %d", &o, &p) == 2 && (o == 0 || o == 1) && p >= 0 && p <= 100) {
        g_want = p; g_override = o; g_wantSaved = o;
        logger->Info("Loaded cfg override=%d pct=%d", o, p);
    }
    fclose(f);
}

/* ---------------- watcher thread ---------------- */
static void* Watcher(void*)
{
    for (;;) {
        usleep(250 * 1000);
        if (!g_pct || !g_loaded || !*g_loaded) continue;   // settings not loaded yet
        if (!g_ready) {
            int cur = *g_pct;
            if (cur < 0 || cur > 100) { logger->Error("settings+0x28 = %d out of range, not touching it", cur); return nullptr; }
            g_orig = cur; g_ready = 1;
            int w, h; EngineSize(cur, &w, &h);
            logger->Info("Ready. engine pct=%d (%dx%d) screen %dx%d", cur, w, h, OS_Width(), OS_Height());
        }
        if (g_override && *g_pct != g_want) *g_pct = g_want;
    }
    return nullptr;
}

/* ---------------- C API for Lua ---------------- */
#define HX_EXPORT extern "C" __attribute__((visibility("default")))

HX_EXPORT int HEXED_IsReady()      { return g_ready; }
HX_EXPORT int HEXED_GetOverride()  { return g_override; }
HX_EXPORT int HEXED_GetPercent()   { return g_pct ? *g_pct : -1; }   // what the engine uses right now
HX_EXPORT int HEXED_GetOriginal()  { return g_orig; }
HX_EXPORT int HEXED_GetScreenW()   { return OS_Width  ? OS_Width()  : 0; }
HX_EXPORT int HEXED_GetScreenH()   { return OS_Height ? OS_Height() : 0; }
HX_EXPORT int HEXED_GetActiveW()   { return g_renderW ? *g_renderW : 0; }   // 0 = no alt target
HX_EXPORT int HEXED_GetActiveH()   { return g_renderH ? *g_renderH : 0; }
HX_EXPORT int HEXED_PercentToWidth(int p)  { int w, h; EngineSize(Clamp(p, 0, 100), &w, &h); return w; }
HX_EXPORT int HEXED_PercentToHeight(int p) { int w, h; EngineSize(Clamp(p, 0, 100), &w, &h); return h; }

HX_EXPORT int HEXED_SetPercent(int p)
{
    if (!g_ready || p < 0 || p > 100) return 0;
    g_want = p; g_override = 1; *g_pct = p; SaveCfg();
    logger->Info("Set %d%%", p);
    return 1;
}

/* Pick the percentage whose engine width is closest to w. Returns pct (0..100) or -1. */
HX_EXPORT int HEXED_SetWidth(int w)
{
    int sw = OS_Width ? OS_Width() : 0;
    if (!g_ready || sw <= 640) return -1;
    int p = Clamp(((w - 640) * 100 + (sw - 640) / 2) / (sw - 640), 0, 100);
    return HEXED_SetPercent(p) ? p : -1;
}

HX_EXPORT int HEXED_Reset()
{
    if (!g_ready) return 0;
    g_override = 0; *g_pct = g_orig; SaveCfg();
    logger->Info("Reset to %d%%", (int)g_orig);
    return 1;
}

/* ---------------- load ---------------- */
ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    logger->Info("HEXED Resolution 2.0.0 loading...");

    uintptr_t lib = aml->GetLib("libGTASA.so");
    if (!lib) { logger->Error("libGTASA.so not found"); return; }

    uintptr_t settings = aml->GetSym(lib, "_ZN14MobileSettings8settingsE");
    uintptr_t loaded   = aml->GetSym(lib, "_ZN14MobileSettings6loadedE");
    OS_Width  = (GetScreenFn)aml->GetSym(lib, "_Z17OS_ScreenGetWidthv");
    OS_Height = (GetScreenFn)aml->GetSym(lib, "_Z18OS_ScreenGetHeightv");
    g_renderW = (volatile int32_t*)aml->GetSym(lib, "renderWidth");
    g_renderH = (volatile int32_t*)aml->GetSym(lib, "renderHeight");

    if (!settings || !loaded || !OS_Width || !OS_Height) { logger->Error("required symbols missing"); return; }

    g_pct    = (volatile int*)(settings + 0x28);
    g_loaded = (volatile uint8_t*)loaded;

    LoadCfg();

    pthread_t t;
    if (pthread_create(&t, nullptr, Watcher, nullptr) == 0) pthread_detach(t);
    else logger->Error("watcher thread failed");

    logger->Info("Waiting for MobileSettings to load (no hooks installed)");
}

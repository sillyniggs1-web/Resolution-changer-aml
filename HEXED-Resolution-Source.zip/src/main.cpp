/*
 * HEXED Resolution 1.0.8 - "fixed surface" edition
 * Target: SA-MP Nezuko (TESTING build, see docs/NOTES.md) - armeabi-v7a
 *
 * How it works (see docs/NOTES.md for the evidence):
 *   Everything goes through Android's own resize so the game, EGL, Java overlays and all mods see ONE size:
 *   1. padding on android.R.id.content shrinks the SurfaceView and every overlay together (black bars around)
 *   2. SurfaceHolder.setFixedSize sets a lower/higher render resolution; surfaceChanged -> setWindowSize tells the game
 *   3. touches are mapped into the picture at the Window.Callback (where the Activity receives them); the native hooks are a fallback
 *
 * Replaced from 0.5.x: OS_ScreenSetResolution (an empty stub in this build), direct RsGlobal/renderWidth
 * writes, the OS_ScreenGet* hooks and the GL "present pass" (center.cpp).
 */
#include <mod/amlmod.h>
#include <mod/logger.h>
#include "hlog.h"
#include <mod/config.h>

#include "state.h"
#include "calc.h"

#include <atomic>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 1.0.8, HEXED)

namespace hexed { Shared g; }
using namespace hexed;

// ---------- state (guarded by g_mu; hooks only read the atomics in hexed::g) ----------
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
struct Lock { pthread_mutex_t* m; explicit Lock(pthread_mutex_t* x) : m(x) { pthread_mutex_lock(m); } ~Lock() { pthread_mutex_unlock(m); } };

static int    g_mode = calc::MODE_NONE;
static int    g_pct = 100, g_reqW = 0, g_reqH = 0;
static bool   g_ready = false, g_cfgLoaded = false, g_safeMode = false;
static time_t g_loadTime = 0, g_lastFallback = 0;
static int    g_fallbackTries = 0;
static char   g_err[200] = "";
static int    g_stage = 3;
static bool   g_bars = true;     // letter/pillar-box a request whose shape differs from the screen (else stretch to fill)

static void SetErr(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    hexed::HLog("%s", g_err);
}

// ---------- files: config + "pending" marker (safe mode) ----------
static bool PathOf(char* out, size_t n, const char* file)
{
    const char* d = hexed::DataDir();
    if (!d) return false;
    snprintf(out, n, "%s/%s", d, file);
    return true;
}

static void WriteMarker() { char p[300]; if (PathOf(p, sizeof(p), "hexed_resolution.pending")) if (FILE* f = fopen(p, "w")) { fputs("1\n", f); fclose(f); } }
static void ClearMarker() { char p[300]; if (PathOf(p, sizeof(p), "hexed_resolution.pending")) unlink(p); }
static bool MarkerExists(){ char p[300]; return PathOf(p, sizeof(p), "hexed_resolution.pending") && access(p, F_OK) == 0; }

// sleep() returns early when a signal arrives (the AML crash handler signals every thread while it dumps),
// which made the crash guard think a crashing start had survived. Wait on the monotonic clock instead.
static void SleepSeconds(int sec)
{
    struct timespec t0; clock_gettime(CLOCK_MONOTONIC, &t0);
    for (;;) {
        struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
        if (t.tv_sec - t0.tv_sec >= sec) return;
        usleep(200 * 1000);
    }
}

// The marker stays for 10 s after a setting is applied. If the game is closed within that time
// (setting unusable / crash) the next launch starts in safe mode with the setting cleared.
static std::atomic<unsigned> g_markerGen{0};
static void* MarkerThread(void* arg)
{
    unsigned gen = (unsigned)(uintptr_t)arg;
    SleepSeconds(10);
    if (gen == g_markerGen.load()) ClearMarker();
    return nullptr;
}
static void ArmMarker()
{
    WriteMarker();
    unsigned gen = ++g_markerGen;
    pthread_t t; pthread_attr_t a; pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    if (pthread_create(&t, &a, MarkerThread, (void*)(uintptr_t)gen) != 0) ClearMarker();
    pthread_attr_destroy(&a);
}

static void SaveConfig()
{
    char p[300]; if (!PathOf(p, sizeof(p), "hexed_resolution.cfg")) return;
    if (FILE* f = fopen(p, "w")) {
        fprintf(f, "HXDRES2 %d %d %d %d %d %d\n", g_mode, g_pct, g_reqW, g_reqH, g.touchRemap.load(), g_bars ? 1 : 0);
        fclose(f);
    }
}

static void LoadConfig()
{
    char p[300]; if (!PathOf(p, sizeof(p), "hexed_resolution.cfg")) return;
    FILE* f = fopen(p, "r"); if (!f) return;
    char tag[16] = {0}; int mode = 0, pct = 100, rw = 0, rh = 0, touch = 1, bars = 1;
    int n = fscanf(f, "%15s %d %d %d %d %d %d", tag, &mode, &pct, &rw, &rh, &touch, &bars);
    if (n >= 6 && (!strcmp(tag, "HXDRES1") || !strcmp(tag, "HXDRES2"))) {
        if (mode >= calc::MODE_NONE && mode <= calc::MODE_SIZE) {
            g_mode = mode; g_pct = pct; g_reqW = rw; g_reqH = rh;
            g.touchRemap = touch ? 1 : 0;
            g_bars = (n >= 7) ? (bars != 0) : true;
        }
    }
    fclose(f);
}

static void StartupLoad()      // caller holds g_mu; runs once, on the first sign of the game window
{
    if (MarkerExists()) {
        g_safeMode = true;
        ClearMarker();
        g_mode = calc::MODE_NONE;
        SaveConfig();
        hexed::HLog("Safe mode: last session ended right after a resolution change - setting cleared");
        return;
    }
    LoadConfig();
    if (g_mode != calc::MODE_NONE) { ArmMarker(); hexed::HLog("Saved setting loaded (mode %d)", g_mode); }
}

// ---------- core ----------
// Terms: SCREEN = area the game may use (parent of the SurfaceView). VIEW = current SurfaceView size (= touch space).
//        ACTIVE = size the game renders at (buffer). BOX = wanted view size on screen (0 = fill the screen).

// Render size + on-screen box for a request.
//   SCALE / HEIGHT      : render lower than the screen, picture fills the screen (no bars)
//   SIZE, bars ON       : a real window of that size (scaled down only if bigger than the screen), render = window, bars around
//   SIZE, bars OFF      : render at that size, stretched to fill the screen
static bool ComputeAll(int mode, int pct, int rw, int rh, bool bars, int* aw, int* ah, int* bw, int* bh)
{
    int sw = g.screenW.load(), sh = g.screenH.load();
    if (!calc::Compute(mode, pct, rw, rh, sw, sh, aw, ah)) return false;
    *bw = 0; *bh = 0;
    if (mode == calc::MODE_SIZE && bars) {
        int fw = 0, fh = 0;
        calc::FitDown(*aw, *ah, sw, sh, &fw, &fh);
        if (fw != sw || fh != sh) { *bw = fw; *bh = fh; *aw = fw; *ah = fh; }
        else { *aw = sw; *ah = sh; }                                  // screen-shaped and screen-sized: nothing to do
    }
    return true;
}

static int  g_appliedSig = 0;
static time_t g_lastApply = 0;

static bool ViewMatchesBox()
{
    int vw = 0, vh = 0;
    if (!surface::ViewSize(&vw, &vh)) return false;
    int tw = g.boxW.load() > 0 ? g.boxW.load() : g.screenW.load();
    int th = g.boxH.load() > 0 ? g.boxH.load() : g.screenH.load();
    return abs(vw - tw) <= 2 && abs(vh - th) <= 2;
}

// caller holds g_mu. uiEnv != null: we are on the UI thread (inside a hook) and may change the layout directly.
// Nothing here talks to the game: the layout change makes Android call surfaceChanged and the game follows by itself.
static bool SyncToJava(JNIEnv* uiEnv)
{
    int sig = 0, aw = 0, ah = 0, bw = 0, bh = 0;
    if (g_mode == calc::MODE_NONE) {
        g.overrideOn = 0; g.boxW = 0; g.boxH = 0;
        g.activeW = g.screenW.load(); g.activeH = g.screenH.load();
        g.nativeW = g.screenW.load(); g.nativeH = g.screenH.load();
    } else {
        if (!ComputeAll(g_mode, g_pct, g_reqW, g_reqH, g_bars, &aw, &ah, &bw, &bh)) {
            SetErr("saved setting does not fit this screen (%dx%d) - reset", g.screenW.load(), g.screenH.load());
            g_mode = calc::MODE_NONE; g.overrideOn = 0; g.boxW = 0; g.boxH = 0;
            return false;
        }
        g.activeW = aw; g.activeH = ah; g.boxW = bw; g.boxH = bh; g.overrideOn = 1;
        g.nativeW = bw > 0 ? bw : g.screenW.load();                    // touch space once the layout has settled
        g.nativeH = bh > 0 ? bh : g.screenH.load();
        // The screen area is part of the signature: the same box on a different screen (rotation, split screen, insets) must be re-centered.
        sig = aw * 31 + ah * 17 + bw * 7 + bh * 3 + g.screenW.load() * 13 + g.screenH.load() * 5 + 1;
    }
    if (uiEnv) {
        bool changed = sig != g_appliedSig;
        if (!changed && !ViewMatchesBox() && time(nullptr) - g_lastApply >= 2) changed = true;   // e.g. the system reset the layout
        if (changed) { surface::ApplyLayout(uiEnv); g_appliedSig = sig; g_lastApply = time(nullptr); }
    } else {
        g_appliedSig = sig; g_lastApply = time(nullptr);
        ui::Post();
    }
    return true;
}

void hexed::OnJavaWindowSize(JNIEnv* env, jobject thiz, int w, int h)    // UI thread, from the setWindowSize hook
{
    surface::Attach(env, thiz);
    surface::RefreshGeometry(env);                                  // box position in window coordinates (touch mapping)
    int vw = 0, vh = 0, sw = 0, sh = 0;
    if (!surface::ViewSize(&vw, &vh)) { vw = w; vh = h; }
    bool haveScreen = surface::ParentSize(&sw, &sh);
    Lock l(&g_mu);
    if (vw > 0 && vh > 0) { g.nativeW = vw; g.nativeH = vh; }
    if (haveScreen) { g.screenW = sw; g.screenH = sh; }
    else if (g.boxW.load() == 0 && vw > 0) { g.screenW = vw; g.screenH = vh; }
    if (g.screenW.load() <= 0) return;
    if (!g_cfgLoaded) { g_cfgLoaded = true; StartupLoad(); }
    if (!g_ready) { g_ready = true; hexed::HLog("Ready. screen=%dx%d view=%dx%d java=%dx%d", g.screenW.load(), g.screenH.load(), vw, vh, w, h); }
    SyncToJava(env);
}

static int ResetLocked()
{
    g_mode = calc::MODE_NONE;
    SyncToJava(nullptr);                                           // clears override + box, posts a layout restore
    SaveConfig();
    ClearMarker();
    hexed::HLog("Reset to screen %dx%d", g.screenW.load(), g.screenH.load());
    return 1;
}

static int Apply(int mode, int pct, int rw, int rh)
{
    Lock l(&g_mu);
    if (!g_ready) { SetErr("game not ready yet"); return 0; }
    int sw = g.screenW.load(), sh = g.screenH.load(), aw = 0, ah = 0, bw = 0, bh = 0;
    if (!ComputeAll(mode, pct, rw, rh, g_bars, &aw, &ah, &bw, &bh)) {
        SetErr("rejected (min %dx%d, max side %d)", calc::MIN_W, calc::MIN_H, calc::MAX_SIDE);
        return 0;
    }
    if (aw == sw && ah == sh && bw == 0) return ResetLocked();

    g_mode = mode; g_pct = pct; g_reqW = rw; g_reqH = rh;
    ArmMarker();
    SyncToJava(nullptr);
    SaveConfig();
    hexed::HLog("Applied: game %dx%d, box %dx%d (0 = fill), screen %dx%d, mode %d, bars %d, ui=%d",
                aw, ah, bw, bh, sw, sh, mode, g_bars ? 1 : 0, ui::Ready() ? 1 : 0);
    return 1;
}

// ---------- exported C API (used by lua/hexed_resolution.lua through ffi) ----------
#define EXPORT_C extern "C" __attribute__((visibility("default")))

EXPORT_C int HEXED_Tick()
{
    Lock l(&g_mu);
    if (!g_ready && !surface::HaveActivity() && g_fallbackTries < 6 &&
        time(nullptr) - g_loadTime >= 3 && time(nullptr) != g_lastFallback) {
        g_lastFallback = time(nullptr);
        ++g_fallbackTries;
        if (surface::FindActivityFallback()) {
            int vw = 0, vh = 0, sw = 0, sh = 0;
            if (surface::ViewSize(&vw, &vh)) {
                g.nativeW = vw; g.nativeH = vh;
                if (surface::ParentSize(&sw, &sh)) { g.screenW = sw; g.screenH = sh; }
                else { g.screenW = vw; g.screenH = vh; }
                if (!g_cfgLoaded) { g_cfgLoaded = true; StartupLoad(); }
                g_ready = true;
                hexed::HLog("Ready (late attach). screen=%dx%d", g.screenW.load(), g.screenH.load());
                SyncToJava(nullptr);
            }
        }
    }
    return g_ready ? 1 : 0;
}

EXPORT_C int HEXED_IsReady()        { return g_ready ? 1 : 0; }
EXPORT_C int HEXED_GetMode()        { return g_mode; }
EXPORT_C int HEXED_GetOverride()    { return g.overrideOn.load(); }
EXPORT_C int HEXED_WasSafeMode()    { return g_safeMode ? 1 : 0; }
EXPORT_C int HEXED_GetNativeW()     { return g.screenW.load(); }      // the screen
EXPORT_C int HEXED_GetNativeH()     { return g.screenH.load(); }
EXPORT_C int HEXED_GetActiveW()     { return g.overrideOn.load() ? g.activeW.load() : g.screenW.load(); }   // game resolution
EXPORT_C int HEXED_GetActiveH()     { return g.overrideOn.load() ? g.activeH.load() : g.screenH.load(); }
EXPORT_C int HEXED_GetBoxW()        { return g.boxW.load() > 0 ? g.boxW.load() : g.screenW.load(); }        // picture on screen
EXPORT_C int HEXED_GetBoxH()        { return g.boxH.load() > 0 ? g.boxH.load() : g.screenH.load(); }
EXPORT_C int HEXED_GetScalePercent(){ return g_mode == calc::MODE_SCALE ? g_pct : 100; }
EXPORT_C int HEXED_GetMinW()        { return calc::MIN_W; }
EXPORT_C int HEXED_GetMinH()        { return calc::MIN_H; }
EXPORT_C int HEXED_GetMaxSide()     { return calc::MAX_SIDE; }
EXPORT_C const char* HEXED_GetError(){ return g_err; }

EXPORT_C int HEXED_PercentToWidth(int p)
{
    int w = 0, h = 0;
    return calc::Compute(calc::MODE_SCALE, p, 0, 0, g.screenW.load(), g.screenH.load(), &w, &h) ? w : 0;
}
EXPORT_C int HEXED_PercentToHeight(int p)
{
    int w = 0, h = 0;
    return calc::Compute(calc::MODE_SCALE, p, 0, 0, g.screenW.load(), g.screenH.load(), &w, &h) ? h : 0;
}
EXPORT_C int HEXED_HeightToWidth(int hh)
{
    int w = 0, h = 0;
    return calc::Compute(calc::MODE_HEIGHT, 0, 0, hh, g.screenW.load(), g.screenH.load(), &w, &h) ? w : 0;
}

EXPORT_C int HEXED_Reset()
{
    Lock l(&g_mu);
    if (!g_ready) { SetErr("game not ready yet"); return 0; }
    return ResetLocked();
}

EXPORT_C int HEXED_SetScale(int p)
{
    if (p >= 100) return HEXED_Reset();          // 100 % == native
    return Apply(calc::MODE_SCALE, p, 0, 0);
}
EXPORT_C int HEXED_SetHeight(int h) { return Apply(calc::MODE_HEIGHT, 0, 0, h); }
EXPORT_C int HEXED_SetSize(int w, int h) { return Apply(calc::MODE_SIZE, 0, w, h); }

EXPORT_C int HEXED_SetBars(int on)
{
    int mode, pct, rw, rh;
    { Lock l(&g_mu); g_bars = on != 0; SaveConfig(); mode = g_mode; pct = g_pct; rw = g_reqW; rh = g_reqH; }
    return mode == calc::MODE_NONE ? 1 : Apply(mode, pct, rw, rh);
}
EXPORT_C int HEXED_GetBars() { return g_bars ? 1 : 0; }

EXPORT_C int HEXED_SetTouchRemap(int on)
{
    Lock l(&g_mu);
    g.touchRemap = on ? 1 : 0;
    SaveConfig();
    return 1;
}
EXPORT_C int HEXED_GetTouchRemap() { return g.touchRemap.load(); }

// 0 hookMask  1 haveActivity  2 javaCalls  3 touchCalls  4 viewW  5 viewH  6 bufferCalls  7 dataDirOk  8 stage  9 uiDispatcher
// 10 touch path (0 native hooks / off, 1 gate, 2 callback proxy)  11 picture x in window  12 picture y in window
EXPORT_C int HEXED_GetInfo(int idx)
{
    switch (idx) {
    case 0: return (int)natives::HookMask();
    case 1: return surface::HaveActivity() ? 1 : 0;
    case 2: return (int)g.javaCalls.load();
    case 3: return (int)g.touchCalls.load();
    case 4: return g.nativeW.load();
    case 5: return g.nativeH.load();
    case 6: return (int)g.bufferCalls.load();
    case 7: return hexed::DataDir() ? 1 : 0;
    case 8: return g_stage;
    case 9: return ui::Ready() ? 1 : 0;
    case 10: return g.proxyOn.load() ? 2 : (g.gateOn.load() ? 1 : 0);
    case 11: return g.offX.load();
    case 12: return g.offY.load();
    }
    return 0;
}

// ---------- crash guard ----------
// hexed_resolution.boot holds the stage of a start that has not yet survived 15 s. Closing the game early also leaves it
// behind, so ONE leftover marker only retries the same stage; two failed starts in a row drop one stage and remember it in
// hexed_resolution.stage. A stage saved by another plugin version is ignored, so every new build starts at full (3).
static const int BUILD_ID = 108;                     // bump with every release
static std::atomic<unsigned> g_bootGen{0};
static void* BootThread(void* arg)
{
    unsigned gen = (unsigned)(uintptr_t)arg;
    SleepSeconds(15);
    if (gen == g_bootGen.load()) {
        hexed::RemoveFile("hexed_resolution.boot");
        hexed::RemoveFile("hexed_resolution.fails");
        hexed::HLog("boot ok (15 s)");
    }
    return nullptr;
}

static int ChooseStage()
{
    int ver = 0;
    if (!hexed::ReadIntFile("hexed_resolution.stagever", &ver) || ver != BUILD_ID) {
        if (hexed::ReadIntFile("hexed_resolution.stage", &ver))
            hexed::HLog("ignoring stage file from another plugin version");
        hexed::RemoveFile("hexed_resolution.stage");
        hexed::RemoveFile("hexed_resolution.boot");
        hexed::RemoveFile("hexed_resolution.fails");
        hexed::WriteIntFile("hexed_resolution.stagever", BUILD_ID);
    }
    int desired = 3;
    hexed::ReadIntFile("hexed_resolution.stage", &desired);
    if (desired < 0) desired = 0;
    if (desired > 3) desired = 3;
    int stage = desired, attempted = 0;
    if (hexed::ReadIntFile("hexed_resolution.boot", &attempted)) {
        int fails = 0;
        hexed::ReadIntFile("hexed_resolution.fails", &fails);
        ++fails;
        if (fails >= 2) {
            stage = attempted > 0 ? attempted - 1 : 0;
            hexed::HLog("two starts in a row did not survive 15 s at stage %d -> stage %d", attempted, stage);
            if (stage < desired) hexed::WriteIntFile("hexed_resolution.stage", stage);
            fails = 0;
        } else {
            stage = attempted;
            hexed::HLog("previous start did not survive 15 s at stage %d (strike %d of 2) -> same stage again", attempted, fails);
        }
        hexed::WriteIntFile("hexed_resolution.fails", fails);
    }
    hexed::WriteIntFile("hexed_resolution.boot", stage);
    unsigned gen = ++g_bootGen;
    pthread_t t; pthread_attr_t a; pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    if (pthread_create(&t, &a, BootThread, (void*)(uintptr_t)gen) != 0) hexed::RemoveFile("hexed_resolution.boot");
    pthread_attr_destroy(&a);
    return stage;
}

// ---------- mod entry ----------
ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    hexed::HLog("==== HEXED Resolution 1.0.8 loading (log dir: %s) ====", hexed::PublicDir() ? hexed::PublicDir() : "none");
    g_loadTime = time(nullptr);

    g_stage = ChooseStage();
    hexed::HLog("stage %d", g_stage);
    if (g_stage < 1) return;

    hexed::HLog("step: aml->GetLib");
    uintptr_t pGTASA = aml->GetLib("libGTASA.so");
    if (!pGTASA) { hexed::HLog("libGTASA.so not found"); return; }

    bool ok = natives::Init(pGTASA, g_stage);
    hexed::HLog("natives: ok=%d mask=0x%x - load finished", ok ? 1 : 0, natives::HookMask());
}

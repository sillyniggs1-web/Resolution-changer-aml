/*
 * HEXED Resolution - AML plugin for GTA SA Android
 * Target: SA-MP Nezuko v1.0.3 (TESTING) — armeabi-v7a
 *
 * Uses only real exported symbols from the APK's libGTASA.so:
 *   RsGlobal, renderWidth, renderHeight
 *
 * Changes game-internal resolution only (RsGlobal + helpers).
 * Does NOT touch Android system DPI / display resolution.
 */

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <cstdint>
#include <cstdio>
#include <cstring>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 0.1.0, HEXED)

#pragma pack(push, 1)
struct RsGlobalType {
    const char* appName;
    int32_t     maximumWidth;
    int32_t     maximumHeight;
    int32_t     maxFPS;
    int32_t     quit;
    void*       ps;
};
#pragma pack(pop)

static uintptr_t     pGTASA         = 0;
static RsGlobalType* g_RsGlobal     = nullptr;
static int32_t*      g_renderWidth  = nullptr;
static int32_t*      g_renderHeight = nullptr;

static int32_t g_origWidth  = 0;
static int32_t g_origHeight = 0;
static bool    g_hasOriginal = false;
static bool    g_applied     = false;

static bool IsSaneResolution(int w, int h)
{
    if (w < 320 || h < 240) return false;
    if (w > 4096 || h > 4096) return false;
    if ((w & 1) || (h & 1)) return false;
    return true;
}

static void SaveOriginal()
{
    if (!g_RsGlobal || g_hasOriginal) return;
    g_origWidth  = g_RsGlobal->maximumWidth;
    g_origHeight = g_RsGlobal->maximumHeight;
    g_hasOriginal = true;
    logger->Info("Saved original resolution %d x %d", g_origWidth, g_origHeight);
}

extern "C" {

__attribute__((visibility("default")))
int HEXED_GetCurrentWidth()
{
    return g_RsGlobal ? g_RsGlobal->maximumWidth : 0;
}

__attribute__((visibility("default")))
int HEXED_GetCurrentHeight()
{
    return g_RsGlobal ? g_RsGlobal->maximumHeight : 0;
}

__attribute__((visibility("default")))
int HEXED_GetOriginalWidth()
{
    return g_hasOriginal ? g_origWidth : 0;
}

__attribute__((visibility("default")))
int HEXED_GetOriginalHeight()
{
    return g_hasOriginal ? g_origHeight : 0;
}

__attribute__((visibility("default")))
int HEXED_IsApplied()
{
    return g_applied ? 1 : 0;
}

__attribute__((visibility("default")))
int HEXED_Apply(int width, int height)
{
    if (!g_RsGlobal) {
        logger->Error("HEXED_Apply: RsGlobal not ready");
        return 0;
    }
    if (!IsSaneResolution(width, height)) {
        logger->Error("HEXED_Apply: rejected %d x %d", width, height);
        return 0;
    }

    SaveOriginal();

    g_RsGlobal->maximumWidth  = width;
    g_RsGlobal->maximumHeight = height;
    if (g_renderWidth)  *g_renderWidth  = width;
    if (g_renderHeight) *g_renderHeight = height;

    g_applied = true;
    logger->Info("Applied %d x %d", width, height);
    return 1;
}

__attribute__((visibility("default")))
int HEXED_Reset()
{
    if (!g_RsGlobal || !g_hasOriginal) {
        logger->Warning("HEXED_Reset: nothing to restore");
        return 0;
    }

    g_RsGlobal->maximumWidth  = g_origWidth;
    g_RsGlobal->maximumHeight = g_origHeight;
    if (g_renderWidth)  *g_renderWidth  = g_origWidth;
    if (g_renderHeight) *g_renderHeight = g_origHeight;

    g_applied = false;
    logger->Info("Reset to original %d x %d", g_origWidth, g_origHeight);
    return 1;
}

__attribute__((visibility("default")))
int HEXED_SaveSettings(int width, int height)
{
    const char* candidates[] = {
        "/sdcard/Android/data/com.nezukosamp.game/files/hexed_resolution.cfg",
        "/sdcard/Android_unprotected/data/com.nezukosamp.game/files/hexed_resolution.cfg",
        "/sdcard/Android/data/com.rockstargames.gtasa/files/hexed_resolution.cfg",
        "/sdcard/hexed_resolution.cfg",
        nullptr
    };

    for (int i = 0; candidates[i]; ++i) {
        FILE* f = fopen(candidates[i], "w");
        if (f) {
            fprintf(f, "%d %d\n", width, height);
            fclose(f);
            logger->Info("Saved settings to %s", candidates[i]);
            return 1;
        }
    }
    logger->Warning("Could not write config file");
    return 0;
}

__attribute__((visibility("default")))
int HEXED_LoadSettings(int* outW, int* outH)
{
    if (!outW || !outH) return 0;

    const char* candidates[] = {
        "/sdcard/Android/data/com.nezukosamp.game/files/hexed_resolution.cfg",
        "/sdcard/Android_unprotected/data/com.nezukosamp.game/files/hexed_resolution.cfg",
        "/sdcard/Android/data/com.rockstargames.gtasa/files/hexed_resolution.cfg",
        "/sdcard/hexed_resolution.cfg",
        nullptr
    };

    for (int i = 0; candidates[i]; ++i) {
        FILE* f = fopen(candidates[i], "r");
        if (f) {
            int w = 0, h = 0;
            if (fscanf(f, "%d %d", &w, &h) == 2 && IsSaneResolution(w, h)) {
                *outW = w;
                *outH = h;
                fclose(f);
                logger->Info("Loaded settings %d x %d from %s", w, h, candidates[i]);
                return 1;
            }
            fclose(f);
        }
    }
    return 0;
}

} // extern "C"

extern "C" void OnModLoad()
{
    logger->SetTag("HEXED_Resolution");
    logger->Info("HEXED Resolution loading...");

    pGTASA = aml->GetLib("libGTASA.so");
    if (!pGTASA) {
        logger->Error("libGTASA.so not found");
        return;
    }

    g_RsGlobal = reinterpret_cast<RsGlobalType*>(aml->GetSym(pGTASA, "RsGlobal"));
    if (!g_RsGlobal) {
        logger->Error("RsGlobal symbol not found");
        return;
    }

    g_renderWidth  = reinterpret_cast<int32_t*>(aml->GetSym(pGTASA, "renderWidth"));
    g_renderHeight = reinterpret_cast<int32_t*>(aml->GetSym(pGTASA, "renderHeight"));

    logger->Info("RsGlobal @ %p  (maxW=%d maxH=%d)",
                 g_RsGlobal,
                 g_RsGlobal->maximumWidth,
                 g_RsGlobal->maximumHeight);

    SaveOriginal();

    int w = 0, h = 0;
    if (HEXED_LoadSettings(&w, &h)) {
        logger->Info("Auto-applying saved %d x %d", w, h);
        HEXED_Apply(w, h);
    }

    logger->Info("HEXED Resolution ready (original %d x %d)", g_origWidth, g_origHeight);
}

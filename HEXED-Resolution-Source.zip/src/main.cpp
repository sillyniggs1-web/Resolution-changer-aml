/*
 * HEXED Resolution 1.0.1 - "fixed surface" edition
 * Target: SA-MP Nezuko v1.0.3 (TESTING) - armeabi-v7a
 *
 * How it works (see docs/NOTES.md for the evidence):
 *   1. The game's own resize path is Java surfaceChanged -> setGameWindowSize -> native setWindowSize(w,h),
 *      which posts a window-size event to the game thread. We hook that native: while an override is
 *      active the game is told OUR size, and we can post the same event ourselves at runtime.
 *   2. The real EGL surface buffers are resized with ANativeWindow_setBuffersGeometry, so the surface
 *      IS the picture and Android scales it to the screen (no stale area, no corner picture).
 *   3. Android delivers touch in screen pixels; touchEvent/multiTouchEvent are hooked and remapped.
 *
 * Replaced from 0.5.x: OS_ScreenSetResolution (an empty stub in this build), direct RsGlobal/renderWidth
 * writes, the OS_ScreenGet* hooks and the GL "present pass" (center.cpp).
 */
#include <mod/amlmod.h>
#include <mod/logger.h>
#include "hlog.h"
#include <mod/config.h>

#include "state.h"
#include "calc.h"

#include <atomic>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 1.0.1, HEXED)

namespace hexed { Shared g; }
using namespace hexed;

// ---------- state (guarded by g_mu; hooks only read the atomics in hexed::g) ----------
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
struct Lock { pthread_mutex_t* m; explicit Lock(pthread_mutex_t* x) : m(x) { pthread_mutex_lock(m); } ~Lock() { pthread_mutex_unlock(m); } };

static int    g_mode = calc::MODE_NONE;
static int    g_pct = 100, g_reqW = 0, g_reqH = 0;
static bool   g_ready = false, g_cfgLoaded = false, g_safeMode = false;
static time_t g_loadTime = 0, g_lastFallback = 0;
static int    g_fallbackTries = 0;
static char   g_err[200] = "";
static int    g_stage = 3;

static void SetErr(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    hexed::HLog("%s", g_err);
}

// ---------- files: config + "pending" marker (safe mode) ----------
static bool PathOf(char* out, size_t n, const char* file)
{
    const char* d = hexed::DataDir();
    if (!d) return false;
    snprintf(out, n, "%s/%s", d, file);
    return true;
}

static void WriteMarker() { char p[300]; if (PathOf(p, sizeof(p), "hexed_resolution.pending")) if (FILE* f = fopen(p, "w")) { fputs("1\n", f); fclose(f); } }
static void ClearMarker() { char p[300]; if (PathOf(p, sizeof(p), "hexed_resolution.pending")) unlink(p); }
static bool MarkerExists(){ char p[300]; return PathOf(p, sizeof(p), "hexed_resolution.pending") && access(p, F_OK) == 0; }

// The marker stays for 10 s after a setting is applied. If the game is closed within that time
// (setting unusable / crash) the next launch starts in safe mode with the setting cleared.
static std::atomic<unsigned> g_markerGen{0};
static void* MarkerThread(void* arg)
{
    unsigned gen = (unsigned)(uintptr_t)arg;
    sleep(10);
    if (gen == g_markerGen.load()) ClearMarker();
    return nullptr;
}
static void ArmMarker()
{
    WriteMarker();
    unsigned gen = ++g_markerGen;
    pthread_t t; pthread_attr_t a; pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    if (pthread_create(&t, &a, MarkerThread, (void*)(uintptr_t)gen) != 0) ClearMarker();
    pthread_attr_destroy(&a);
}

static void SaveConfig()
{
    char p[300]; if (!PathOf(p, sizeof(p), "hexed_resolution.cfg")) return;
    if (FILE* f = fopen(p, "w")) {
        fprintf(f, "HXDRES1 %d %d %d %d %d\n", g_mode, g_pct, g_reqW, g_reqH, g.touchRemap.load());
        fclose(f);
    }
}

static void LoadConfig()
{
    char p[300]; if (!PathOf(p, sizeof(p), "hexed_resolution.cfg")) return;
    FILE* f = fopen(p, "r"); if (!f) return;
    char tag[16] = {0}; int mode = 0, pct = 100, rw = 0, rh = 0, touch = 1;
    if (fscanf(f, "%15s %d %d %d %d %d", tag, &mode, &pct, &rw, &rh, &touch) == 6 && !strcmp(tag, "HXDRES1")) {
        if (mode >= calc::MODE_NONE && mode <= calc::MODE_SIZE) {
            g_mode = mode; g_pct = pct; g_reqW = rw; g_reqH = rh;
            g.touchRemap = touch ? 1 : 0;
        }
    }
    fclose(f);
}

static void StartupLoad()      // caller holds g_mu; runs once, on the first sign of the game window
{
    if (MarkerExists()) {
        g_safeMode = true;
        ClearMarker();
        g_mode = calc::MODE_NONE;
        SaveConfig();
        hexed::HLog("Safe mode: last session ended right after a resolution change - setting cleared");
        return;
    }
    LoadConfig();
    if (g_mode != calc::MODE_NONE) { ArmMarker(); hexed::HLog("Saved setting loaded (mode %d)", g_mode); }
}

// ---------- core ----------
// caller holds g_mu. Brings surface buffers + Java fields in line with the requested mode.
static void SyncToJava(bool post)
{
    if (g_mode == calc::MODE_NONE) return;
    int aw = 0, ah = 0;
    if (!calc::Compute(g_mode, g_pct, g_reqW, g_reqH, g.nativeW.load(), g.nativeH.load(), &aw, &ah)) {
        SetErr("saved setting does not fit this screen (%dx%d) - reset", g.nativeW.load(), g.nativeH.load());
        g_mode = calc::MODE_NONE; g.overrideOn = 0;
        return;
    }
    g.activeW = aw; g.activeH = ah; g.overrideOn = 1;
    surface::SetBufferSize(aw, ah);
    surface::SetJavaSurfaceFields(aw, ah);
    if (post) natives::PostWindowSize(aw, ah);
}

void hexed::OnJavaWindowSize(JNIEnv* env, jobject thiz, int w, int h)    // UI thread, from the setWindowSize hook
{
    surface::Attach(env, thiz);
    int vw = 0, vh = 0;
    if (!surface::ViewSize(&vw, &vh)) {
        if (g.overrideOn.load()) { vw = g.nativeW.load(); vh = g.nativeH.load(); }
        else { vw = w; vh = h; }
    }
    Lock l(&g_mu);
    if (vw > 0 && vh > 0) { g.nativeW = vw; g.nativeH = vh; }
    if (g.nativeW.load() <= 0) return;
    if (!g_cfgLoaded) { g_cfgLoaded = true; StartupLoad(); }
    if (!g_ready) { g_ready = true; hexed::HLog("Ready. native=%dx%d", g.nativeW.load(), g.nativeH.load()); }
    SyncToJava(false);      // the hook forwards the override to the game itself
}

static int ResetLocked()
{
    g_mode = calc::MODE_NONE;
    g.overrideOn = 0;
    g.activeW = g.nativeW.load(); g.activeH = g.nativeH.load();
    surface::SetBufferSize(0, 0);
    surface::SetJavaSurfaceFields(g.nativeW.load(), g.nativeH.load());
    natives::PostWindowSize(g.nativeW.load(), g.nativeH.load());
    SaveConfig();
    ClearMarker();
    hexed::HLog("Reset to native %dx%d", g.nativeW.load(), g.nativeH.load());
    return 1;
}

static int Apply(int mode, int pct, int rw, int rh)
{
    Lock l(&g_mu);
    if (!g_ready) { SetErr("game not ready yet"); return 0; }
    int nw = g.nativeW.load(), nh = g.nativeH.load(), aw = 0, ah = 0;
    if (!calc::Compute(mode, pct, rw, rh, nw, nh, &aw, &ah)) {
        SetErr("rejected (min %dx%d, max side %d)", calc::MIN_W, calc::MIN_H, calc::MAX_SIDE);
        return 0;
    }
    if (aw == nw && ah == nh) return ResetLocked();

    int oMode = g_mode, oPct = g_pct, oW = g_reqW, oH = g_reqH;
    int oAW = g.activeW.load(), oAH = g.activeH.load(), oOn = g.overrideOn.load();
    g_mode = mode; g_pct = pct; g_reqW = rw; g_reqH = rh;
    ArmMarker();
    g.activeW = aw; g.activeH = ah; g.overrideOn = 1;

    if (!surface::SetBufferSize(aw, ah)) {
        SetErr("%s", surface::LastError());
        g_mode = oMode; g_pct = oPct; g_reqW = oW; g_reqH = oH;
        g.activeW = oAW; g.activeH = oAH; g.overrideOn = oOn;
        return 0;
    }
    surface::SetJavaSurfaceFields(aw, ah);
    if (!natives::PostWindowSize(aw, ah)) {
        SetErr("cannot reach the game's setWindowSize");
        ResetLocked();
        return 0;
    }
    SaveConfig();
    hexed::HLog("Applied %dx%d (native %dx%d, mode %d)", aw, ah, nw, nh, mode);
    return 1;
}

// ---------- exported C API (used by lua/hexed_resolution.lua through ffi) ----------
#define EXPORT_C extern "C" __attribute__((visibility("default")))

EXPORT_C int HEXED_Tick()
{
    Lock l(&g_mu);
    if (!g_ready && !surface::HaveActivity() && g_fallbackTries < 6 &&
        time(nullptr) - g_loadTime >= 3 && time(nullptr) != g_lastFallback) {
        g_lastFallback = time(nullptr);
        ++g_fallbackTries;
        if (surface::FindActivityFallback()) {
            int vw = 0, vh = 0;
            if (surface::ViewSize(&vw, &vh)) {
                g.nativeW = vw; g.nativeH = vh;
                if (!g_cfgLoaded) { g_cfgLoaded = true; StartupLoad(); }
                g_ready = true;
                hexed::HLog("Ready (late attach). native=%dx%d", vw, vh);
                SyncToJava(true);
            }
        }
    }
    return g_ready ? 1 : 0;
}

EXPORT_C int HEXED_IsReady()        { return g_ready ? 1 : 0; }
EXPORT_C int HEXED_GetMode()        { return g_mode; }
EXPORT_C int HEXED_GetOverride()    { return g.overrideOn.load(); }
EXPORT_C int HEXED_WasSafeMode()    { return g_safeMode ? 1 : 0; }
EXPORT_C int HEXED_GetNativeW()     { return g.nativeW.load(); }
EXPORT_C int HEXED_GetNativeH()     { return g.nativeH.load(); }
EXPORT_C int HEXED_GetActiveW()     { return g.overrideOn.load() ? g.activeW.load() : g.nativeW.load(); }
EXPORT_C int HEXED_GetActiveH()     { return g.overrideOn.load() ? g.activeH.load() : g.nativeH.load(); }
EXPORT_C int HEXED_GetScalePercent(){ return g_mode == calc::MODE_SCALE ? g_pct : 100; }
EXPORT_C int HEXED_GetMinW()        { return calc::MIN_W; }
EXPORT_C int HEXED_GetMinH()        { return calc::MIN_H; }
EXPORT_C int HEXED_GetMaxSide()     { return calc::MAX_SIDE; }
EXPORT_C const char* HEXED_GetError(){ return g_err; }

EXPORT_C int HEXED_PercentToWidth(int p)
{
    int w = 0, h = 0;
    return calc::Compute(calc::MODE_SCALE, p, 0, 0, g.nativeW.load(), g.nativeH.load(), &w, &h) ? w : 0;
}
EXPORT_C int HEXED_PercentToHeight(int p)
{
    int w = 0, h = 0;
    return calc::Compute(calc::MODE_SCALE, p, 0, 0, g.nativeW.load(), g.nativeH.load(), &w, &h) ? h : 0;
}
EXPORT_C int HEXED_HeightToWidth(int hh)
{
    int w = 0, h = 0;
    return calc::Compute(calc::MODE_HEIGHT, 0, 0, hh, g.nativeW.load(), g.nativeH.load(), &w, &h) ? w : 0;
}

EXPORT_C int HEXED_Reset()
{
    Lock l(&g_mu);
    if (!g_ready) { SetErr("game not ready yet"); return 0; }
    return ResetLocked();
}

EXPORT_C int HEXED_SetScale(int p)
{
    if (p >= 100) return HEXED_Reset();          // 100 % == native
    return Apply(calc::MODE_SCALE, p, 0, 0);
}
EXPORT_C int HEXED_SetHeight(int h) { return Apply(calc::MODE_HEIGHT, 0, 0, h); }
EXPORT_C int HEXED_SetSize(int w, int h) { return Apply(calc::MODE_SIZE, 0, w, h); }
EXPORT_C int HEXED_SetTouchRemap(int on)
{
    Lock l(&g_mu);
    g.touchRemap = on ? 1 : 0;
    SaveConfig();
    return 1;
}
EXPORT_C int HEXED_GetTouchRemap() { return g.touchRemap.load(); }

// 0 hookMask  1 haveActivity  2 javaCalls  3 touchCalls  4 viewW  5 viewH  6 bufferCalls  7 dataDirOk  8 stage
EXPORT_C int HEXED_GetInfo(int idx)
{
    switch (idx) {
    case 0: return (int)natives::HookMask();
    case 1: return surface::HaveActivity() ? 1 : 0;
    case 2: return (int)g.javaCalls.load();
    case 3: return (int)g.touchCalls.load();
    case 4: return g.nativeW.load();
    case 5: return g.nativeH.load();
    case 6: return (int)g.bufferCalls.load();
    case 7: return hexed::DataDir() ? 1 : 0;
    case 8: return g_stage;
    }
    return 0;
}

// ---------- crash guard ----------
// hexed_resolution.boot holds the stage of a start that has not yet survived 15 s. If it is still there at the
// next start, that start died: drop one stage and remember it in hexed_resolution.stage (delete that file to retry).
static std::atomic<unsigned> g_bootGen{0};
static void* BootThread(void* arg)
{
    unsigned gen = (unsigned)(uintptr_t)arg;
    sleep(15);
    if (gen == g_bootGen.load()) { hexed::RemoveFile("hexed_resolution.boot"); hexed::HLog("boot ok (15 s)"); }
    return nullptr;
}

static int ChooseStage()
{
    int desired = 3;
    hexed::ReadIntFile("hexed_resolution.stage", &desired);
    if (desired < 0) desired = 0;
    if (desired > 3) desired = 3;
    int stage = desired, attempted = 0;
    if (hexed::ReadIntFile("hexed_resolution.boot", &attempted)) {
        stage = attempted > 0 ? attempted - 1 : 0;
        hexed::HLog("previous start did not survive 15 s at stage %d -> trying stage %d", attempted, stage);
        if (stage < desired) hexed::WriteIntFile("hexed_resolution.stage", stage);
    }
    hexed::WriteIntFile("hexed_resolution.boot", stage);
    unsigned gen = ++g_bootGen;
    pthread_t t; pthread_attr_t a; pthread_attr_init(&a);
    pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
    if (pthread_create(&t, &a, BootThread, (void*)(uintptr_t)gen) != 0) hexed::RemoveFile("hexed_resolution.boot");
    pthread_attr_destroy(&a);
    return stage;
}

// ---------- mod entry ----------
ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    hexed::HLog("==== HEXED Resolution 1.0.1 loading (log dir: %s) ====", hexed::PublicDir() ? hexed::PublicDir() : "none");
    g_loadTime = time(nullptr);

    g_stage = ChooseStage();
    hexed::HLog("stage %d", g_stage);
    if (g_stage < 1) return;

    hexed::HLog("step: aml->GetLib");
    uintptr_t pGTASA = aml->GetLib("libGTASA.so");
    if (!pGTASA) { hexed::HLog("libGTASA.so not found"); return; }

    bool ok = natives::Init(pGTASA, g_stage);
    hexed::HLog("natives: ok=%d mask=0x%x - load finished", ok ? 1 : 0, natives::HookMask());
}

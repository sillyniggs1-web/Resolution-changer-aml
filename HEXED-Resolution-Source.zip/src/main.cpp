/*
 * HEXED Resolution v4.0.0 - AML plugin for GTA SA Android
 * Target: SA-MP Nezuko v1.0.3 (TESTING) - armeabi-v7a
 *
 * TWO MODES (engine contract verified in libGTASA.so: touch px == windowSize == real surface size)
 *  1. RENDER SCALE (recommended, default): writes the engine's own resolution setting
 *     MobileSettings::settings + 0x28 (int 0..100). Idle() then renders the scene into an offscreen target
 *       w = 640 + (screenW-640)*pct/100,  h = screenH*w/screenW  (both rounded up to a multiple of 4)
 *     and stretches it to the full surface. Touch, HUD layout and aspect are untouched. No hooks.
 *  2. WINDOW SIZE (experimental): posts the engine's own window-resize event (see below). Because the real
 *     EGL surface and Android touch coordinates are NOT resized, HUD/touch/viewport can disagree. Off by default.
 *
 * WINDOW-SIZE METHOD: tell the game its window changed size (same path as a real Android surface change)
 * ------------------------------------------------------------------------------------------
 * Verified in libGTASA.so (1.0.3):
 *   Java  NvEventQueueActivity.setGameWindowSize(w,h) -> native setWindowSize(w,h) (JNI stub @0x273e3c)
 *         -> NVEventPostEvent({type=6, w, h})            (shared post fn @0x27c4f0, 24-byte events, mutex queue)
 *   ProcessEvents() (main thread, start of frame) handles type 6:  windowSize = {w, h}
 *   OS_ScreenGetWidth/Height read `windowSize` live and feed: CAdjustableHUD (touch HUD layout),
 *   CDraw::CalculateAspectRatio (camera aspect), CSprite::CalcScreenCoors, emu_glViewport,
 *   RQ target select/scissor, Idle() (render-target size).
 * No code is hooked or patched. If the post function's bytes do not match this build we fall back to
 * one strd store into `windowSize` (what event type 6 itself does).
 *
 * v3.1 SAFETY / DIAGNOSTICS
 *   - Crash-loop guard: a "pending" flag file is written before a size is applied and removed after the
 *     size has been stable for 20 s. If it is still there at the next launch the previous apply crashed
 *     the game, so the saved size is dropped (safe mode) instead of crashing again.
 *   - Breadcrumb log + crash recorder: <Android/data/pkg/files>/HEXED/hexed_resolution.log
 *     records every step, the engine's reaction, and on SIGSEGV/SIGBUS/SIGFPE/SIGILL/SIGABRT the
 *     fault address, pc/lr (with library + offset) and the last step. The previous handler is chained,
 *     so the game crashes exactly as it did before.
 */

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <dlfcn.h>
#include <time.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <ucontext.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 4.0.0, HEXED)

#define POST_EVENT_RVA   0x27c4f0u   /* NVEventPostEvent in 1.0.3 libGTASA.so */
#define EVT_WINDOW_SIZE  6
#define MIN_W 320
#define MIN_H 180
#define MAX_SIDE 2560                /* keeps the render target inside safe GPU memory */
#define STABLE_MS 20000              /* size must survive this long before the crash flag is cleared */

typedef void (*PostEventFn)(void*);

static uintptr_t   g_lib       = 0;
static PostEventFn g_post      = nullptr;       // nullptr => fallback to direct store
static volatile uint32_t* g_windowSize = nullptr; // [0]=w [1]=h
static volatile uint8_t*  g_loaded     = nullptr; // MobileSettings::loaded
static volatile int32_t*  g_renderW    = nullptr; // read only
static volatile int32_t*  g_renderH    = nullptr;

static volatile int*      g_pct        = nullptr; // MobileSettings::settings + 0x28
static volatile int g_scaleOk = 0, g_scaleOverride = 0, g_scaleWant = 100, g_scaleOrig = 100;

static volatile int g_ready    = 0;
static volatile int g_override = 0;
static volatile int g_safeMode = 0;
static volatile int g_wantW = 0, g_wantH = 0;
static volatile int g_nativeW = 0, g_nativeH = 0;
static volatile const char* g_phase = "init";

static int       g_logfd = -1;
static long long g_t0 = 0;
static volatile long long g_traceUntil = 0, g_lastPost = 0;

static inline int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int CurW() { return g_windowSize ? (int)g_windowSize[0] : 0; }
static int CurH() { return g_windowSize ? (int)g_windowSize[1] : 0; }

/* exactly what Idle() computes for the render target at a given percentage of a given screen */
static void EngineSize(int sw, int sh, int pct, int* ow, int* oh)
{
    if (sw <= 0 || sh <= 0) { *ow = *oh = 0; return; }
    int w = (sw > 640) ? 640 + ((sw - 640) * pct) / 100 : sw;
    int h = (int)((long long)sh * w / sw);
    *ow = (w + 3) & ~3; *oh = (h + 3) & ~3;
}

static long long NowMs()
{
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

/* ---------------- paths / log ---------------- */
static std::string CfgDir()     { return std::string(aml->GetAndroidDataPath()) + "/HEXED"; }
static std::string CfgPath()    { return CfgDir() + "/hexed_resolution.cfg"; }
static std::string LogPath()    { return CfgDir() + "/hexed_resolution.log"; }
static std::string PendingPath(){ return CfgDir() + "/apply.pending"; }

static void Log(const char* fmt, ...)
{
    char msg[300]; va_list ap; va_start(ap, fmt); vsnprintf(msg, sizeof(msg), fmt, ap); va_end(ap);
    logger->Info("%s", msg);
    if (g_logfd < 0) return;
    char line[360];
    int n = snprintf(line, sizeof(line), "[%7lld ms] %s\n", NowMs() - g_t0, msg);
    if (n > 0) { (void)!write(g_logfd, line, (size_t)n); fsync(g_logfd); }   // survive a crash
}

static void OpenLog()
{
    aml->CreateDirRecursive(CfgDir().c_str());
    struct stat st;
    int flags = O_WRONLY | O_CREAT | O_APPEND;
    if (stat(LogPath().c_str(), &st) == 0 && st.st_size > 100 * 1024) flags |= O_TRUNC;
    g_logfd = open(LogPath().c_str(), flags, 0644);
}

/* ---------------- crash recorder (chains to the previous handler) ---------------- */
static const int kSigs[] = { SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGABRT };
static struct sigaction g_old[32];
static volatile int g_reinstalls = 0;

static void CrashHandler(int sig, siginfo_t* si, void* uc_)
{
    static volatile int inside = 0;
    if (!inside) {
        inside = 1;
        uintptr_t pc = 0, lr = 0, sp = 0;
#if defined(__ANDROID__) && defined(__arm__)
        ucontext_t* uc = (ucontext_t*)uc_;
        pc = uc->uc_mcontext.arm_pc; lr = uc->uc_mcontext.arm_lr; sp = uc->uc_mcontext.arm_sp;
#else
        (void)uc_;
#endif
        char b[700]; Dl_info a, c; memset(&a, 0, sizeof(a)); memset(&c, 0, sizeof(c));
        dladdr((void*)pc, &a); dladdr((void*)lr, &c);
        const char* an = a.dli_fname ? strrchr(a.dli_fname, '/') : nullptr;
        const char* cn = c.dli_fname ? strrchr(c.dli_fname, '/') : nullptr;
        int n = snprintf(b, sizeof(b),
            "*** CRASH sig=%d code=%d addr=%p tid=%d\n    pc=%p (%s+0x%lx)\n    lr=%p (%s+0x%lx)\n    sp=%p  last-step=%s\n    window=%dx%d renderTarget=%dx%d want=%dx%d override=%d\n",
            sig, si ? si->si_code : 0, si ? si->si_addr : nullptr, (int)syscall(__NR_gettid),
            (void*)pc, an ? an + 1 : "?", a.dli_fbase ? (unsigned long)(pc - (uintptr_t)a.dli_fbase) : 0UL,
            (void*)lr, cn ? cn + 1 : "?", c.dli_fbase ? (unsigned long)(lr - (uintptr_t)c.dli_fbase) : 0UL,
            (void*)sp, (const char*)g_phase, CurW(), CurH(),
            g_renderW ? (int)*g_renderW : -1, g_renderH ? (int)*g_renderH : -1,
            (int)g_wantW, (int)g_wantH, (int)g_override);
        if (g_logfd >= 0 && n > 0) { (void)!write(g_logfd, b, (size_t)n); fsync(g_logfd); }
    }
    struct sigaction& o = g_old[sig];
    if ((o.sa_flags & SA_SIGINFO) && o.sa_sigaction) { o.sa_sigaction(sig, si, uc_); return; }
    if (o.sa_handler && o.sa_handler != SIG_DFL && o.sa_handler != SIG_IGN) { o.sa_handler(sig); return; }
    signal(sig, SIG_DFL);   // returning re-faults / abort() re-raises -> normal crash, nothing swallowed
}

static void InstallCrashHandlers()
{
    for (int s : kSigs) {
        struct sigaction cur; if (sigaction(s, nullptr, &cur) != 0) continue;
        if ((cur.sa_flags & SA_SIGINFO) && cur.sa_sigaction == CrashHandler) continue;
        g_old[s] = cur;
        struct sigaction sa; memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = CrashHandler; sa.sa_flags = SA_SIGINFO | SA_NODEFER; sigemptyset(&sa.sa_mask);
        sigaction(s, &sa, nullptr);
    }
}

/* ---------------- posting the new window size ---------------- */
static bool PostSize(int w, int h)
{
    if (w < MIN_W || h < MIN_H || w > MAX_SIDE || h > MAX_SIDE) return false;
    g_lastPost = NowMs();
    if (g_post) {
        g_phase = "post-event";
        alignas(8) uint32_t ev[16]; memset(ev, 0, sizeof(ev));
        ev[0] = EVT_WINDOW_SIZE; ev[1] = (uint32_t)w; ev[2] = (uint32_t)h;
        g_post(ev);
        g_phase = "post-event-done";
        return true;
    }
    if (!g_windowSize) return false;
    g_phase = "direct-store";
#if defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7__)
    uint64_t v = (uint64_t)(uint32_t)w | ((uint64_t)(uint32_t)h << 32);
    __asm__ volatile("strd %Q0, %R0, [%1]" :: "r"(v), "r"(g_windowSize) : "memory");   // plain strd like the engine
#else
    g_windowSize[0] = (uint32_t)w; g_windowSize[1] = (uint32_t)h;
#endif
    g_phase = "direct-store-done";
    return true;
}

/* ---------------- config + crash-loop guard ---------------- */
static bool PendingExists() { struct stat st; return stat(PendingPath().c_str(), &st) == 0; }
static void SetPending(bool on)
{
    if (on) { int fd = open(PendingPath().c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644); if (fd >= 0) { (void)!write(fd, "1", 1); fsync(fd); close(fd); } }
    else unlink(PendingPath().c_str());
}

static void SaveCfg()
{
    FILE* f = fopen(CfgPath().c_str(), "w");
    if (!f) { Log("Cannot write %s", CfgPath().c_str()); return; }
    fprintf(f, "%d %d %d %d %d\n", (int)g_override, (int)g_wantW, (int)g_wantH, (int)g_scaleOverride, (int)g_scaleWant);
    fflush(f); fsync(fileno(f)); fclose(f);
}

static void LoadCfg()
{
    if (PendingExists()) {
        g_safeMode = 1; g_override = 0; g_scaleOverride = 0; SetPending(false); SaveCfg();
        Log("SAFE MODE: the previous run ended before a size was stable (crash). Saved size dropped.");
        return;
    }
    FILE* f = fopen(CfgPath().c_str(), "r");
    if (!f) return;
    int o = 0, w = 0, h = 0, so = 0, sp = 100;
    int n = fscanf(f, "%d %d %d %d %d", &o, &w, &h, &so, &sp);
    if (n >= 3 && (o == 0 || o == 1) && w >= MIN_W && h >= MIN_H && w <= MAX_SIDE && h <= MAX_SIDE) {
        g_override = o; g_wantW = w; g_wantH = h;
    }
    if (n == 5 && (so == 0 || so == 1) && sp >= 0 && sp <= 100) { g_scaleOverride = so; g_scaleWant = sp; }
    Log("Loaded cfg window=%d %dx%d scale=%d %d%%", (int)g_override, (int)g_wantW, (int)g_wantH, (int)g_scaleOverride, (int)g_scaleWant);
    fclose(f);
}

/* ---------------- watcher ---------------- */
static void* Watcher(void*)
{
    long long stableSince = 0; int lw = -1, lh = -1, lrw = -1, lrh = -1; long long lastHandlerCheck = 0;
    for (;;) {
        long long now = NowMs();
        usleep(now < g_traceUntil ? 50 * 1000 : 250 * 1000);
        now = NowMs();
        if (now - lastHandlerCheck > 1000 && g_reinstalls < 8) { lastHandlerCheck = now; InstallCrashHandlers(); }
        if (!g_windowSize || !g_loaded || !*g_loaded) continue;   // game not fully started
        int cw = CurW(), ch = CurH();
        if (cw <= 0 || ch <= 0) continue;
        if (!g_ready) {
            g_nativeW = cw; g_nativeH = ch; g_ready = 1;
            if (g_pct) {
                int cur = *g_pct;
                if (cur >= 0 && cur <= 100) { g_scaleOrig = cur; g_scaleOk = 1; Log("Render scale available. engine pct=%d", cur); }
                else Log("settings+0x28 = %d out of range - render-scale mode disabled", cur);
            }
            Log("Ready. native window %dx%d, method=%s", cw, ch, g_post ? "NVEventPostEvent" : "direct store");
        }
        int rw = g_renderW ? (int)*g_renderW : 0, rh = g_renderH ? (int)*g_renderH : 0;
        if (now < g_traceUntil && (cw != lw || ch != lh || rw != lrw || rh != lrh))
            Log("trace: window %dx%d renderTarget %dx%d", cw, ch, rw, rh);
        lw = cw; lh = ch; lrw = rw; lrh = rh;

        if (g_scaleOk && g_scaleOverride && *g_pct != g_scaleWant) {      // Menu_LoadSettings may overwrite it
            if (!PendingExists()) SetPending(true);
            Log("render scale: engine had %d%%, setting %d%%", (int)*g_pct, (int)g_scaleWant);
            *g_pct = g_scaleWant;
        }
        if (g_override) {
            if (cw != g_wantW || ch != g_wantH) {
                stableSince = 0;
                if (now - g_lastPost > 1000) {      // first apply after launch, or Android re-posted the real size
                    g_phase = "watch:apply";
                    if (!PendingExists()) SetPending(true);
                    Log("apply %dx%d (window is %dx%d)", (int)g_wantW, (int)g_wantH, cw, ch);
                    g_traceUntil = now + 8000;
                    PostSize(g_wantW, g_wantH);
                }
            } else if (!stableSince) {
                stableSince = now; Log("engine accepted %dx%d", cw, ch);
            } else if (now - stableSince > STABLE_MS && PendingExists()) {
                SetPending(false); Log("size stable for %d s - crash flag cleared", STABLE_MS / 1000);
            }
        }
        if (!g_override && g_scaleOk && g_scaleOverride && *g_pct == g_scaleWant) {
            if (!stableSince) { stableSince = now; Log("render scale %d%% in effect", (int)g_scaleWant); }
            else if (now - stableSince > STABLE_MS && PendingExists()) { SetPending(false); Log("scale stable for %d s - crash flag cleared", STABLE_MS / 1000); }
        }
        g_phase = "idle";
    }
    return nullptr;
}

/* ---------------- C API for Lua ---------------- */
#define HX_EXPORT extern "C" __attribute__((visibility("default")))

HX_EXPORT int HEXED_IsReady()     { return g_ready; }
HX_EXPORT int HEXED_GetOverride() { return g_override; }
HX_EXPORT int HEXED_WasSafeMode() { return g_safeMode; }
HX_EXPORT int HEXED_GetNativeW()  { return g_nativeW; }
HX_EXPORT int HEXED_GetNativeH()  { return g_nativeH; }
HX_EXPORT int HEXED_GetCurrentW() { return CurW(); }
HX_EXPORT int HEXED_GetCurrentH() { return CurH(); }
HX_EXPORT int HEXED_GetActiveW()  { return g_renderW ? *g_renderW : 0; }   // alt render target, 0 = none
HX_EXPORT int HEXED_GetActiveH()  { return g_renderH ? *g_renderH : 0; }
HX_EXPORT int HEXED_GetMaxSide()  { return MAX_SIDE; }
HX_EXPORT int HEXED_GetMinW()     { return MIN_W; }
HX_EXPORT int HEXED_GetMinH()     { return MIN_H; }

HX_EXPORT int HEXED_ScaleAvailable()    { return g_scaleOk; }
HX_EXPORT int HEXED_GetScaleOverride()  { return g_scaleOverride; }
HX_EXPORT int HEXED_GetScalePercent()   { return g_pct ? *g_pct : -1; }       // value the engine uses right now
HX_EXPORT int HEXED_GetScaleOriginal()  { return g_scaleOrig; }
HX_EXPORT int HEXED_PercentToWidth(int p)  { int w, h; EngineSize(g_nativeW, g_nativeH, Clamp(p, 0, 100), &w, &h); return w; }
HX_EXPORT int HEXED_PercentToHeight(int p) { int w, h; EngineSize(g_nativeW, g_nativeH, Clamp(p, 0, 100), &w, &h); return h; }
HX_EXPORT int HEXED_WidthToPercent(int w)  // nearest engine step for a wanted render width, -1 if unavailable
{
    if (!g_ready || g_nativeW <= 640) return -1;
    return Clamp(((w - 640) * 100 + (g_nativeW - 640) / 2) / (g_nativeW - 640), 0, 100);
}

HX_EXPORT int HEXED_SetScale(int p)
{
    if (!g_ready || !g_scaleOk || p < 0 || p > 100) return 0;
    if (g_override) { g_override = 0; PostSize(g_nativeW, g_nativeH); }       // modes are exclusive
    g_phase = "SetScale";
    Log("SetScale %d%% requested (engine had %d%%)", p, (int)*g_pct);
    g_scaleWant = p; g_scaleOverride = 1;
    SetPending(true);
    SaveCfg();
    *g_pct = p;
    Log("SetScale %d%% written", p);
    return 1;
}

HX_EXPORT int HEXED_ResetScale()
{
    if (!g_ready || !g_scaleOk) return 0;
    g_scaleOverride = 0; SetPending(false);
    *g_pct = g_scaleOrig; SaveCfg();
    Log("ResetScale -> %d%%", (int)g_scaleOrig);
    return 1;
}

HX_EXPORT int HEXED_SetSize(int w, int h)
{
    if (!g_ready || w < MIN_W || h < MIN_H || w > MAX_SIDE || h > MAX_SIDE) return 0;
    if (g_scaleOverride && g_scaleOk) { g_scaleOverride = 0; *g_pct = g_scaleOrig; }   // modes are exclusive
    g_phase = "SetSize:pending";
    Log("SetSize %dx%d requested (window %dx%d)", w, h, CurW(), CurH());
    g_wantW = w; g_wantH = h; g_override = 1;
    SetPending(true);
    g_phase = "SetSize:saved";
    SaveCfg();
    g_traceUntil = NowMs() + 8000;
    if (!PostSize(w, h)) { Log("PostSize refused"); return 0; }
    Log("SetSize %dx%d posted", w, h);
    return 1;
}

HX_EXPORT int HEXED_Reset()
{
    if (!g_ready) return 0;
    g_override = 0; SetPending(false);
    if (g_scaleOk && g_scaleOverride) { g_scaleOverride = 0; *g_pct = g_scaleOrig; }
    g_traceUntil = NowMs() + 4000;
    PostSize(g_nativeW, g_nativeH);
    SaveCfg();
    Log("Reset to native %dx%d", (int)g_nativeW, (int)g_nativeH);
    return 1;
}

/* ---------------- load ---------------- */
static bool PostFnLooksRight()
{
    // push {r4,r5,r7,lr}; add r7,sp,#8; mov r4,r0; ldr r0,[pc,#..]; add r0,pc; ldrb r0,[r0]; cmp r0,#0 ...
    static const uint8_t sig[] = { 0xb0,0xb5, 0x02,0xaf, 0x04,0x46, 0x9a,0x48, 0x78,0x44, 0x00,0x78, 0x00,0x28 };
    return memcmp((const void*)(g_lib + POST_EVENT_RVA), sig, sizeof(sig)) == 0;
}

ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    g_t0 = NowMs();
    OpenLog();
    Log("---- HEXED Resolution 3.1.0 loading ----");
    InstallCrashHandlers();

    g_lib = aml->GetLib("libGTASA.so");
    if (!g_lib) { Log("libGTASA.so not found"); return; }

    uintptr_t ws     = aml->GetSym(g_lib, "windowSize");
    uintptr_t loaded = aml->GetSym(g_lib, "_ZN14MobileSettings6loadedE");
    g_renderW = (volatile int32_t*)aml->GetSym(g_lib, "renderWidth");
    g_renderH = (volatile int32_t*)aml->GetSym(g_lib, "renderHeight");
    if (!ws || !loaded) { Log("windowSize / MobileSettings::loaded not found"); return; }
    uintptr_t settings = aml->GetSym(g_lib, "_ZN14MobileSettings8settingsE");
    if (settings) g_pct = (volatile int*)(settings + 0x28);
    g_windowSize = (volatile uint32_t*)ws;
    g_loaded     = (volatile uint8_t*)loaded;
    Log("libGTASA base=%p windowSize=%p", (void*)g_lib, (void*)ws);

    if (PostFnLooksRight()) {
        g_post = (PostEventFn)(g_lib + POST_EVENT_RVA + 1);      // Thumb
        Log("Using NVEventPostEvent (verified bytes)");
    } else {
        Log("NVEventPostEvent bytes differ (or GetLib is not the load base) - using direct windowSize store");
    }

    LoadCfg();
    pthread_t t;
    if (pthread_create(&t, nullptr, Watcher, nullptr) == 0) pthread_detach(t);
    else Log("watcher thread failed");
}

/*
 * HEXED Resolution v3.0.0 - AML plugin for GTA SA Android
 * Target: SA-MP Nezuko v1.0.3 (TESTING) - armeabi-v7a
 *
 * METHOD: tell the game its window changed size (same path as a real Android surface change)
 * ------------------------------------------------------------------------------------------
 * Verified in libGTASA.so (1.0.3):
 *   Java  NvEventQueueActivity.setGameWindowSize(w,h) -> native setWindowSize(w,h) (JNI stub @0x273e3c)
 *         -> NVEventPostEvent({type=6, w, h})            (shared post fn @0x27c4f0, mutex-protected queue)
 *   ProcessEvents() (main thread, start of frame) handles type 6:  windowSize = {w, h}
 *   OS_ScreenGetWidth/Height read `windowSize` live and feed: CAdjustableHUD (touch HUD layout),
 *   CDraw::CalculateAspectRatio (camera aspect), CSprite::CalcScreenCoors, emu_glViewport,
 *   RQ target select/scissor, Idle() (render-target size).
 * So posting a type-6 event resizes HUD + aspect + render target together, safely, at a frame boundary.
 * That is exactly what the reference "Zen Menu" resolution changer does (HUD shrinks, aspect changes).
 *
 * We do NOT hook or patch any code. If the post function's bytes do not match this build we fall back
 * to one atomic 64-bit store into `windowSize` (what event type 6 itself does), never a partial write.
 */

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

#include <pthread.h>
#include <unistd.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

MYMODCFG(net.hexed.resolution, HEXED Resolution, 3.0.0, HEXED)

#define POST_EVENT_RVA   0x27c4f0u   /* NVEventPostEvent in 1.0.3 libGTASA.so */
#define EVT_WINDOW_SIZE  6
#define MIN_W 320
#define MIN_H 180
#define MAX_SIDE 2560                /* keeps the render target inside safe GPU memory */

typedef void (*PostEventFn)(void*);
typedef int  (*GetScreenFn)();

static uintptr_t   g_lib       = 0;
static PostEventFn g_post      = nullptr;       // nullptr => fallback to direct store
static volatile uint32_t* g_windowSize = nullptr; // [0]=w [1]=h
static volatile uint8_t*  g_loaded     = nullptr; // MobileSettings::loaded
static volatile int32_t*  g_renderW    = nullptr; // read only
static volatile int32_t*  g_renderH    = nullptr;

static volatile int g_ready    = 0;
static volatile int g_override = 0;
static volatile int g_wantW = 0, g_wantH = 0;
static volatile int g_nativeW = 0, g_nativeH = 0;

static inline int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int CurW() { return g_windowSize ? (int)g_windowSize[0] : 0; }
static int CurH() { return g_windowSize ? (int)g_windowSize[1] : 0; }

static bool PostSize(int w, int h)
{
    if (w < MIN_W || h < MIN_H || w > MAX_SIDE || h > MAX_SIDE) return false;
    if (g_post) {
        alignas(8) uint32_t ev[16]; memset(ev, 0, sizeof(ev));
        ev[0] = EVT_WINDOW_SIZE; ev[1] = (uint32_t)w; ev[2] = (uint32_t)h;
        g_post(ev);
        return true;
    }
    if (!g_windowSize) return false;
    // windowSize is only 4-byte aligned, so no ldrex/strex (needs 8). Use plain strd exactly like the engine.
#if defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7__)
    uint64_t v = (uint64_t)(uint32_t)w | ((uint64_t)(uint32_t)h << 32);
    __asm__ volatile("strd %Q0, %R0, [%1]" :: "r"(v), "r"(g_windowSize) : "memory");
#else
    g_windowSize[0] = (uint32_t)w; g_windowSize[1] = (uint32_t)h;
#endif
    return true;
}

/* ---------------- config ---------------- */
static std::string CfgDir()  { return std::string(aml->GetAndroidDataPath()) + "/HEXED"; }
static std::string CfgPath() { return CfgDir() + "/hexed_resolution.cfg"; }

static void SaveCfg()
{
    aml->CreateDirRecursive(CfgDir().c_str());
    FILE* f = fopen(CfgPath().c_str(), "w");
    if (!f) { logger->Error("Cannot write %s", CfgPath().c_str()); return; }
    fprintf(f, "%d %d %d\n", (int)g_override, (int)g_wantW, (int)g_wantH);
    fclose(f);
}

static void LoadCfg()
{
    FILE* f = fopen(CfgPath().c_str(), "r");
    if (!f) return;
    int o, w, h;
    if (fscanf(f, "%d %d %d", &o, &w, &h) == 3 && (o == 0 || o == 1) &&
        w >= MIN_W && h >= MIN_H && w <= MAX_SIDE && h <= MAX_SIDE) {
        g_override = o; g_wantW = w; g_wantH = h;
        logger->Info("Loaded cfg override=%d %dx%d", o, w, h);
    }
    fclose(f);
}

/* ---------------- watcher ---------------- */
static void* Watcher(void*)
{
    for (;;) {
        usleep(250 * 1000);
        if (!g_windowSize || !g_loaded || !*g_loaded) continue;   // game not fully started
        int cw = CurW(), ch = CurH();
        if (cw <= 0 || ch <= 0) continue;
        if (!g_ready) {
            g_nativeW = cw; g_nativeH = ch; g_ready = 1;
            logger->Info("Ready. native window %dx%d, method=%s", cw, ch, g_post ? "NVEventPostEvent" : "direct store");
        }
        // Android surface callbacks (resume, hideSystemUI, rotation) post the real size again: re-assert ours.
        if (g_override && (cw != g_wantW || ch != g_wantH)) PostSize(g_wantW, g_wantH);
    }
    return nullptr;
}

/* ---------------- C API for Lua ---------------- */
#define HX_EXPORT extern "C" __attribute__((visibility("default")))

HX_EXPORT int HEXED_IsReady()     { return g_ready; }
HX_EXPORT int HEXED_GetOverride() { return g_override; }
HX_EXPORT int HEXED_GetNativeW()  { return g_nativeW; }
HX_EXPORT int HEXED_GetNativeH()  { return g_nativeH; }
HX_EXPORT int HEXED_GetCurrentW() { return CurW(); }
HX_EXPORT int HEXED_GetCurrentH() { return CurH(); }
HX_EXPORT int HEXED_GetActiveW()  { return g_renderW ? *g_renderW : 0; }   // alt render target, 0 = none
HX_EXPORT int HEXED_GetActiveH()  { return g_renderH ? *g_renderH : 0; }
HX_EXPORT int HEXED_GetMaxSide()  { return MAX_SIDE; }
HX_EXPORT int HEXED_GetMinW()     { return MIN_W; }
HX_EXPORT int HEXED_GetMinH()     { return MIN_H; }

HX_EXPORT int HEXED_SetSize(int w, int h)
{
    if (!g_ready || w < MIN_W || h < MIN_H || w > MAX_SIDE || h > MAX_SIDE) return 0;
    g_wantW = w; g_wantH = h; g_override = 1;
    if (!PostSize(w, h)) return 0;
    SaveCfg();
    logger->Info("Set %dx%d", w, h);
    return 1;
}

HX_EXPORT int HEXED_Reset()
{
    if (!g_ready) return 0;
    g_override = 0;
    PostSize(g_nativeW, g_nativeH);
    SaveCfg();
    logger->Info("Reset to native %dx%d", (int)g_nativeW, (int)g_nativeH);
    return 1;
}

/* ---------------- load ---------------- */
static bool PostFnLooksRight()
{
    // push {r4,r5,r7,lr}; add r7,sp,#8; mov r4,r0; ldr r0,[pc,#..]; add r0,pc; ldrb r0,[r0]; cmp r0,#0 ...
    static const uint8_t sig[] = { 0xb0,0xb5, 0x02,0xaf, 0x04,0x46, 0x9a,0x48, 0x78,0x44, 0x00,0x78, 0x00,0x28 };
    return memcmp((const void*)(g_lib + POST_EVENT_RVA), sig, sizeof(sig)) == 0;
}

ON_MOD_LOAD()
{
    logger->SetTag("HEXED_Resolution");
    logger->Info("HEXED Resolution 3.0.0 loading...");

    g_lib = aml->GetLib("libGTASA.so");
    if (!g_lib) { logger->Error("libGTASA.so not found"); return; }

    uintptr_t ws     = aml->GetSym(g_lib, "windowSize");
    uintptr_t loaded = aml->GetSym(g_lib, "_ZN14MobileSettings6loadedE");
    g_renderW = (volatile int32_t*)aml->GetSym(g_lib, "renderWidth");
    g_renderH = (volatile int32_t*)aml->GetSym(g_lib, "renderHeight");
    if (!ws || !loaded) { logger->Error("windowSize / MobileSettings::loaded not found"); return; }
    g_windowSize = (volatile uint32_t*)ws;
    g_loaded     = (volatile uint8_t*)loaded;

    if (PostFnLooksRight()) {
        g_post = (PostEventFn)(g_lib + POST_EVENT_RVA + 1);      // Thumb
        logger->Info("Using NVEventPostEvent (verified bytes)");
    } else {
        logger->Info("NVEventPostEvent bytes differ - using atomic windowSize store");
    }

    LoadCfg();
    pthread_t t;
    if (pthread_create(&t, nullptr, Watcher, nullptr) == 0) pthread_detach(t);
    else logger->Error("watcher thread failed");
}

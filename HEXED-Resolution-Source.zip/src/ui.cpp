/*
 * HEXED UI-thread dispatcher.
 *
 * Android only lets the UI thread resize views, and a native plugin has no Java code of its own. tools/gen_uidex.py
 * produces a 476-byte DEX holding   public class hexed.UiPost implements Runnable { public native void run(); }.
 * We load it with InMemoryDexClassLoader (API 26+), RegisterNatives its run() to Drain(), and post an instance with
 * Activity.runOnUiThread(). Fallback when that is not available: the hooks that already run on the UI thread
 * (setWindowSize, touchEvent, multiTouchEvent) call Drain() too, so a pending change is applied on the next touch.
 */
#include "state.h"
#include "uidex.h"
#include <mod/logger.h>
#include "hlog.h"

#include <atomic>

namespace hexed { namespace ui {

static std::atomic<int> g_pending{0};
static jobject   g_runnable = nullptr;    // global ref to a hexed.UiPost instance
static jmethodID m_runOnUi  = nullptr;    // Activity.runOnUiThread(Runnable)
static bool      g_tried    = false;
static jobject   g_gate     = nullptr;    // global ref to a hexed.TouchGate instance

static void ClearExc(JNIEnv* env) { if (env->ExceptionCheck()) env->ExceptionClear(); }

bool Ready() { return g_runnable != nullptr; }
jobject Gate() { return g_gate; }

void Drain(JNIEnv* env)
{
    if (g_pending.exchange(0)) surface::ApplyLayout(env);
}

static void NativeRun(JNIEnv* env, jobject) { Drain(env); }

// View.OnTouchListener.onTouch for hexed.TouchGate. Installed on the game's SurfaceView (receives picture-local events)
// and on the content root (receives only what nobody else took, i.e. touches in the black bars).
static jboolean GateOnTouch(JNIEnv* env, jobject, jobject view, jobject ev)
{
    if (!g.gateOn.load()) return JNI_FALSE;                       // gate disabled: normal Android dispatch continues
    if (!surface::IsGameView(env, view)) return JNI_TRUE;         // black bar: swallow, the game never sees it
    surface::ForwardTouch(env, ev);
    return JNI_TRUE;                                              // always consume so the whole gesture keeps coming
}

bool Init(JNIEnv* env, jobject act)
{
    if (g_runnable || g_tried || !env || !act) return g_runnable != nullptr;
    g_tried = true;
    hexed::HLog("step: ui dispatcher");

    jclass actc = env->GetObjectClass(act);
    jmethodID getCl = actc ? env->GetMethodID(actc, "getClassLoader", "()Ljava/lang/ClassLoader;") : nullptr; ClearExc(env);
    m_runOnUi = actc ? env->GetMethodID(actc, "runOnUiThread", "(Ljava/lang/Runnable;)V") : nullptr;          ClearExc(env);
    jclass imc = env->FindClass("dalvik/system/InMemoryDexClassLoader");                                       ClearExc(env);
    if (!actc || !getCl || !m_runOnUi || !imc) { hexed::HLog("ui dispatcher: unavailable (needs Android 8+)"); return false; }

    jobject parent = env->CallObjectMethod(act, getCl); ClearExc(env);
    jmethodID ictor = env->GetMethodID(imc, "<init>", "(Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V");     ClearExc(env);
    jobject buf = env->NewDirectByteBuffer((void*)kUiDex, (jlong)sizeof(kUiDex));                             ClearExc(env);
    if (!ictor || !buf || !parent) { hexed::HLog("ui dispatcher: loader arguments failed"); return false; }
    jobject loader = env->NewObject(imc, ictor, buf, parent);                                                 ClearExc(env);
    if (!loader) { hexed::HLog("ui dispatcher: InMemoryDexClassLoader failed"); return false; }

    jclass clc = env->FindClass("java/lang/ClassLoader");                                                      ClearExc(env);
    jmethodID load = clc ? env->GetMethodID(clc, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;") : nullptr; ClearExc(env);
    jstring nm = env->NewStringUTF("hexed.UiPost");
    jclass cls = load ? (jclass)env->CallObjectMethod(loader, load, nm) : nullptr;                            ClearExc(env);
    if (!cls) { hexed::HLog("ui dispatcher: class hexed.UiPost not loadable"); return false; }

    JNINativeMethod nat = { (char*)"run", (char*)"()V", (void*)NativeRun };
    if (env->RegisterNatives(cls, &nat, 1) != 0) { ClearExc(env); hexed::HLog("ui dispatcher: RegisterNatives failed"); return false; }
    jmethodID ctor = env->GetMethodID(cls, "<init>", "()V");                                                  ClearExc(env);
    jobject obj = ctor ? env->NewObject(cls, ctor) : nullptr;                                                 ClearExc(env);
    if (!obj) { hexed::HLog("ui dispatcher: instance failed"); return false; }

    // second generated class: the touch gate (optional: without it the native touch hooks do the mapping)
    jstring gnm = env->NewStringUTF("hexed.TouchGate");
    jclass gcls = (jclass)env->CallObjectMethod(loader, load, gnm);                                           ClearExc(env);
    if (gcls) {
        JNINativeMethod gn = { (char*)"onTouch", (char*)"(Landroid/view/View;Landroid/view/MotionEvent;)Z", (void*)GateOnTouch };
        jmethodID gctor = env->GetMethodID(gcls, "<init>", "()V");                                            ClearExc(env);
        if (env->RegisterNatives(gcls, &gn, 1) == 0 && gctor) {
            jobject gobj = env->NewObject(gcls, gctor);                                                       ClearExc(env);
            if (gobj) { g_gate = env->NewGlobalRef(gobj); hexed::HLog("touch gate class ready"); }
        } else ClearExc(env);
    }
    if (!g_gate) hexed::HLog("touch gate unavailable: native touch hooks will be used");
    g_runnable = env->NewGlobalRef(obj);
    hexed::HLog("ui dispatcher ready");
    return true;
}

void Post()
{
    g_pending = 1;
    if (!g_runnable) return;                       // fallback: drained by the next UI-thread hook call
    JNIEnv* env = surface::Env();
    jobject act = surface::Activity();
    if (!env || !act) return;
    env->CallVoidMethod(act, m_runOnUi, g_runnable);
    ClearExc(env);
}

}} // namespace hexed::ui

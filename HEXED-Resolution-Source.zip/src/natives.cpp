/*
 * HEXED natives module.
 *
 * libGTASA.so registers the Java natives of NvEventQueueActivity through a static
 * JNINativeMethod table {name, signature, fn}. We locate three of them by scanning that table
 * (no hard-coded addresses) and verify the first Thumb halfwords of each against the reference
 * build (Nezuko 1.0.3 TESTING) before hooking:
 *
 *   setWindowSize(II)V          posts the game's "window resized" event {6, w, h}; Java calls it
 *                               from surfaceCreated/surfaceChanged. We substitute our size.
 *   touchEvent(IIILMotionEvent)Z               raw view pixels: action, x, y
 *   multiTouchEvent(IIIIIILMotionEvent)Z       raw view pixels: action, count, x0, y0, x1, y1
 *
 * multiTouchEvent4 is a 4-byte "return true" stub in this build and is deliberately NOT hooked.
 */
#include "state.h"
#include "scan.h"
#include "calc.h"
#include <mod/amlmod.h>
#include <mod/logger.h>

#include <link.h>
#include <string.h>

namespace hexed { namespace natives {

typedef void     (*fnSet)  (JNIEnv*, jobject, jint, jint);
typedef jboolean (*fnTouch)(JNIEnv*, jobject, jint, jint, jint, jobject);
typedef jboolean (*fnMulti)(JNIEnv*, jobject, jint, jint, jint, jint, jint, jint, jobject);

static fnSet   g_rawSet   = nullptr, g_origSet   = nullptr;
static fnTouch g_rawTouch = nullptr, g_origTouch = nullptr;
static fnMulti g_rawMulti = nullptr, g_origMulti = nullptr;
static unsigned g_mask = 0;   // bit0..2 hooked (set/touch/multi), bit3..5 found in table, bit6 table scan ran

// Reference prologues (Thumb halfwords) from libGTASA.so of Nezuko 1.0.3 TESTING.
static const uint16_t PRO_SET[]   = { 0xb580, 0x466f, 0xb086, 0x2006, 0x9201, 0x9000 };
static const uint16_t PRO_TOUCH[] = { 0xb5f0, 0xaf03, 0xf84d, 0x8d04, 0xb086, 0x4606 };
static const uint16_t PRO_MULTI[] = { 0xb5f0, 0xaf03, 0xe92d, 0x0b00, 0xb086, 0x4606 };

// ---------- hooks ----------

static void Hook_setWindowSize(JNIEnv* env, jobject thiz, jint w, jint h)
{
    g.javaCalls++;
    hexed::OnJavaWindowSize(env, thiz, w, h);
    if (g.overrideOn.load() && g.activeW.load() > 0 && g.activeH.load() > 0) {
        w = g.activeW.load();
        h = g.activeH.load();
    }
    g_origSet(env, thiz, w, h);
}

static inline jint MapX(jint x)
{
    if (!g.overrideOn.load() || !g.touchRemap.load()) return x;
    return calc::MapCoord(x, g.nativeW.load(), g.activeW.load());
}
static inline jint MapY(jint y)
{
    if (!g.overrideOn.load() || !g.touchRemap.load()) return y;
    return calc::MapCoord(y, g.nativeH.load(), g.activeH.load());
}

static jboolean Hook_touchEvent(JNIEnv* env, jobject thiz, jint action, jint x, jint y, jobject ev)
{
    g.touchCalls++;
    return g_origTouch(env, thiz, action, MapX(x), MapY(y), ev);
}

static jboolean Hook_multiTouchEvent(JNIEnv* env, jobject thiz, jint action, jint count,
                                     jint x0, jint y0, jint x1, jint y1, jobject ev)
{
    g.touchCalls++;
    return g_origMulti(env, thiz, action, count, MapX(x0), MapY(y0), MapX(x1), MapY(y1), ev);
}

// ---------- setup ----------

struct PhdrCtx { uintptr_t base; scan::Seg seg[8]; int n; };

static int PhdrCb(struct dl_phdr_info* info, size_t, void* data)
{
    PhdrCtx* c = (PhdrCtx*)data;
    bool match = (info->dlpi_addr == c->base) ||
                 (info->dlpi_name && strstr(info->dlpi_name, "libGTASA.so") != nullptr);
    if (!match) return 0;
    for (int i = 0; i < info->dlpi_phnum && c->n < 8; ++i) {
        const ElfW(Phdr)& p = info->dlpi_phdr[i];
        if (p.p_type != PT_LOAD) continue;
        scan::Seg s;
        s.b = (uintptr_t)(info->dlpi_addr + p.p_vaddr);
        s.e = s.b + p.p_filesz;
        s.flags = p.p_flags;
        c->seg[c->n++] = s;
    }
    return 1;
}

template <typename F>
static bool Setup(const scan::Seg* seg, int n, const char* name, const char* sig,
                  const uint16_t* pro, int proN, unsigned bitFound, unsigned bitHook,
                  void* hook, F* raw, F* orig)
{
    uintptr_t fn = 0;
    if (!scan::FindNative(seg, n, name, sig, &fn)) {
        logger->Error("native %s%s not found in the JNI table", name, sig);
        return false;
    }
    g_mask |= bitFound;
    *raw = (F)fn;
    logger->Info("native %s -> %p (thumb=%d)", name, (void*)fn, (int)(fn & 1));
    if (!scan::Prologue(fn, pro, proN)) {
        logger->Error("%s: prologue differs from the reference build (already hooked or another build); not hooking", name);
        return true;   // still callable through the raw pointer
    }
    if (aml->Hook((void*)fn, hook, (void**)orig) && *orig) {
        g_mask |= bitHook;
        logger->Info("hooked %s", name);
    } else {
        *orig = nullptr;
        logger->Error("aml->Hook failed for %s", name);
    }
    return true;
}

bool Init(uintptr_t pGTASA)
{
    static PhdrCtx ctx;
    ctx.base = pGTASA; ctx.n = 0;
    dl_iterate_phdr(PhdrCb, &ctx);
    if (ctx.n == 0) { logger->Error("libGTASA.so segments not found"); return false; }
    g_mask |= 0x40;

    Setup<fnSet>  (ctx.seg, ctx.n, "setWindowSize",   "(II)V",
                   PRO_SET,   6, 0x08, 0x01, (void*)Hook_setWindowSize,   &g_rawSet,   &g_origSet);
    Setup<fnTouch>(ctx.seg, ctx.n, "touchEvent",      "(IIILandroid/view/MotionEvent;)Z",
                   PRO_TOUCH, 6, 0x10, 0x02, (void*)Hook_touchEvent,      &g_rawTouch, &g_origTouch);
    Setup<fnMulti>(ctx.seg, ctx.n, "multiTouchEvent", "(IIIIIILandroid/view/MotionEvent;)Z",
                   PRO_MULTI, 6, 0x20, 0x04, (void*)Hook_multiTouchEvent, &g_rawMulti, &g_origMulti);
    return (g_mask & 0x08) != 0;
}

unsigned HookMask() { return g_mask; }

bool PostWindowSize(int w, int h)
{
    fnSet f = g_origSet ? g_origSet : g_rawSet;      // never call the raw pointer once it is hooked
    JNIEnv* env = surface::Env();
    jobject act = surface::Activity();
    if (!f || !env || !act) return false;
    f(env, act, w, h);                                // env/thiz are unused by the native (verified in the bytes)
    return true;
}

}} // namespace hexed::natives

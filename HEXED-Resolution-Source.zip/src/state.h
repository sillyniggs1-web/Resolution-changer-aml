// HEXED Resolution - shared state and the small interfaces between modules.
#ifndef HEXED_STATE_H
#define HEXED_STATE_H

#include <jni.h>
#include <stdint.h>
#include <atomic>

namespace hexed {

// Read from the touch hooks (UI thread) and written from the Lua thread: atomics only.
struct Shared {
    std::atomic<int>      nativeW{0}, nativeH{0};   // current SurfaceView size = Android touch space
    std::atomic<int>      activeW{0}, activeH{0};   // size the game is told to use
    std::atomic<int>      offX{0}, offY{0};         // top-left of the SurfaceView in WINDOW coordinates (touch events use these)
    std::atomic<int>      screenW{0}, screenH{0};   // full area available to the game (parent of the SurfaceView)
    std::atomic<int>      boxW{0}, boxH{0};         // wanted SurfaceView size on screen; 0 = fill the screen
    std::atomic<int>      overrideOn{0};
    std::atomic<int>      touchRemap{1};
    std::atomic<int>      gateOn{0};                // a Java-level touch path (callback proxy or gate) maps touches: native hooks stand down
    std::atomic<int>      proxyOn{0};               // 1 = Window.Callback proxy is the touch path, 0 = fallback gate / hooks
    std::atomic<int>      contentX{0}, contentY{0}; // content root position in WINDOW coordinates (input of the centering rule)
    std::atomic<int>      liveX{0}, liveY{0};       // where Android says the SurfaceView is (diagnostic; the touch origin is computed)
    std::atomic<int>      mappedGesture{0};         // >0 while a Java path hands an ALREADY mapped event to the game: native hooks must not map again
    std::atomic<unsigned> proxyCalls{0};            // dispatchTouchEvent calls seen by the Window.Callback proxy
    std::atomic<unsigned> mappedDowns{0};           // pointer-downs mapped into the picture (any path)
    std::atomic<int>      lastRawX{0}, lastRawY{0}, lastMapX{0}, lastMapY{0};   // last pointer-down: window -> game
    std::atomic<unsigned> touchCalls{0};
    std::atomic<unsigned> javaCalls{0};
    std::atomic<unsigned> bufferCalls{0};
};
extern Shared g;

// ---- surface.cpp: Activity / Surface / ANativeWindow access over JNI ----
namespace surface {
bool        Attach(JNIEnv* env, jobject activity);   // call from a JNI callback; caches ids + global ref
bool        HaveActivity();
bool        FindActivityFallback();                  // ActivityThread reflection, for a late-loaded mod
bool        ViewSize(int* w, int* h);                // SurfaceView size in pixels (= touch space)
bool        ParentSize(int* w, int* h);              // size of the FrameLayout that holds it (= screen area)
void        RefreshGeometry(JNIEnv* env);            // UI thread: picture rectangle in window coordinates = calc::PictureRect (same rule as ApplyLayout)
bool        VerifyTouchPath(JNIEnv* env);            // UI thread: make sure our Window.Callback proxy is still the one installed
bool        ApplyLayout(JNIEnv* env);
bool        IsGameView(JNIEnv* env, jobject view);   // is `view` the game's SurfaceView?
bool        ForwardTouch(JNIEnv* env, jobject ev);   // fallback gate: hand a picture-local MotionEvent to Activity.onTouchEvent (scaled if needed)
bool        InstallCallback(JNIEnv* env);            // UI thread: wrap the Activity's Window.Callback so touches are mapped where the Activity gets them
void        RemoveCallback(JNIEnv* env);             // UI thread: put the original Window.Callback back
jobject     CallbackInvoke(JNIEnv* env, jobject proxy, jobject method, jobjectArray args);   // InvocationHandler.invoke body
bool        SetBufferSize(int w, int h);             // ANativeWindow_setBuffersGeometry; 0,0 = default
void        SetJavaSurfaceFields(int w, int h);      // keep Activity.surfaceWidth/Height consistent
JNIEnv*     Env();                                   // env for the calling thread (attaches if needed)
jobject     Activity();
const char* LastError();
}

// ---- ui.cpp: run code on Android's UI thread (a generated Runnable class, see tools/gen_uidex.py) ----
namespace ui {
bool Init(JNIEnv* env, jobject activity);   // builds the Runnable; safe to call repeatedly
void Post();                                // schedule ApplyLayout on the UI thread
void PostVerify();                          // schedule VerifyTouchPath on the UI thread
void Drain(JNIEnv* env);                    // UI thread: run it if scheduled (also called from the UI-thread hooks)
bool Ready();
jobject Gate();                             // hexed.TouchGate instance (View.OnTouchListener) or null
jobject Handler();                          // hexed.CbHandler instance (InvocationHandler for the Window.Callback proxy) or null
}

// ---- natives.cpp: the game's JNI natives (setWindowSize, touchEvent, multiTouchEvent) ----
namespace natives {
bool     Init(uintptr_t pGTASA, int stage);
bool     PostWindowSize(int w, int h);               // the game's own "window resized" event
unsigned HookMask();
}

// Implemented in main.cpp; called from the hooked setWindowSize on the Java UI thread.
void OnJavaWindowSize(JNIEnv* env, jobject thiz, int w, int h);

} // namespace hexed

#endif

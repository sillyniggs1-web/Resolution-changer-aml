// HEXED Resolution - shared state and the small interfaces between modules.
#ifndef HEXED_STATE_H
#define HEXED_STATE_H

#include <jni.h>
#include <stdint.h>
#include <atomic>

namespace hexed {

// Read from the touch hooks (UI thread) and written from the Lua thread: atomics only.
struct Shared {
    std::atomic<int>      nativeW{0}, nativeH{0};   // real view size = Android touch space
    std::atomic<int>      activeW{0}, activeH{0};   // size the game is told to use
    std::atomic<int>      overrideOn{0};
    std::atomic<int>      touchRemap{1};
    std::atomic<unsigned> touchCalls{0};
    std::atomic<unsigned> javaCalls{0};
    std::atomic<unsigned> bufferCalls{0};
};
extern Shared g;

// ---- surface.cpp: Activity / Surface / ANativeWindow access over JNI ----
namespace surface {
bool        Attach(JNIEnv* env, jobject activity);   // call from a JNI callback; caches ids + global ref
bool        HaveActivity();
bool        FindActivityFallback();                  // ActivityThread reflection, for a late-loaded mod
bool        ViewSize(int* w, int* h);                // SurfaceView size in pixels (= touch space)
bool        SetBufferSize(int w, int h);             // ANativeWindow_setBuffersGeometry; 0,0 = default
void        SetJavaSurfaceFields(int w, int h);      // keep Activity.surfaceWidth/Height consistent
JNIEnv*     Env();                                   // env for the calling thread (attaches if needed)
jobject     Activity();
const char* LastError();
}

// ---- natives.cpp: the game's JNI natives (setWindowSize, touchEvent, multiTouchEvent) ----
namespace natives {
bool     Init(uintptr_t pGTASA, int stage);
bool     PostWindowSize(int w, int h);               // the game's own "window resized" event
unsigned HookMask();
}

// Implemented in main.cpp; called from the hooked setWindowSize on the Java UI thread.
void OnJavaWindowSize(JNIEnv* env, jobject thiz, int w, int h);

} // namespace hexed

#endif

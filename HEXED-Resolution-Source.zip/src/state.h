// HEXED Resolution - shared state and the small interfaces between modules.
#ifndef HEXED_STATE_H
#define HEXED_STATE_H

#include <jni.h>
#include <stdint.h>
#include <atomic>

namespace hexed {

// Read from the touch hooks (UI thread) and written from the Lua thread: atomics only.
struct Shared {
    std::atomic<int>      nativeW{0}, nativeH{0};   // current SurfaceView size = Android touch space
    std::atomic<int>      activeW{0}, activeH{0};   // size the game is told to use
    std::atomic<int>      padL{0}, padT{0};         // box origin inside the content root (what ApplyLayout set)
    std::atomic<int>      offX{0}, offY{0};         // top-left of the SurfaceView in WINDOW coordinates (touch events use these)
    std::atomic<int>      screenW{0}, screenH{0};   // full area available to the game (parent of the SurfaceView)
    std::atomic<int>      boxW{0}, boxH{0};         // wanted SurfaceView size on screen; 0 = fill the screen
    std::atomic<int>      overrideOn{0};
    std::atomic<int>      touchRemap{1};
    std::atomic<int>      gateOn{0};                // Java touch gate installed: touches reach the game already in picture coordinates
    std::atomic<unsigned> touchCalls{0};
    std::atomic<unsigned> javaCalls{0};
    std::atomic<unsigned> bufferCalls{0};
};
extern Shared g;

// ---- surface.cpp: Activity / Surface / ANativeWindow access over JNI ----
namespace surface {
bool        Attach(JNIEnv* env, jobject activity);   // call from a JNI callback; caches ids + global ref
bool        HaveActivity();
bool        FindActivityFallback();                  // ActivityThread reflection, for a late-loaded mod
bool        ViewSize(int* w, int* h);                // SurfaceView size in pixels (= touch space)
bool        ParentSize(int* w, int* h);              // size of the FrameLayout that holds it (= screen area)
void        RefreshGeometry(JNIEnv* env);            // UI thread: update g.nativeW/H (view size) and g.offX/offY
bool        ApplyLayout(JNIEnv* env);
bool        GateTouch(JNIEnv* env, jobject ev);      // content-root touch: inside the box -> game (shifted+scaled), bars -> dropped                // UI thread only: size/center the SurfaceView per g.boxW/boxH
bool        SetBufferSize(int w, int h);             // ANativeWindow_setBuffersGeometry; 0,0 = default
void        SetJavaSurfaceFields(int w, int h);      // keep Activity.surfaceWidth/Height consistent
JNIEnv*     Env();                                   // env for the calling thread (attaches if needed)
jobject     Activity();
const char* LastError();
}

// ---- ui.cpp: run code on Android's UI thread (a generated Runnable class, see tools/gen_uidex.py) ----
namespace ui {
bool Init(JNIEnv* env, jobject activity);   // builds the Runnable; safe to call repeatedly
void Post();                                // schedule ApplyLayout on the UI thread
void Drain(JNIEnv* env);                    // UI thread: run it if scheduled (also called from the UI-thread hooks)
bool Ready();
jobject Gate();                             // hexed.TouchGate instance (View.OnTouchListener) or null
}

// ---- natives.cpp: the game's JNI natives (setWindowSize, touchEvent, multiTouchEvent) ----
namespace natives {
bool     Init(uintptr_t pGTASA, int stage);
bool     PostWindowSize(int w, int h);               // the game's own "window resized" event
unsigned HookMask();
}

// Implemented in main.cpp; called from the hooked setWindowSize on the Java UI thread.
void OnJavaWindowSize(JNIEnv* env, jobject thiz, int w, int h);

} // namespace hexed

#endif

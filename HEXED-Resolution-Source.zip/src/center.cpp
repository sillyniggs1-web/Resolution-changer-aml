/*
 * HEXED center / letterbox module, v2 ("present pass")
 *
 * Facts established from the user's screenshots (2000x1200 screen):
 *   - the game draws a W'xH' picture 1:1 into the BOTTOM-LEFT corner of the real
 *     surface, and the rest of the surface keeps stale frames;
 *   - so instead of trying to intercept every glViewport call, we post-process
 *     the finished frame right before eglSwapBuffers:
 *        copy (0,0,W',H') of the back buffer -> temp texture
 *        clear the whole surface black
 *        draw the texture into a centered rectangle T (aspect kept)
 *   Only ONE hook is needed: eglSwapBuffers.
 *
 * The hook is installed two ways, so at least one fires:
 *   1. GOT patch in libGTASA/libsamp/libNezukoSA (coexists with other mods' inline hooks)
 *   2. if no frame was seen after a few seconds: inline hook of libEGL's eglSwapBuffers
 */

#include "center.h"
#include <mod/amlmod.h>
#include <mod/logger.h>

#include <link.h>
#include <dlfcn.h>
#include <elf.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <ctype.h>

#ifndef R_ARM_GLOB_DAT
#define R_ARM_GLOB_DAT 21
#endif
#ifndef R_ARM_JUMP_SLOT
#define R_ARM_JUMP_SLOT 22
#endif
#ifndef DT_GNU_HASH
#define DT_GNU_HASH 0x6ffffef5
#endif

namespace hexed {

typedef int32_t  GLint;
typedef int32_t  GLsizei;
typedef uint32_t GLenum;
typedef uint32_t GLuint;
typedef uint32_t GLbitfield;
typedef float    GLfloat;
typedef uint8_t  GLboolean;
typedef char     GLchar;
typedef intptr_t GLsizeiptr;

enum : GLenum {
    GL_FRAMEBUFFER = 0x8D40, GL_FRAMEBUFFER_BINDING = 0x8CA6,
    GL_VIEWPORT = 0x0BA2, GL_SCISSOR_BOX = 0x0C10,
    GL_CURRENT_PROGRAM = 0x8B8D, GL_ACTIVE_TEXTURE = 0x84E0, GL_TEXTURE0 = 0x84C0,
    GL_TEXTURE_BINDING_2D = 0x8069, GL_ARRAY_BUFFER = 0x8892, GL_ARRAY_BUFFER_BINDING = 0x8894,
    GL_TEXTURE_2D = 0x0DE1, GL_RGB = 0x1907, GL_UNSIGNED_BYTE = 0x1401,
    GL_TEXTURE_MIN_FILTER = 0x2801, GL_TEXTURE_MAG_FILTER = 0x2800,
    GL_TEXTURE_WRAP_S = 0x2802, GL_TEXTURE_WRAP_T = 0x2803,
    GL_CLAMP_TO_EDGE = 0x812F, GL_LINEAR = 0x2601, GL_NEAREST = 0x2600,
    GL_VERTEX_SHADER = 0x8B31, GL_FRAGMENT_SHADER = 0x8B30,
    GL_COMPILE_STATUS = 0x8B81, GL_LINK_STATUS = 0x8B82,
    GL_STATIC_DRAW = 0x88E4, GL_FLOAT = 0x1406, GL_TRIANGLE_STRIP = 0x0005,
    GL_VA_ENABLED = 0x8622, GL_VA_SIZE = 0x8623, GL_VA_STRIDE = 0x8624, GL_VA_TYPE = 0x8625,
    GL_VA_NORMALIZED = 0x886A, GL_VA_BUFFER = 0x889F, GL_VA_POINTER = 0x8645,
    GL_BLEND = 0x0BE2, GL_DEPTH_TEST = 0x0B71, GL_CULL_FACE = 0x0B44,
    GL_STENCIL_TEST = 0x0B90, GL_SCISSOR_TEST = 0x0C11,
    GL_COLOR_CLEAR_VALUE = 0x0C22, GL_COLOR_WRITEMASK = 0x0C23,
    GL_COLOR_BUFFER_BIT = 0x4000
};
static const int32_t EGL_HEIGHT = 0x3056, EGL_WIDTH = 0x3057;

// ---------- GL function table (all resolved from libGLESv2 with dlsym) ----------
struct GLFns {
    void (*GetIntegerv)(GLenum, GLint*);
    void (*GetFloatv)(GLenum, GLfloat*);
    void (*GetBooleanv)(GLenum, GLboolean*);
    GLboolean (*IsEnabled)(GLenum);
    void (*Enable)(GLenum);
    void (*Disable)(GLenum);
    void (*Viewport)(GLint, GLint, GLsizei, GLsizei);
    void (*Scissor)(GLint, GLint, GLsizei, GLsizei);
    void (*ClearColor)(GLfloat, GLfloat, GLfloat, GLfloat);
    void (*Clear)(GLbitfield);
    void (*ColorMask)(GLboolean, GLboolean, GLboolean, GLboolean);
    void (*BindFramebuffer)(GLenum, GLuint);
    void (*ActiveTexture)(GLenum);
    void (*BindTexture)(GLenum, GLuint);
    void (*GenTextures)(GLsizei, GLuint*);
    void (*TexImage2D)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*);
    void (*TexParameteri)(GLenum, GLenum, GLint);
    void (*CopyTexSubImage2D)(GLenum, GLint, GLint, GLint, GLint, GLint, GLsizei, GLsizei);
    GLuint (*CreateShader)(GLenum);
    void (*ShaderSource)(GLuint, GLsizei, const GLchar* const*, const GLint*);
    void (*CompileShader)(GLuint);
    void (*GetShaderiv)(GLuint, GLenum, GLint*);
    GLuint (*CreateProgram)();
    void (*AttachShader)(GLuint, GLuint);
    void (*BindAttribLocation)(GLuint, GLuint, const GLchar*);
    void (*LinkProgram)(GLuint);
    void (*GetProgramiv)(GLuint, GLenum, GLint*);
    void (*UseProgram)(GLuint);
    GLint (*GetUniformLocation)(GLuint, const GLchar*);
    void (*Uniform1i)(GLint, GLint);
    void (*Uniform4f)(GLint, GLfloat, GLfloat, GLfloat, GLfloat);
    void (*GenBuffers)(GLsizei, GLuint*);
    void (*BindBuffer)(GLenum, GLuint);
    void (*BufferData)(GLenum, GLsizeiptr, const void*, GLenum);
    void (*EnableVertexAttribArray)(GLuint);
    void (*DisableVertexAttribArray)(GLuint);
    void (*VertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
    void (*GetVertexAttribiv)(GLuint, GLenum, GLint*);
    void (*GetVertexAttribPointerv)(GLuint, GLenum, void**);
    void (*DrawArrays)(GLenum, GLint, GLsizei);
    GLenum (*GetError)();
};
static GLFns gl;
static bool  g_glOk = false;

typedef unsigned (*fnSwap)(void*, void*);
typedef unsigned (*fnQuerySurface)(void*, void*, int32_t, int32_t*);
typedef void*    (*fnGetCtx)();

static fnSwap         rSwapGot    = nullptr;   // original found in a GOT slot
static fnSwap         rSwapInline = nullptr;   // trampoline from aml->Hook
static fnQuerySurface rQuerySurface = nullptr;
static fnGetCtx       rGetCtx     = nullptr;
static void*          g_eglHandle = nullptr;

// ---------- settings (Lua thread writes, render thread reads) ----------
static volatile int g_enabled   = 1;
static volatile int g_fit       = 0;     // 0 fit-to-screen, 1 pixel-perfect
static volatile int g_active    = 0;     // a resolution override is active
static volatile int g_suspended = 0;     // menu open: do not move the picture (touch stays correct)
static volatile int g_srcW = 0, g_srcH = 0;

// ---------- render-thread state ----------
static int   g_Sw = 0, g_Sh = 0;
static int   g_T[4] = {0, 0, 0, 0};
static bool  g_centeredNow = false;
static long  g_swapCalls = 0;
static int   g_hookMask = 0;                // 1 = GOT patched, 2 = inline hook installed
static int   g_lastGlErr = 0;
static int   g_logBudget = 40;
static bool  g_inSwap = false;
static time_t g_initTime = 0;

static bool    g_gpuReady = false;
static int     g_gpuFails = 0;
static void*   g_ctx = nullptr;
static GLuint  g_prog = 0, g_vbo = 0, g_tex = 0;
static GLint   g_uTex = -1, g_uScale = -1, g_uClamp = -1;
static int     g_texW = 0, g_texH = 0;

static inline int Rnd(float v) { return (int)lroundf(v); }

static void Log(const char* what)
{
    if (g_logBudget <= 0) return;
    --g_logBudget;
    logger->Info("%s | S=%dx%d src=%dx%d T=%d,%d %dx%d active=%d susp=%d en=%d",
                 what, g_Sw, g_Sh, (int)g_srcW, (int)g_srcH, g_T[0], g_T[1], g_T[2], g_T[3],
                 (int)g_active, (int)g_suspended, (int)g_enabled);
}

// ---------- GL resolve ----------
#define LOADGL(name) do { gl.name = (decltype(gl.name))dlsym(h, "gl" #name); if (!gl.name) { missing = #name; } } while (0)

static bool ResolveGL()
{
    void* h = dlopen("libGLESv2.so", RTLD_NOW);
    if (!h) h = dlopen("libGLESv3.so", RTLD_NOW);
    if (!h) { logger->Error("libGLESv2.so not available"); return false; }
    const char* missing = nullptr;
    LOADGL(GetIntegerv); LOADGL(GetFloatv); LOADGL(GetBooleanv); LOADGL(IsEnabled);
    LOADGL(Enable); LOADGL(Disable); LOADGL(Viewport); LOADGL(Scissor);
    LOADGL(ClearColor); LOADGL(Clear); LOADGL(ColorMask); LOADGL(BindFramebuffer);
    LOADGL(ActiveTexture); LOADGL(BindTexture); LOADGL(GenTextures); LOADGL(TexImage2D);
    LOADGL(TexParameteri); LOADGL(CopyTexSubImage2D); LOADGL(CreateShader); LOADGL(ShaderSource);
    LOADGL(CompileShader); LOADGL(GetShaderiv); LOADGL(CreateProgram); LOADGL(AttachShader);
    LOADGL(BindAttribLocation); LOADGL(LinkProgram); LOADGL(GetProgramiv); LOADGL(UseProgram);
    LOADGL(GetUniformLocation); LOADGL(Uniform1i); LOADGL(Uniform4f); LOADGL(GenBuffers);
    LOADGL(BindBuffer); LOADGL(BufferData); LOADGL(EnableVertexAttribArray);
    LOADGL(DisableVertexAttribArray); LOADGL(VertexAttribPointer); LOADGL(GetVertexAttribiv);
    LOADGL(GetVertexAttribPointerv); LOADGL(DrawArrays); LOADGL(GetError);
    if (missing) { logger->Error("GL function missing: gl%s", missing); return false; }
    return true;
}

static void DrainErrors() { for (int i = 0; i < 8 && gl.GetError() != 0; ++i) {} }

static GLuint Compile(GLenum type, const char* src)
{
    GLuint s = gl.CreateShader(type);
    gl.ShaderSource(s, 1, &src, nullptr);
    gl.CompileShader(s);
    GLint ok = 0;
    gl.GetShaderiv(s, GL_COMPILE_STATUS, &ok);
    return ok ? s : 0;
}

static bool InitGpu()
{
    static const char* VS =
        "attribute vec2 aPos;\n"
        "varying vec2 vUV;\n"
        "void main(){ vUV = aPos * 0.5 + 0.5; gl_Position = vec4(aPos, 0.0, 1.0); }\n";
    static const char* FS =
        "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
        "varying vec2 vUV;\n"
        "uniform sampler2D uTex;\n"
        "uniform vec4 uScale;\n"
        "uniform vec4 uClamp;\n"
        "void main(){ vec2 uv = clamp(vUV * uScale.xy, uClamp.xy, uClamp.zw);\n"
        "  gl_FragColor = vec4(texture2D(uTex, uv).rgb, 1.0); }\n";

    GLuint vs = Compile(GL_VERTEX_SHADER, VS);
    GLuint fs = Compile(GL_FRAGMENT_SHADER, FS);
    if (!vs || !fs) { logger->Error("present shader compile failed"); return false; }
    g_prog = gl.CreateProgram();
    gl.AttachShader(g_prog, vs);
    gl.AttachShader(g_prog, fs);
    gl.BindAttribLocation(g_prog, 0, "aPos");
    gl.LinkProgram(g_prog);
    GLint ok = 0;
    gl.GetProgramiv(g_prog, GL_LINK_STATUS, &ok);
    if (!ok) { logger->Error("present program link failed"); return false; }
    g_uTex   = gl.GetUniformLocation(g_prog, "uTex");
    g_uScale = gl.GetUniformLocation(g_prog, "uScale");
    g_uClamp = gl.GetUniformLocation(g_prog, "uClamp");

    static const GLfloat quad[8] = { -1.f, -1.f,  1.f, -1.f,  -1.f, 1.f,  1.f, 1.f };
    gl.GenBuffers(1, &g_vbo);
    gl.BindBuffer(GL_ARRAY_BUFFER, g_vbo);
    gl.BufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);

    gl.GenTextures(1, &g_tex);
    g_texW = g_texH = 0;
    return gl.GetError() == 0;
}

static void EnsureTexture(int w, int h)
{
    if (w == g_texW && h == g_texH) return;
    gl.BindTexture(GL_TEXTURE_2D, g_tex);
    gl.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    gl.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    gl.TexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, nullptr);
    g_texW = w; g_texH = h;
}

// ---------- geometry ----------
static void ComputeTarget(int srcW, int srcH)
{
    int tw, th;
    if (g_fit == 1) {
        tw = srcW; th = srcH;                           // 1:1, centered
    } else {
        float k  = (float)g_Sw / (float)srcW;
        float k2 = (float)g_Sh / (float)srcH;
        if (k2 < k) k = k2;                             // fit inside screen, keep aspect
        tw = Rnd((float)srcW * k);
        th = Rnd((float)srcH * k);
    }
    if (tw < 1) tw = 1;
    if (th < 1) th = 1;
    if (tw > g_Sw) tw = g_Sw;
    if (th > g_Sh) th = g_Sh;
    g_T[0] = (g_Sw - tw) / 2;
    g_T[1] = (g_Sh - th) / 2;
    g_T[2] = tw;
    g_T[3] = th;
}

// ---------- the present pass ----------
struct SavedState {
    GLint fb, vp[4], sb[4], prog, actTex, tex0, arrBuf;
    GLboolean sc, bl, dt, cf, st, cm[4];
    GLfloat cc[4];
    GLint vaEn, vaSize, vaStride, vaType, vaNorm, vaBuf;
    void* vaPtr;
};

static void SaveState(SavedState& s)
{
    gl.GetIntegerv(GL_FRAMEBUFFER_BINDING, &s.fb);
    gl.GetIntegerv(GL_VIEWPORT, s.vp);
    gl.GetIntegerv(GL_SCISSOR_BOX, s.sb);
    gl.GetIntegerv(GL_CURRENT_PROGRAM, &s.prog);
    gl.GetIntegerv(GL_ACTIVE_TEXTURE, &s.actTex);
    gl.GetIntegerv(GL_ARRAY_BUFFER_BINDING, &s.arrBuf);
    s.sc = gl.IsEnabled(GL_SCISSOR_TEST); s.bl = gl.IsEnabled(GL_BLEND);
    s.dt = gl.IsEnabled(GL_DEPTH_TEST);   s.cf = gl.IsEnabled(GL_CULL_FACE);
    s.st = gl.IsEnabled(GL_STENCIL_TEST);
    gl.GetBooleanv(GL_COLOR_WRITEMASK, s.cm);
    gl.GetFloatv(GL_COLOR_CLEAR_VALUE, s.cc);
    gl.ActiveTexture(GL_TEXTURE0);
    gl.GetIntegerv(GL_TEXTURE_BINDING_2D, &s.tex0);
    gl.GetVertexAttribiv(0, GL_VA_ENABLED, &s.vaEn);
    gl.GetVertexAttribiv(0, GL_VA_SIZE, &s.vaSize);
    gl.GetVertexAttribiv(0, GL_VA_STRIDE, &s.vaStride);
    gl.GetVertexAttribiv(0, GL_VA_TYPE, &s.vaType);
    gl.GetVertexAttribiv(0, GL_VA_NORMALIZED, &s.vaNorm);
    gl.GetVertexAttribiv(0, GL_VA_BUFFER, &s.vaBuf);
    s.vaPtr = nullptr;
    gl.GetVertexAttribPointerv(0, GL_VA_POINTER, &s.vaPtr);
}

static void RestoreState(const SavedState& s)
{
    // vertex attribute 0
    gl.BindBuffer(GL_ARRAY_BUFFER, (GLuint)s.vaBuf);
    gl.VertexAttribPointer(0, s.vaSize > 0 ? s.vaSize : 4, s.vaType ? (GLenum)s.vaType : GL_FLOAT,
                           (GLboolean)s.vaNorm, s.vaStride, s.vaPtr);
    if (s.vaEn) gl.EnableVertexAttribArray(0); else gl.DisableVertexAttribArray(0);
    gl.BindBuffer(GL_ARRAY_BUFFER, (GLuint)s.arrBuf);

    gl.ActiveTexture(GL_TEXTURE0);
    gl.BindTexture(GL_TEXTURE_2D, (GLuint)s.tex0);
    gl.ActiveTexture((GLenum)s.actTex);
    gl.UseProgram((GLuint)s.prog);

    if (s.bl) gl.Enable(GL_BLEND); else gl.Disable(GL_BLEND);
    if (s.dt) gl.Enable(GL_DEPTH_TEST); else gl.Disable(GL_DEPTH_TEST);
    if (s.cf) gl.Enable(GL_CULL_FACE); else gl.Disable(GL_CULL_FACE);
    if (s.st) gl.Enable(GL_STENCIL_TEST); else gl.Disable(GL_STENCIL_TEST);
    gl.ColorMask(s.cm[0], s.cm[1], s.cm[2], s.cm[3]);
    gl.ClearColor(s.cc[0], s.cc[1], s.cc[2], s.cc[3]);
    gl.Scissor(s.sb[0], s.sb[1], s.sb[2], s.sb[3]);
    if (s.sc) gl.Enable(GL_SCISSOR_TEST); else gl.Disable(GL_SCISSOR_TEST);
    gl.Viewport(s.vp[0], s.vp[1], s.vp[2], s.vp[3]);
    gl.BindFramebuffer(GL_FRAMEBUFFER, (GLuint)s.fb);
}

// Paint everything outside (0,0,w,h) black (used when the picture is NOT being moved,
// so stale frames never show through).
static void BlackOutside(int w, int h)
{
    if (w >= g_Sw && h >= g_Sh) return;
    SavedState s;
    SaveState(s);
    gl.ColorMask(1, 1, 1, 1);
    gl.ClearColor(0.f, 0.f, 0.f, 1.f);
    gl.Enable(GL_SCISSOR_TEST);
    if (w < g_Sw) { gl.Scissor(w, 0, g_Sw - w, g_Sh); gl.Clear(GL_COLOR_BUFFER_BIT); }
    if (h < g_Sh) { gl.Scissor(0, h, w, g_Sh - h);   gl.Clear(GL_COLOR_BUFFER_BIT); }
    RestoreState(s);
}

static bool PresentCentered(int srcW, int srcH)
{
    SavedState s;
    SaveState(s);

    gl.BindFramebuffer(GL_FRAMEBUFFER, 0);

    // 1) grab the finished picture
    gl.ActiveTexture(GL_TEXTURE0);
    EnsureTexture(g_Sw, g_Sh);
    gl.BindTexture(GL_TEXTURE_2D, g_tex);
    gl.CopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, srcW, srcH);
    GLint filt = (g_T[2] == srcW && g_T[3] == srcH) ? GL_NEAREST : GL_LINEAR;
    gl.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filt);
    gl.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filt);

    // 2) whole surface -> black
    gl.Disable(GL_SCISSOR_TEST); gl.Disable(GL_BLEND); gl.Disable(GL_DEPTH_TEST);
    gl.Disable(GL_CULL_FACE);    gl.Disable(GL_STENCIL_TEST);
    gl.ColorMask(1, 1, 1, 1);
    gl.Viewport(0, 0, g_Sw, g_Sh);
    gl.ClearColor(0.f, 0.f, 0.f, 1.f);
    gl.Clear(GL_COLOR_BUFFER_BIT);

    // 3) draw the picture into the centered rectangle
    gl.Viewport(g_T[0], g_T[1], g_T[2], g_T[3]);
    gl.UseProgram(g_prog);
    gl.Uniform1i(g_uTex, 0);
    const float tw = (float)g_texW, th = (float)g_texH;
    gl.Uniform4f(g_uScale, (float)srcW / tw, (float)srcH / th, 0.f, 0.f);
    gl.Uniform4f(g_uClamp, 0.5f / tw, 0.5f / th, ((float)srcW - 0.5f) / tw, ((float)srcH - 0.5f) / th);
    gl.BindBuffer(GL_ARRAY_BUFFER, g_vbo);
    gl.VertexAttribPointer(0, 2, GL_FLOAT, 0, 0, nullptr);
    gl.EnableVertexAttribArray(0);
    gl.DrawArrays(GL_TRIANGLE_STRIP, 0, 4);

    RestoreState(s);
    return true;
}

static unsigned CallRealSwap(void* dpy, void* surf)
{
    fnSwap f = rSwapInline ? rSwapInline : rSwapGot;
    return f ? f(dpy, surf) : 0;
}

static void DoFramePass(void* dpy, void* surf)
{
    // surface size
    if (rQuerySurface) {
        int32_t w = 0, h = 0;
        if (rQuerySurface(dpy, surf, EGL_WIDTH, &w) && rQuerySurface(dpy, surf, EGL_HEIGHT, &h) && w > 0 && h > 0) {
            if (w != g_Sw || h != g_Sh) { g_Sw = w; g_Sh = h; Log("surface size"); }
        }
    }
    if (!g_glOk || g_Sw <= 0 || g_Sh <= 0) return;

    bool wantPass = g_active && g_srcW > 0 && g_srcH > 0;
    if (!wantPass) {
        if (g_centeredNow) { g_centeredNow = false; Log("override off"); }
        return;
    }

    int srcW = g_srcW < g_Sw ? g_srcW : g_Sw;
    int srcH = g_srcH < g_Sh ? g_srcH : g_Sh;

    // new EGL context (e.g. after the app came back from background): old GL objects are gone
    void* ctx = rGetCtx ? rGetCtx() : nullptr;
    if (ctx != g_ctx) { g_ctx = ctx; g_gpuReady = false; g_gpuFails = 0; g_texW = g_texH = 0; }

    bool center = g_enabled && !g_suspended;
    if (!center) {
        BlackOutside(srcW, srcH);
        if (g_centeredNow) { g_centeredNow = false; Log(g_suspended ? "suspended (menu open)" : "centering off"); }
        return;
    }

    if (!g_gpuReady) {
        if (g_gpuFails >= 3) return;
        DrainErrors();
        g_gpuReady = InitGpu();
        if (!g_gpuReady) { ++g_gpuFails; logger->Error("present pass init failed (%d/3)", g_gpuFails); return; }
        Log("present pass ready");
    }

    ComputeTarget(srcW, srcH);
    DrainErrors();
    PresentCentered(srcW, srcH);
    GLenum e = gl.GetError();
    if (e != 0) { g_lastGlErr = (int)e; DrainErrors(); if (g_logBudget > 0) { --g_logBudget; logger->Error("GL error 0x%x in present pass", (unsigned)e); } }
    if (!g_centeredNow) { g_centeredNow = true; Log("centered"); }
}

static unsigned H_eglSwapBuffers(void* dpy, void* surf)
{
    if (g_inSwap) return CallRealSwap(dpy, surf);      // GOT path + inline path both active
    g_inSwap = true;
    ++g_swapCalls;
    DoFramePass(dpy, surf);
    unsigned r = CallRealSwap(dpy, surf);
    g_inSwap = false;
    return r;
}

// ---------- ELF scanning: GOT patch + touch symbol discovery ----------
static bool WantModule(const char* name)
{
    if (!name || !*name) return false;
    return strstr(name, "libGTASA") || strstr(name, "libsamp") || strstr(name, "libNezukoSA");
}
static inline uintptr_t FixPtr(uintptr_t p, uintptr_t base) { return p < base ? p + base : p; }

struct ScanCtx { int patched; bool logSyms; };
static int  g_touchLogBudget = 60;
static bool g_symsLogged = false;

static size_t CountSyms(uintptr_t hash, uintptr_t gnuHash)
{
    if (hash) return ((const uint32_t*)hash)[1];                       // DT_HASH: nchain
    if (!gnuHash) return 0;
    const uint32_t* g = (const uint32_t*)gnuHash;
    uint32_t nb = g[0], symoff = g[1], bloom = g[2];
    const uint32_t* buckets = g + 4 + bloom;                           // ELF32: bloom words are 32-bit
    const uint32_t* chain = buckets + nb;
    uint32_t maxIdx = 0;
    for (uint32_t i = 0; i < nb; ++i) if (buckets[i] > maxIdx) maxIdx = buckets[i];
    if (maxIdx < symoff) return symoff;
    while (!(chain[maxIdx - symoff] & 1)) ++maxIdx;
    return (size_t)maxIdx + 1;
}

static int PhdrCb(struct dl_phdr_info* info, size_t, void* data)
{
    ScanCtx* ctx = (ScanCtx*)data;
    if (!WantModule(info->dlpi_name)) return 0;

    const uintptr_t base = (uintptr_t)info->dlpi_addr;
    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; ++i)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn)*)(base + info->dlpi_phdr[i].p_vaddr); break; }
    if (!dyn) return 0;

    uintptr_t symtab = 0, strtab = 0, jmprel = 0, rel = 0, hash = 0, gnuHash = 0;
    size_t pltrelsz = 0, relsz = 0;
    for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; ++d) {
        switch (d->d_tag) {
            case DT_SYMTAB:   symtab   = FixPtr(d->d_un.d_ptr, base); break;
            case DT_STRTAB:   strtab   = FixPtr(d->d_un.d_ptr, base); break;
            case DT_JMPREL:   jmprel   = FixPtr(d->d_un.d_ptr, base); break;
            case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
            case DT_REL:      rel      = FixPtr(d->d_un.d_ptr, base); break;
            case DT_RELSZ:    relsz    = d->d_un.d_val; break;
            case DT_HASH:     hash     = FixPtr(d->d_un.d_ptr, base); break;
            case DT_GNU_HASH: gnuHash  = FixPtr(d->d_un.d_ptr, base); break;
            default: break;
        }
    }
    if (!symtab || !strtab) return 0;
    const char* lib = info->dlpi_name;

    // (a) GOT patch of eglSwapBuffers
    uintptr_t tables[2] = { jmprel, rel };
    size_t    sizes[2]  = { pltrelsz, relsz };
    for (int t = 0; t < 2; ++t) {
        if (!tables[t] || !sizes[t]) continue;
        const ElfW(Rel)* r = (const ElfW(Rel)*)tables[t];
        size_t n = sizes[t] / sizeof(ElfW(Rel));
        for (size_t i = 0; i < n; ++i) {
            unsigned type = ELF32_R_TYPE(r[i].r_info);
            if (type != R_ARM_JUMP_SLOT && type != R_ARM_GLOB_DAT) continue;
            unsigned si = ELF32_R_SYM(r[i].r_info);
            if (!si) continue;
            const char* nm = (const char*)strtab + ((const ElfW(Sym)*)symtab)[si].st_name;
            if (strcmp(nm, "eglSwapBuffers") != 0) continue;
            void** slot = (void**)FixPtr(r[i].r_offset, base);
            if (*slot == (void*)H_eglSwapBuffers) continue;
            uintptr_t page = (uintptr_t)slot & ~(uintptr_t)(getpagesize() - 1);
            if (mprotect((void*)page, getpagesize(), PROT_READ | PROT_WRITE) != 0) { logger->Error("mprotect failed in %s", lib); continue; }
            if (!rSwapGot) rSwapGot = (fnSwap)*slot;
            *slot = (void*)H_eglSwapBuffers;
            g_hookMask |= 1;
            ctx->patched++;
            logger->Info("GOT: patched eglSwapBuffers in %s", lib);
        }
    }

    // (b) one-time discovery of touch-related exports (for the touch fix, next step)
    if (ctx->logSyms && g_touchLogBudget > 0) {
        size_t n = CountSyms(hash, gnuHash);
        if (n > 0 && n < 200000) {
            const ElfW(Sym)* syms = (const ElfW(Sym)*)symtab;
            for (size_t i = 1; i < n && g_touchLogBudget > 0; ++i) {
                if (syms[i].st_shndx == 0) continue;                  // imported, not defined here
                const char* nm = (const char*)strtab + syms[i].st_name;
                if (strstr(nm, "ouch") || strstr(nm, "MotionEvent") || strstr(nm, "Touch")) {
                    --g_touchLogBudget;
                    logger->Info("TOUCHSYM %s: %s", lib, nm);
                }
            }
        }
    }
    return 0;
}

static void ScanModules(bool logSyms)
{
    ScanCtx ctx = { 0, logSyms };
    dl_iterate_phdr(PhdrCb, &ctx);
}

static void InstallInlineFallback()
{
    if (g_hookMask & 2) return;
    if (!g_eglHandle) return;
    void* addr = dlsym(g_eglHandle, "eglSwapBuffers");
    if (!addr) { logger->Error("inline fallback: eglSwapBuffers not found in libEGL"); return; }
    void* orig = nullptr;
    bool ok = aml->Hook(addr, (void*)H_eglSwapBuffers, &orig);
    if (ok && orig) { rSwapInline = (fnSwap)orig; g_hookMask |= 2; logger->Info("inline hook installed on libEGL eglSwapBuffers"); }
    else logger->Error("inline hook on eglSwapBuffers FAILED");
}

// ---------- public ----------
void CenterInit()
{
    g_initTime = time(nullptr);
    g_eglHandle = dlopen("libEGL.so", RTLD_NOW);
    if (g_eglHandle) {
        rQuerySurface = (fnQuerySurface)dlsym(g_eglHandle, "eglQuerySurface");
        rGetCtx       = (fnGetCtx)dlsym(g_eglHandle, "eglGetCurrentContext");
    }
    g_glOk = ResolveGL();
    if (!rQuerySurface) logger->Error("eglQuerySurface not found");

    ScanModules(true);
    g_symsLogged = true;
    logger->Info("Center init v2: glOk=%d hookMask=%d (1=GOT 2=inline)", g_glOk ? 1 : 0, g_hookMask);
    if (!g_hookMask) logger->Error("eglSwapBuffers not imported by game libs yet; will retry, then fall back to inline hook");
}

void CenterTick()
{
    static time_t last = 0;
    time_t now = time(nullptr);
    if (now == last) return;                                          // at most once per second
    last = now;
    if (!(g_hookMask & 1)) ScanModules(false);                       // libs that loaded late
    if (g_swapCalls == 0 && !(g_hookMask & 2) && time(nullptr) - g_initTime >= 4)
        InstallInlineFallback();                                      // no frame seen via GOT: go inline
}

void CenterSetTarget(int srcW, int srcH, bool active) { g_srcW = srcW; g_srcH = srcH; g_active = active ? 1 : 0; }
void CenterSetEnabled(bool on)   { g_enabled = on ? 1 : 0; }
void CenterSetFitMode(int mode)  { g_fit = (mode == 1) ? 1 : 0; }
void CenterSetSuspended(bool on) { g_suspended = on ? 1 : 0; }

bool CenterGetSurface(int* w, int* h)
{
    if (g_Sw <= 0 || g_Sh <= 0) return false;
    if (w) *w = g_Sw;
    if (h) *h = g_Sh;
    return true;
}

int CenterGetInfo(int idx)
{
    switch (idx) {
        case 0:  return g_Sw;
        case 1:  return g_Sh;
        case 2:  return g_T[0];
        case 3:  return g_T[1];
        case 4:  return g_T[2];
        case 5:  return g_T[3];
        case 6:  return g_srcW;
        case 7:  return g_srcH;
        case 8:  return g_hookMask;
        case 9:  return g_enabled;
        case 10: return g_fit;
        case 11: return g_centeredNow ? 1 : 0;
        case 12: return (int)g_swapCalls;
        case 13: return g_lastGlErr;
        case 14: return g_gpuReady ? 1 : 0;
        default: return 0;
    }
}

} // namespace hexed

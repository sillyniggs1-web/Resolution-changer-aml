/*
 * HEXED center / letterbox module (see center.h)
 *
 * Nothing here depends on offsets in libGTASA: hooks are installed by
 * reading each game library's own relocation table (R_ARM_JUMP_SLOT /
 * R_ARM_GLOB_DAT) and swapping the GOT slot of the GL/EGL imports.
 */

#include "center.h"
#include <mod/logger.h>

#include <link.h>
#include <dlfcn.h>
#include <elf.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#ifndef R_ARM_GLOB_DAT
#define R_ARM_GLOB_DAT 21
#endif
#ifndef R_ARM_JUMP_SLOT
#define R_ARM_JUMP_SLOT 22
#endif

namespace hexed {

// ---------- minimal GL / EGL types (no GL headers needed) ----------
typedef int32_t  GLint;
typedef int32_t  GLsizei;
typedef uint32_t GLenum;
typedef uint32_t GLuint;
typedef uint32_t GLbitfield;
typedef float    GLfloat;
typedef uint8_t  GLboolean;

static const GLenum GL_SCISSOR_TEST       = 0x0C11;
static const GLenum GL_COLOR_CLEAR_VALUE  = 0x0C22;
static const GLenum GL_COLOR_WRITEMASK    = 0x0C23;
static const GLenum GL_FRAMEBUFFER        = 0x8D40;
static const GLenum GL_DRAW_FRAMEBUFFER   = 0x8CA9;
static const GLbitfield GL_COLOR_BUFFER_BIT = 0x00004000;
static const int32_t EGL_HEIGHT = 0x3056;
static const int32_t EGL_WIDTH  = 0x3057;

typedef void     (*fnViewport)(GLint, GLint, GLsizei, GLsizei);
typedef void     (*fnCap)(GLenum);
typedef void     (*fnBindFB)(GLenum, GLuint);
typedef void     (*fnClearColor)(GLfloat, GLfloat, GLfloat, GLfloat);
typedef void     (*fnClear)(GLbitfield);
typedef void     (*fnColorMask)(GLboolean, GLboolean, GLboolean, GLboolean);
typedef void     (*fnGetFloatv)(GLenum, GLfloat*);
typedef void     (*fnGetBooleanv)(GLenum, GLboolean*);
typedef unsigned (*fnSwap)(void*, void*);
typedef unsigned (*fnQuerySurface)(void*, void*, int32_t, int32_t*);
typedef void*    (*fnGetProc)(const char*);

// ---------- real functions ----------
static fnViewport     rViewport   = nullptr;
static fnViewport     rScissor    = nullptr;
static fnCap          rEnable     = nullptr;
static fnCap          rDisable    = nullptr;
static fnBindFB       rBindFB     = nullptr;
static fnBindFB       rBindFBOES  = nullptr;
static fnSwap         rSwap       = nullptr;
static fnGetProc      rGetProc    = nullptr;
static fnClearColor   rClearColor = nullptr;
static fnClear        rClear      = nullptr;
static fnColorMask    rColorMask  = nullptr;
static fnGetFloatv    rGetFloatv  = nullptr;
static fnGetBooleanv  rGetBooleanv = nullptr;
static fnQuerySurface rQuerySurface = nullptr;

// ---------- settings (written by the Lua thread, read by the render thread) ----------
static volatile int g_enabled = 1;   // user toggle
static volatile int g_fit     = 0;   // 0 fit-to-screen, 1 pixel-perfect (no upscaling)
static volatile int g_active  = 0;   // a resolution override is active
static volatile int g_vw = 0, g_vh = 0;   // virtual (override) size

// ---------- render-thread state ----------
static int     g_fbo = 0;                         // currently bound framebuffer (0 = screen)
static GLint   g_vp[4]  = {0, 0, 0, 0};           // game's last glViewport args (raw)
static bool    g_vpSet  = false;
static GLint   g_sc[4]  = {0, 0, 0, 0};           // game's last glScissor args (raw)
static bool    g_scSet  = false;
static bool    g_scEn   = false;                  // game's scissor-test flag (raw)

static GLint   g_F[4]   = {0, 0, 0, 0};           // engine's full-frame viewport (learned)
static bool    g_Fvalid = false;
static GLint   g_frameMax[4] = {0, 0, 0, 0};
static long    g_frameMaxArea = 0;

static int     g_Sw = 0, g_Sh = 0;                // real surface size (EGL)
static GLint   g_T[4]   = {0, 0, 0, 0};           // centered target rect
static bool    g_Tvalid = false;

static int     g_hookMask = 0;                    // bit per installed hook (diagnostics)
static int     g_logBudget = 40;

enum { HK_VIEWPORT = 1, HK_SCISSOR = 2, HK_ENABLE = 4, HK_DISABLE = 8,
       HK_BIND = 16, HK_SWAP = 32, HK_GETPROC = 64 };

// ---------- geometry ----------

static inline int Rnd(float v) { return (int)lroundf(v); }

static bool ActiveOnScreen() { return g_Tvalid && g_Fvalid && g_fbo == 0; }

// map a rect from the engine's frame F into the centered target T
static void RemapRect(const GLint r[4], GLint o[4])
{
    float kx = (float)g_T[2] / (float)g_F[2];
    float ky = (float)g_T[3] / (float)g_F[3];
    o[0] = g_T[0] + Rnd((float)(r[0] - g_F[0]) * kx);
    o[1] = g_T[1] + Rnd((float)(r[1] - g_F[1]) * ky);
    o[2] = Rnd((float)r[2] * kx);
    o[3] = Rnd((float)r[3] * ky);
}

static void IntersectT(GLint b[4])
{
    int x0 = b[0] > g_T[0] ? b[0] : g_T[0];
    int y0 = b[1] > g_T[1] ? b[1] : g_T[1];
    int x1 = (b[0] + b[2]) < (g_T[0] + g_T[2]) ? (b[0] + b[2]) : (g_T[0] + g_T[2]);
    int y1 = (b[1] + b[3]) < (g_T[1] + g_T[3]) ? (b[1] + b[3]) : (g_T[1] + g_T[3]);
    b[0] = x0; b[1] = y0;
    b[2] = x1 > x0 ? x1 - x0 : 0;
    b[3] = y1 > y0 ? y1 - y0 : 0;
}

static bool SameRect(const GLint a[4], const GLint b[4])
{
    return a[0] == b[0] && a[1] == b[1] && a[2] == b[2] && a[3] == b[3];
}

// recompute T from the virtual size and the real surface
static void ComputeTarget()
{
    bool want = g_enabled && g_active && g_vw > 0 && g_vh > 0 && g_Sw > 0 && g_Sh > 0;
    if (!want) { g_Tvalid = false; return; }

    int tw, th;
    if (g_fit == 1 && g_vw <= g_Sw && g_vh <= g_Sh) {
        tw = g_vw; th = g_vh;                         // 1:1 pixels, no upscaling
    } else {
        float k = (float)g_Sw / (float)g_vw;
        float k2 = (float)g_Sh / (float)g_vh;
        if (k2 < k) k = k2;                           // fit inside the screen, keep aspect
        tw = Rnd((float)g_vw * k);
        th = Rnd((float)g_vh * k);
    }
    if (tw < 1) tw = 1;
    if (th < 1) th = 1;
    if (tw > g_Sw) tw = g_Sw;
    if (th > g_Sh) th = g_Sh;
    g_T[0] = (g_Sw - tw) / 2;
    g_T[1] = (g_Sh - th) / 2;
    g_T[2] = tw;
    g_T[3] = th;
    g_Tvalid = true;
}

// ---------- applying state to GL ----------

static void ApplyViewport()
{
    if (!rViewport) return;
    if (ActiveOnScreen()) {
        if (g_vpSet) {
            GLint o[4];
            RemapRect(g_vp, o);
            rViewport(o[0], o[1], o[2], o[3]);
        } else {
            rViewport(g_T[0], g_T[1], g_T[2], g_T[3]);
        }
    } else if (g_vpSet) {
        rViewport(g_vp[0], g_vp[1], g_vp[2], g_vp[3]);
    }
}

static void ApplyScissor()
{
    if (!rScissor || !rEnable || !rDisable) return;
    if (ActiveOnScreen()) {
        // Force the scissor on, always inside T: nothing can paint the bars.
        GLint b[4];
        if (g_scEn && g_scSet) { RemapRect(g_sc, b); IntersectT(b); }
        else                   { b[0] = g_T[0]; b[1] = g_T[1]; b[2] = g_T[2]; b[3] = g_T[3]; }
        rEnable(GL_SCISSOR_TEST);
        rScissor(b[0], b[1], b[2], b[3]);
    } else {
        if (g_scSet) rScissor(g_sc[0], g_sc[1], g_sc[2], g_sc[3]);
        if (g_scEn) rEnable(GL_SCISSOR_TEST); else rDisable(GL_SCISSOR_TEST);
    }
}

static void SyncState()
{
    ApplyViewport();
    ApplyScissor();
}

// ---------- hooks ----------

static void H_glViewport(GLint x, GLint y, GLsizei w, GLsizei h)
{
    g_vp[0] = x; g_vp[1] = y; g_vp[2] = w; g_vp[3] = h;
    g_vpSet = true;

    if (g_fbo == 0 && w > 0 && h > 0) {
        long area = (long)w * (long)h;
        if (area > g_frameMaxArea) {
            g_frameMaxArea = area;
            g_frameMax[0] = x; g_frameMax[1] = y; g_frameMax[2] = w; g_frameMax[3] = h;
        }
    }

    if (ActiveOnScreen()) {
        GLint o[4];
        RemapRect(g_vp, o);
        rViewport(o[0], o[1], o[2], o[3]);
    } else if (rViewport) {
        rViewport(x, y, w, h);
    }
}

static void H_glScissor(GLint x, GLint y, GLsizei w, GLsizei h)
{
    g_sc[0] = x; g_sc[1] = y; g_sc[2] = w; g_sc[3] = h;
    g_scSet = true;

    if (ActiveOnScreen()) ApplyScissor();
    else if (rScissor)    rScissor(x, y, w, h);
}

static void H_glEnable(GLenum cap)
{
    if (cap == GL_SCISSOR_TEST) {
        g_scEn = true;
        if (ActiveOnScreen()) { ApplyScissor(); return; }
    }
    if (rEnable) rEnable(cap);
}

static void H_glDisable(GLenum cap)
{
    if (cap == GL_SCISSOR_TEST) {
        g_scEn = false;
        if (ActiveOnScreen()) { ApplyScissor(); return; }
    }
    if (rDisable) rDisable(cap);
}

static void BindCommon(GLenum target, GLuint fb)
{
    if (target == GL_FRAMEBUFFER || target == GL_DRAW_FRAMEBUFFER) {
        int old = g_fbo;
        g_fbo = (int)fb;
        if (old != g_fbo && g_Tvalid && g_Fvalid) SyncState();
    }
}

static void H_glBindFramebuffer(GLenum target, GLuint fb)
{
    if (rBindFB) rBindFB(target, fb);
    BindCommon(target, fb);
}

static void H_glBindFramebufferOES(GLenum target, GLuint fb)
{
    if (rBindFBOES) rBindFBOES(target, fb);
    BindCommon(target, fb);
}

static void ClearBars()
{
    if (!rClear || !rClearColor || !rColorMask || !rGetFloatv || !rGetBooleanv ||
        !rScissor || !rEnable) return;
    if (g_fbo != 0) return;
    if (g_T[0] == 0 && g_T[1] == 0 && g_T[2] == g_Sw && g_T[3] == g_Sh) return;   // no bars needed

    GLfloat cc[4] = {0, 0, 0, 1};
    GLboolean cm[4] = {1, 1, 1, 1};
    rGetFloatv(GL_COLOR_CLEAR_VALUE, cc);
    rGetBooleanv(GL_COLOR_WRITEMASK, cm);

    rColorMask(1, 1, 1, 1);
    rClearColor(0.f, 0.f, 0.f, 1.f);
    rEnable(GL_SCISSOR_TEST);

    const int Tx = g_T[0], Ty = g_T[1], Tw = g_T[2], Th = g_T[3];
    struct R { int x, y, w, h; } strips[4] = {
        { 0,       0,       Tx,                   g_Sh },          // left
        { Tx + Tw, 0,       g_Sw - (Tx + Tw),     g_Sh },          // right
        { Tx,      0,       Tw,                   Ty },            // bottom
        { Tx,      Ty + Th, Tw,                   g_Sh - (Ty + Th) } // top
    };
    for (int i = 0; i < 4; ++i) {
        if (strips[i].w > 0 && strips[i].h > 0) {
            rScissor(strips[i].x, strips[i].y, strips[i].w, strips[i].h);
            rClear(GL_COLOR_BUFFER_BIT);
        }
    }

    rClearColor(cc[0], cc[1], cc[2], cc[3]);
    rColorMask(cm[0], cm[1], cm[2], cm[3]);
    ApplyScissor();
}

static void Log(const char* what)
{
    if (g_logBudget <= 0) return;
    --g_logBudget;
    logger->Info("%s | S=%dx%d F=%d,%d %dx%d T=%d,%d %dx%d valid=%d virt=%dx%d",
                 what, g_Sw, g_Sh, g_F[0], g_F[1], g_F[2], g_F[3],
                 g_T[0], g_T[1], g_T[2], g_T[3], g_Tvalid ? 1 : 0, g_vw, g_vh);
}

static unsigned H_eglSwapBuffers(void* dpy, void* surf)
{
    unsigned r = rSwap ? rSwap(dpy, surf) : 0;

    // 1) real surface size
    if (rQuerySurface) {
        int32_t w = 0, h = 0;
        if (rQuerySurface(dpy, surf, EGL_WIDTH, &w) && rQuerySurface(dpy, surf, EGL_HEIGHT, &h) &&
            w > 0 && h > 0) {
            if (w != g_Sw || h != g_Sh) { g_Sw = w; g_Sh = h; Log("surface size"); }
        }
    }

    // 2) learn the engine's full-frame viewport from the frame that just ended
    GLint oldF[4] = { g_F[0], g_F[1], g_F[2], g_F[3] };
    bool oldFvalid = g_Fvalid;
    if (g_frameMaxArea > 0) {
        g_F[0] = g_frameMax[0]; g_F[1] = g_frameMax[1];
        g_F[2] = g_frameMax[2]; g_F[3] = g_frameMax[3];
        g_Fvalid = true;
    } else if (!g_Fvalid && g_Sw > 0 && g_Sh > 0) {
        g_F[0] = 0; g_F[1] = 0; g_F[2] = g_Sw; g_F[3] = g_Sh;   // never seen a viewport: assume full surface
        g_Fvalid = true;
    }
    g_frameMaxArea = 0;

    // 3) recompute target; re-sync GL state if anything changed
    bool wasValid = g_Tvalid;
    GLint oldT[4] = { g_T[0], g_T[1], g_T[2], g_T[3] };
    ComputeTarget();
    bool changed = (wasValid != g_Tvalid) || (g_Tvalid && !SameRect(oldT, g_T)) ||
                   (oldFvalid != g_Fvalid) || !SameRect(oldF, g_F);
    if (changed) {
        SyncState();
        Log(g_Tvalid ? "centered" : "centering off");
    }

    // 4) paint the bars (new back buffer is undefined, so do it every frame)
    if (g_Tvalid && g_Fvalid) ClearBars();

    return r;
}

static void* H_eglGetProcAddress(const char* name);

// ---------- GOT patching ----------

struct HookDef { const char* name; void* hook; void** orig; int bit; };

static HookDef g_defs[] = {
    { "glViewport",           (void*)H_glViewport,           (void**)&rViewport,  HK_VIEWPORT },
    { "glScissor",            (void*)H_glScissor,            (void**)&rScissor,   HK_SCISSOR  },
    { "glEnable",             (void*)H_glEnable,             (void**)&rEnable,    HK_ENABLE   },
    { "glDisable",            (void*)H_glDisable,            (void**)&rDisable,   HK_DISABLE  },
    { "glBindFramebuffer",    (void*)H_glBindFramebuffer,    (void**)&rBindFB,    HK_BIND     },
    { "glBindFramebufferOES", (void*)H_glBindFramebufferOES, (void**)&rBindFBOES, HK_BIND     },
    { "eglSwapBuffers",       (void*)H_eglSwapBuffers,       (void**)&rSwap,      HK_SWAP     },
    { "eglGetProcAddress",    (void*)H_eglGetProcAddress,    (void**)&rGetProc,   HK_GETPROC  },
};
static const int NUM_DEFS = sizeof(g_defs) / sizeof(g_defs[0]);

static void* H_eglGetProcAddress(const char* name)
{
    void* p = rGetProc ? rGetProc(name) : nullptr;
    if (!name || !p) return p;
    for (int i = 0; i < NUM_DEFS; ++i) {
        if (g_defs[i].hook == (void*)H_eglGetProcAddress) continue;
        if (strcmp(name, g_defs[i].name) == 0) {
            if (!*g_defs[i].orig) *g_defs[i].orig = p;
            return g_defs[i].hook;
        }
    }
    return p;
}

struct PatchCtx { int patched; };

static bool WantModule(const char* name)
{
    if (!name || !*name) return false;
    // game + client libs that issue GL calls. NOT libmonetloader (the Lua/ImGui menu
    // keeps drawing on the full screen so it always stays usable).
    return strstr(name, "libGTASA") || strstr(name, "libsamp") || strstr(name, "libNezukoSA");
}

static inline uintptr_t FixPtr(uintptr_t p, uintptr_t base) { return p < base ? p + base : p; }

static void PatchSlot(uintptr_t slot, const char* sym, PatchCtx* ctx, const char* lib)
{
    for (int i = 0; i < NUM_DEFS; ++i) {
        if (strcmp(sym, g_defs[i].name) != 0) continue;
        void** pSlot = (void**)slot;
        if (*pSlot == g_defs[i].hook) return;                       // already patched
        uintptr_t page = slot & ~(uintptr_t)(getpagesize() - 1);
        if (mprotect((void*)page, getpagesize(), PROT_READ | PROT_WRITE) != 0) {
            logger->Error("mprotect failed for %s in %s", sym, lib);
            return;
        }
        if (!*g_defs[i].orig) *g_defs[i].orig = *pSlot;               // keep the original
        *pSlot = g_defs[i].hook;
        g_hookMask |= g_defs[i].bit;
        ctx->patched++;
        logger->Info("patched %s in %s", sym, lib);
        return;
    }
}

static int PhdrCb(struct dl_phdr_info* info, size_t, void* data)
{
    PatchCtx* ctx = (PatchCtx*)data;
    if (!WantModule(info->dlpi_name)) return 0;

    const uintptr_t base = (uintptr_t)info->dlpi_addr;
    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; ++i) {
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) {
            dyn = (const ElfW(Dyn)*)(base + info->dlpi_phdr[i].p_vaddr);
            break;
        }
    }
    if (!dyn) return 0;

    uintptr_t symtab = 0, strtab = 0, jmprel = 0, rel = 0;
    size_t pltrelsz = 0, relsz = 0;
    for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; ++d) {
        switch (d->d_tag) {
            case DT_SYMTAB:   symtab   = FixPtr(d->d_un.d_ptr, base); break;
            case DT_STRTAB:   strtab   = FixPtr(d->d_un.d_ptr, base); break;
            case DT_JMPREL:   jmprel   = FixPtr(d->d_un.d_ptr, base); break;
            case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
            case DT_REL:      rel      = FixPtr(d->d_un.d_ptr, base); break;
            case DT_RELSZ:    relsz    = d->d_un.d_val; break;
            default: break;
        }
    }
    if (!symtab || !strtab) return 0;

    const char* lib = info->dlpi_name;
    uintptr_t tables[2]  = { jmprel, rel };
    size_t    sizes[2]   = { pltrelsz, relsz };
    for (int t = 0; t < 2; ++t) {
        if (!tables[t] || !sizes[t]) continue;
        const ElfW(Rel)* r = (const ElfW(Rel)*)tables[t];
        size_t n = sizes[t] / sizeof(ElfW(Rel));
        for (size_t i = 0; i < n; ++i) {
            unsigned type = ELF32_R_TYPE(r[i].r_info);
            if (type != R_ARM_JUMP_SLOT && type != R_ARM_GLOB_DAT) continue;
            unsigned symIdx = ELF32_R_SYM(r[i].r_info);
            if (!symIdx) continue;
            const ElfW(Sym)* s = ((const ElfW(Sym)*)symtab) + symIdx;
            const char* nm = (const char*)strtab + s->st_name;
            uintptr_t slot = FixPtr(r[i].r_offset, base);
            PatchSlot(slot, nm, ctx, lib);
        }
    }
    return 0;
}

static void PatchAll()
{
    PatchCtx ctx = { 0 };
    dl_iterate_phdr(PhdrCb, &ctx);
    if (ctx.patched > 0) logger->Info("GOT patch pass: %d slot(s), hookMask=0x%x", ctx.patched, g_hookMask);
}

// ---------- public ----------

void CenterInit()
{
    // Patch first: this records the game's own GL/EGL function pointers as the "real" ones,
    // which keeps any hook chain other mods built on top intact.
    PatchAll();

    void* gl = dlopen("libGLESv2.so", RTLD_NOW);
    if (!gl) gl = dlopen("libGLESv3.so", RTLD_NOW);
    void* egl = dlopen("libEGL.so", RTLD_NOW);

    if (gl) {
        rClearColor  = (fnClearColor)dlsym(gl, "glClearColor");
        rClear       = (fnClear)dlsym(gl, "glClear");
        rColorMask   = (fnColorMask)dlsym(gl, "glColorMask");
        rGetFloatv   = (fnGetFloatv)dlsym(gl, "glGetFloatv");
        rGetBooleanv = (fnGetBooleanv)dlsym(gl, "glGetBooleanv");
        // fill gaps for entry points the game libs did not import
        if (!rViewport)  rViewport  = (fnViewport)dlsym(gl, "glViewport");
        if (!rScissor)   rScissor   = (fnViewport)dlsym(gl, "glScissor");
        if (!rEnable)    rEnable    = (fnCap)dlsym(gl, "glEnable");
        if (!rDisable)   rDisable   = (fnCap)dlsym(gl, "glDisable");
        if (!rBindFB)    rBindFB    = (fnBindFB)dlsym(gl, "glBindFramebuffer");
    } else {
        logger->Error("libGLESv2.so not available - centering disabled");
    }
    if (egl) {
        rQuerySurface = (fnQuerySurface)dlsym(egl, "eglQuerySurface");
        if (!rSwap)    rSwap    = (fnSwap)dlsym(egl, "eglSwapBuffers");
        if (!rGetProc) rGetProc = (fnGetProc)dlsym(egl, "eglGetProcAddress");
    } else {
        logger->Error("libEGL.so not available - centering disabled");
    }

    logger->Info("Center init: hookMask=0x%x (1 viewport,2 scissor,4 enable,8 disable,16 bind,32 swap,64 getproc)", g_hookMask);
    if (!(g_hookMask & HK_SWAP))     logger->Error("eglSwapBuffers is not imported by the game libs: no per-frame hook yet");
    if (!(g_hookMask & HK_VIEWPORT)) logger->Error("glViewport is not imported by the game libs: viewport cannot be centered yet");
}

void CenterRescan()
{
    int before = g_hookMask;
    PatchAll();
    if (g_hookMask != before) logger->Info("Center rescan: hookMask=0x%x", g_hookMask);
}

void CenterSetTarget(int virtW, int virtH, bool active)
{
    g_vw = virtW; g_vh = virtH; g_active = active ? 1 : 0;
    // takes effect at the next eglSwapBuffers (render thread)
}

void CenterSetEnabled(bool on) { g_enabled = on ? 1 : 0; }
void CenterSetFitMode(int mode) { g_fit = (mode == 1) ? 1 : 0; }

int CenterGetInfo(int idx)
{
    switch (idx) {
        case 0:  return g_Sw;
        case 1:  return g_Sh;
        case 2:  return g_T[0];
        case 3:  return g_T[1];
        case 4:  return g_T[2];
        case 5:  return g_T[3];
        case 6:  return g_F[2];
        case 7:  return g_F[3];
        case 8:  return g_hookMask;
        case 9:  return g_enabled;
        case 10: return g_fit;
        case 11: return g_Tvalid ? 1 : 0;
        default: return 0;
    }
}

} // namespace hexed

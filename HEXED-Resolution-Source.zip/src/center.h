#ifndef HEXED_CENTER_H
#define HEXED_CENTER_H

/*
 * HEXED center / letterbox module (v2, "present pass").
 *
 * The game draws a W'xH' picture into the bottom-left corner of the real surface.
 * Right before eglSwapBuffers we copy that picture, clear the surface to black and
 * draw the picture again into a centered rectangle, so the screen shows the picked
 * resolution with black bars around it. See center.cpp.
 */

namespace hexed {

void CenterInit();
void CenterTick();                                   // call regularly (rate-limited inside)
void CenterSetTarget(int srcW, int srcH, bool active);   // size the game renders at
void CenterSetEnabled(bool on);
void CenterSetFitMode(int mode);                     // 0 = fit to screen, 1 = 1:1 pixels
void CenterSetSuspended(bool on);                    // true while the menu is open
bool CenterGetSurface(int* w, int* h);               // real EGL surface size (false until 1st frame)
int  CenterGetInfo(int idx);                         // see center.cpp

}

#endif

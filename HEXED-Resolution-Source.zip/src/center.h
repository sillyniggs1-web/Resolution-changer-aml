#ifndef HEXED_CENTER_H
#define HEXED_CENTER_H

/*
 * HEXED center / letterbox module.
 *
 * Keeps the game picture centered on the real display surface and paints
 * black bars around it, so the screen shows exactly the aspect ratio of the
 * resolution that was applied.
 *
 * How: it patches the GOT (import table) of the game libraries so every
 * glViewport / glScissor / glEnable / glDisable / glBindFramebuffer /
 * eglSwapBuffers call goes through us. While active, rendering to the
 * default framebuffer is remapped into a centered rectangle T, and the area
 * outside T is cleared to black once per frame.
 */

namespace hexed {

void CenterInit();                                   // resolve GL/EGL + patch GOTs
void CenterRescan();                                 // patch libs that loaded late
void CenterSetTarget(int virtW, int virtH, bool active);
void CenterSetEnabled(bool on);
void CenterSetFitMode(int mode);                     // 0 = fit to screen, 1 = 1:1 pixels
int  CenterGetInfo(int idx);                         // see indices in center.cpp

}

#endif

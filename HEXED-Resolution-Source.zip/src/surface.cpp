/*
 * HEXED surface module.
 *
 * Why this exists: the Nezuko/GTA:SA client creates its EGL window surface in Java
 * (NvEventQueueActivity.createEGLSurface). Changing the game's logical size alone leaves the
 * real surface at the screen size, so the picture only fills a corner and the rest shows stale
 * GPU memory. Here we change the size of the *buffers* of that surface instead
 * (ANativeWindow_setBuffersGeometry): the compositor then scales the smaller picture to the
 * whole screen, so the surface itself is the picture.
 *
 * Verified in the APK (classes.dex): NvEventQueueActivity has the fields
 *   SurfaceView view, SurfaceHolder cachedSurfaceHolder, SurfaceHolder holder, int surfaceWidth/Height.
 */
#include "state.h"
#include <mod/logger.h>
#include "hlog.h"

#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <dlfcn.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

namespace hexed { namespace surface {

static JavaVM*   g_vm         = nullptr;
static jobject   g_act        = nullptr;   // global ref: the NvEventQueueActivity instance
static jfieldID  f_cached     = nullptr;
static jfieldID  f_holder     = nullptr;
static jfieldID  f_view       = nullptr;
static jfieldID  f_surfW      = nullptr;
static jfieldID  f_surfH      = nullptr;
static jmethodID m_getHolder  = nullptr;   // SurfaceView.getHolder()
static jmethodID m_getSurface = nullptr;   // SurfaceHolder.getSurface()
static jmethodID m_getW       = nullptr;   // View.getWidth()
static jmethodID m_getH       = nullptr;   // View.getHeight()
static char      g_err[160]   = "";
static pthread_mutex_t g_mu   = PTHREAD_MUTEX_INITIALIZER;

static void Err(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    hexed::HLog("%s", g_err);
}

static void ClearExc(JNIEnv* env) { if (env->ExceptionCheck()) env->ExceptionClear(); }

const char* LastError()   { return g_err; }
bool        HaveActivity(){ return g_act != nullptr; }
jobject     Activity()    { return g_act; }

typedef jint (*GetVMs_t)(JavaVM**, jsize, jsize*);

static bool AcquireVm()
{
    if (g_vm) return true;
    GetVMs_t fn = (GetVMs_t)dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs");
    if (!fn) {
        void* art = dlopen("libart.so", RTLD_NOW | RTLD_NOLOAD);
        if (art) fn = (GetVMs_t)dlsym(art, "JNI_GetCreatedJavaVMs");
    }
    if (!fn) return false;
    JavaVM* vm = nullptr; jsize n = 0;
    if (fn(&vm, 1, &n) != 0 || n < 1 || !vm) return false;
    g_vm = vm;
    return true;
}

JNIEnv* Env()
{
    if (!g_vm) return nullptr;
    JNIEnv* e = nullptr;
    jint r = g_vm->GetEnv((void**)&e, JNI_VERSION_1_6);
    if (r == JNI_OK) return e;
    if (r == JNI_EDETACHED && g_vm->AttachCurrentThread(&e, nullptr) == JNI_OK) return e;
    return nullptr;
}

static void ResolveIds(JNIEnv* env, jobject act)
{
    jclass ac = env->GetObjectClass(act);
    if (ac) {
        f_cached = env->GetFieldID(ac, "cachedSurfaceHolder", "Landroid/view/SurfaceHolder;"); ClearExc(env);
        f_holder = env->GetFieldID(ac, "holder",              "Landroid/view/SurfaceHolder;"); ClearExc(env);
        f_view   = env->GetFieldID(ac, "view",                "Landroid/view/SurfaceView;");   ClearExc(env);
        f_surfW  = env->GetFieldID(ac, "surfaceWidth",  "I"); ClearExc(env);
        f_surfH  = env->GetFieldID(ac, "surfaceHeight", "I"); ClearExc(env);
        env->DeleteLocalRef(ac);
    }
    jclass sv = env->FindClass("android/view/SurfaceView");
    if (sv) { m_getHolder = env->GetMethodID(sv, "getHolder", "()Landroid/view/SurfaceHolder;"); ClearExc(env); env->DeleteLocalRef(sv); }
    ClearExc(env);
    jclass vw = env->FindClass("android/view/View");
    if (vw) {
        m_getW = env->GetMethodID(vw, "getWidth",  "()I"); ClearExc(env);
        m_getH = env->GetMethodID(vw, "getHeight", "()I"); ClearExc(env);
        env->DeleteLocalRef(vw);
    }
    ClearExc(env);
    jclass sh = env->FindClass("android/view/SurfaceHolder");
    if (sh) { m_getSurface = env->GetMethodID(sh, "getSurface", "()Landroid/view/Surface;"); ClearExc(env); env->DeleteLocalRef(sh); }
    ClearExc(env);
    hexed::HLog("surface ids: cached=%d holder=%d view=%d surfW=%d getHolder=%d getSurface=%d getW=%d",
                 f_cached != 0, f_holder != 0, f_view != 0, f_surfW != 0,
                 m_getHolder != 0, m_getSurface != 0, m_getW != 0);
}

bool Attach(JNIEnv* env, jobject act)
{
    if (!env || !act) return false;
    pthread_mutex_lock(&g_mu);
    if (!g_vm) env->GetJavaVM(&g_vm);
    if (!g_act || !env->IsSameObject(g_act, act)) {
        if (g_act) env->DeleteGlobalRef(g_act);
        g_act = env->NewGlobalRef(act);
        hexed::HLog("Activity captured");
    }
    if (!f_cached && !f_holder && !f_view) ResolveIds(env, act);
    pthread_mutex_unlock(&g_mu);
    return g_act != nullptr;
}

// Surface of the game's SurfaceView (local ref, caller deletes), or null.
static jobject GetSurfaceObj(JNIEnv* env)
{
    jobject holder = nullptr;
    if (f_cached) holder = env->GetObjectField(g_act, f_cached);
    if (!holder && f_holder) holder = env->GetObjectField(g_act, f_holder);
    if (!holder && f_view && m_getHolder) {
        jobject v = env->GetObjectField(g_act, f_view);
        if (v) { holder = env->CallObjectMethod(v, m_getHolder); env->DeleteLocalRef(v); }
    }
    ClearExc(env);
    if (!holder || !m_getSurface) return nullptr;
    jobject surf = env->CallObjectMethod(holder, m_getSurface);
    ClearExc(env);
    env->DeleteLocalRef(holder);
    return surf;
}

bool ViewSize(int* w, int* h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_view || !m_getW || !m_getH) return false;
    jobject v = env->GetObjectField(g_act, f_view);
    ClearExc(env);
    if (!v) return false;
    jint vw = env->CallIntMethod(v, m_getW);
    jint vh = env->CallIntMethod(v, m_getH);
    ClearExc(env);
    env->DeleteLocalRef(v);
    if (vw <= 0 || vh <= 0) return false;
    *w = vw; *h = vh;
    return true;
}

bool SetBufferSize(int w, int h)
{
    JNIEnv* env = Env();
    if (!env || !g_act) { Err("no activity yet"); return false; }
    jobject surf = GetSurfaceObj(env);
    if (!surf) { Err("game surface not available"); return false; }
    ANativeWindow* win = ANativeWindow_fromSurface(env, surf);
    env->DeleteLocalRef(surf);
    if (!win) { Err("ANativeWindow_fromSurface failed"); return false; }
    // Buffer size only: the compositor scales it to the window. 0,0 restores the window size.
    int r = ANativeWindow_setBuffersGeometry(win, w, h, 0);
    ANativeWindow_release(win);
    g.bufferCalls++;
    if (r != 0) { Err("setBuffersGeometry(%d,%d) failed: %d", w, h, r); return false; }
    hexed::HLog("buffers geometry -> %dx%d", w, h);
    return true;
}

void SetJavaSurfaceFields(int w, int h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_surfW || !f_surfH) return;
    env->SetIntField(g_act, f_surfW, w);
    env->SetIntField(g_act, f_surfH, h);
    ClearExc(env);
}

bool FindActivityFallback()
{
    if (!AcquireVm()) { Err("JavaVM not found"); return false; }
    JNIEnv* env = Env();
    if (!env) { Err("no JNIEnv"); return false; }

    jclass at = env->FindClass("android/app/ActivityThread"); ClearExc(env);
    if (!at) return false;
    jmethodID cur = env->GetStaticMethodID(at, "currentActivityThread", "()Landroid/app/ActivityThread;"); ClearExc(env);
    jfieldID  fa  = env->GetFieldID(at, "mActivities", "Landroid/util/ArrayMap;");                          ClearExc(env);
    jclass mc = env->FindClass("android/util/ArrayMap");                                                    ClearExc(env);
    jclass rc = env->FindClass("android/app/ActivityThread$ActivityClientRecord");                          ClearExc(env);
    if (!cur || !fa || !mc || !rc) { Err("ActivityThread reflection unavailable"); return false; }
    jmethodID msize = env->GetMethodID(mc, "size", "()I");                              ClearExc(env);
    jmethodID mval  = env->GetMethodID(mc, "valueAt", "(I)Ljava/lang/Object;");         ClearExc(env);
    jfieldID  fact  = env->GetFieldID(rc, "activity", "Landroid/app/Activity;");        ClearExc(env);
    if (!msize || !mval || !fact) { Err("ActivityClientRecord layout unknown"); return false; }

    jobject thread = env->CallStaticObjectMethod(at, cur); ClearExc(env);
    jobject map = thread ? env->GetObjectField(thread, fa) : nullptr; ClearExc(env);
    bool found = false;
    if (map) {
        jint n = env->CallIntMethod(map, msize); ClearExc(env);
        for (jint i = 0; i < n && !found; ++i) {
            jobject rec = env->CallObjectMethod(map, mval, i); ClearExc(env);
            jobject act = rec ? env->GetObjectField(rec, fact) : nullptr; ClearExc(env);
            if (act) {
                jclass ac = env->GetObjectClass(act);
                jfieldID probe = ac ? env->GetFieldID(ac, "cachedSurfaceHolder", "Landroid/view/SurfaceHolder;") : nullptr;
                ClearExc(env);
                if (probe) found = Attach(env, act);
                if (ac) env->DeleteLocalRef(ac);
                env->DeleteLocalRef(act);
            }
            if (rec) env->DeleteLocalRef(rec);
        }
        env->DeleteLocalRef(map);
    }
    if (thread) env->DeleteLocalRef(thread);
    if (!found) Err("game activity not found");
    return found;
}

}} // namespace hexed::surface

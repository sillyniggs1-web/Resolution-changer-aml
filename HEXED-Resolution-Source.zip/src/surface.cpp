/*
 * HEXED surface module.
 *
 * Why this exists: the Nezuko/GTA:SA client creates its EGL window surface in Java
 * (NvEventQueueActivity.createEGLSurface). Changing the game's logical size alone leaves the
 * real surface at the screen size, so the picture only fills a corner and the rest shows stale
 * GPU memory. Here we change the size of the *buffers* of that surface instead
 * (ANativeWindow_setBuffersGeometry): the compositor then scales the smaller picture to the
 * whole screen, so the surface itself is the picture.
 *
 * Verified in the APK (classes.dex): NvEventQueueActivity has the fields
 *   SurfaceView view, SurfaceHolder cachedSurfaceHolder, SurfaceHolder holder, int surfaceWidth/Height.
 */
#include "state.h"
#include "calc.h"
#include <mod/logger.h>
#include "hlog.h"

#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <atomic>
#include <dlfcn.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

namespace hexed { namespace surface {

static JavaVM*   g_vm         = nullptr;
static jobject   g_act        = nullptr;   // global ref: the NvEventQueueActivity instance
static jfieldID  f_cached     = nullptr;
static jfieldID  f_holder     = nullptr;
static jfieldID  f_view       = nullptr;
static jfieldID  f_surfW      = nullptr;
static jfieldID  f_surfH      = nullptr;
static jmethodID m_getHolder  = nullptr;   // SurfaceView.getHolder()
static jmethodID m_getSurface = nullptr;   // SurfaceHolder.getSurface()
static jmethodID m_getW       = nullptr;   // View.getWidth()
static jmethodID m_getH       = nullptr;   // View.getHeight()
static jmethodID m_getLP      = nullptr;   // View.getLayoutParams()
static jmethodID m_setLP      = nullptr;   // View.setLayoutParams()
static jmethodID m_getParent  = nullptr;   // View.getParent()
static jmethodID m_setBgColor = nullptr;   // View.setBackgroundColor(int)
static jmethodID m_setPadding = nullptr;   // View.setPadding(int,int,int,int)
static jmethodID m_getLocWin  = nullptr;   // View.getLocationInWindow(int[])
static jmethodID m_setOTL     = nullptr;   // View.setOnTouchListener(OnTouchListener)
static jmethodID m_actTouch   = nullptr;   // Activity.onTouchEvent(MotionEvent)
static jmethodID m_setFixed   = nullptr;   // SurfaceHolder.setFixedSize(int,int)
static jmethodID m_setFromLay = nullptr;   // SurfaceHolder.setSizeFromLayout()
static char      g_err[160]   = "";
static pthread_mutex_t g_mu   = PTHREAD_MUTEX_INITIALIZER;

static void Err(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    hexed::HLog("%s", g_err);
}

static void ClearExc(JNIEnv* env) { if (env->ExceptionCheck()) env->ExceptionClear(); }

static jobject g_proxy = nullptr;            // global ref: java.lang.reflect.Proxy implementing Window.Callback (ours)
static jobject g_origCb = nullptr;           // global ref: the Window.Callback that was installed before us (the Activity itself)
static bool    g_dispatchOverridden = false; // the game's Activity class overrides dispatchTouchEvent itself
// One shared handler object serves every proxy we create. A proxy we replaced can still be reachable (a foreign wrapper may point at it),
// so each proxy keeps its OWN original callback here; forwarding an old proxy to the current original would loop forever.
struct PxPair { jobject proxy; jobject orig; };
static PxPair g_old[4] = { {nullptr, nullptr}, {nullptr, nullptr}, {nullptr, nullptr}, {nullptr, nullptr} };

static void DropPair(JNIEnv* env, jobject* p, jobject* o)
{
    if (*p) { env->DeleteGlobalRef(*p); *p = nullptr; }
    if (*o) { env->DeleteGlobalRef(*o); *o = nullptr; }
}
static void DropCallbackRefs(JNIEnv* env)            // everything: the Window the proxies belonged to is gone
{
    DropPair(env, &g_proxy, &g_origCb);
    for (auto& p : g_old) DropPair(env, &p.proxy, &p.orig);
    g.proxyOn = 0;
}
static void RetireCurrentProxy(JNIEnv* env)          // keep it (with its original) so a stale reference to it still forwards correctly
{
    if (!g_proxy) { g.proxyOn = 0; return; }
    for (auto& p : g_old) if (!p.proxy) { p.proxy = g_proxy; p.orig = g_origCb; g_proxy = nullptr; g_origCb = nullptr; g.proxyOn = 0; return; }
    DropPair(env, &g_old[0].proxy, &g_old[0].orig);  // table full: the oldest goes
    g_old[0].proxy = g_proxy; g_old[0].orig = g_origCb; g_proxy = nullptr; g_origCb = nullptr; g.proxyOn = 0;
}

const char* LastError()   { return g_err; }
bool        HaveActivity(){ return g_act != nullptr; }
jobject     Activity()    { return g_act; }

typedef jint (*GetVMs_t)(JavaVM**, jsize, jsize*);

static bool AcquireVm()
{
    if (g_vm) return true;
    GetVMs_t fn = (GetVMs_t)dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs");
    if (!fn) {
        void* art = dlopen("libart.so", RTLD_NOW | RTLD_NOLOAD);
        if (art) fn = (GetVMs_t)dlsym(art, "JNI_GetCreatedJavaVMs");
    }
    if (!fn) return false;
    JavaVM* vm = nullptr; jsize n = 0;
    if (fn(&vm, 1, &n) != 0 || n < 1 || !vm) return false;
    g_vm = vm;
    return true;
}

JNIEnv* Env()
{
    if (!g_vm) return nullptr;
    JNIEnv* e = nullptr;
    jint r = g_vm->GetEnv((void**)&e, JNI_VERSION_1_6);
    if (r == JNI_OK) return e;
    if (r == JNI_EDETACHED && g_vm->AttachCurrentThread(&e, nullptr) == JNI_OK) return e;
    return nullptr;
}

static void ResolveIds(JNIEnv* env, jobject act)
{
    jclass ac = env->GetObjectClass(act);
    if (ac) {
        f_cached = env->GetFieldID(ac, "cachedSurfaceHolder", "Landroid/view/SurfaceHolder;"); ClearExc(env);
        f_holder = env->GetFieldID(ac, "holder",              "Landroid/view/SurfaceHolder;"); ClearExc(env);
        f_view   = env->GetFieldID(ac, "view",                "Landroid/view/SurfaceView;");   ClearExc(env);
        f_surfW  = env->GetFieldID(ac, "surfaceWidth",  "I"); ClearExc(env);
        f_surfH  = env->GetFieldID(ac, "surfaceHeight", "I"); ClearExc(env);
        env->DeleteLocalRef(ac);
    }
    jclass sv = env->FindClass("android/view/SurfaceView");
    if (sv) { m_getHolder = env->GetMethodID(sv, "getHolder", "()Landroid/view/SurfaceHolder;"); ClearExc(env); env->DeleteLocalRef(sv); }
    ClearExc(env);
    jclass vw = env->FindClass("android/view/View");
    if (vw) {
        m_getW = env->GetMethodID(vw, "getWidth",  "()I"); ClearExc(env);
        m_getH = env->GetMethodID(vw, "getHeight", "()I"); ClearExc(env);
        m_getLP      = env->GetMethodID(vw, "getLayoutParams", "()Landroid/view/ViewGroup$LayoutParams;"); ClearExc(env);
        m_setLP      = env->GetMethodID(vw, "setLayoutParams", "(Landroid/view/ViewGroup$LayoutParams;)V"); ClearExc(env);
        m_getParent  = env->GetMethodID(vw, "getParent", "()Landroid/view/ViewParent;");                    ClearExc(env);
        m_setBgColor = env->GetMethodID(vw, "setBackgroundColor", "(I)V");                                  ClearExc(env);
        m_setPadding = env->GetMethodID(vw, "setPadding", "(IIII)V");                                       ClearExc(env);
        m_getLocWin  = env->GetMethodID(vw, "getLocationInWindow", "([I)V");                                ClearExc(env);
        m_setOTL     = env->GetMethodID(vw, "setOnTouchListener", "(Landroid/view/View$OnTouchListener;)V");   ClearExc(env);
        env->DeleteLocalRef(vw);
    }
    ClearExc(env);
    jclass actc = env->FindClass("android/app/Activity");
    if (actc) { m_actTouch = env->GetMethodID(actc, "onTouchEvent", "(Landroid/view/MotionEvent;)Z"); ClearExc(env); env->DeleteLocalRef(actc); }
    ClearExc(env);
    jclass sh = env->FindClass("android/view/SurfaceHolder");
    if (sh) {
        m_getSurface = env->GetMethodID(sh, "getSurface", "()Landroid/view/Surface;"); ClearExc(env);
        m_setFixed   = env->GetMethodID(sh, "setFixedSize", "(II)V");                  ClearExc(env);
        m_setFromLay = env->GetMethodID(sh, "setSizeFromLayout", "()V");               ClearExc(env);
        env->DeleteLocalRef(sh);
    }
    ClearExc(env);
    hexed::HLog("layout ids: getLP=%d setLP=%d getParent=%d setBg=%d", m_getLP != 0, m_setLP != 0, m_getParent != 0, m_setBgColor != 0);
    hexed::HLog("surface ids: cached=%d holder=%d view=%d surfW=%d getHolder=%d getSurface=%d getW=%d",
                 f_cached != 0, f_holder != 0, f_view != 0, f_surfW != 0,
                 m_getHolder != 0, m_getSurface != 0, m_getW != 0);
}

bool Attach(JNIEnv* env, jobject act)
{
    if (!env || !act) return false;
    pthread_mutex_lock(&g_mu);
    if (!g_vm) env->GetJavaVM(&g_vm);
    if (!g_act || !env->IsSameObject(g_act, act)) {
        if (g_act) env->DeleteGlobalRef(g_act);
        g_act = env->NewGlobalRef(act);
        DropCallbackRefs(env);                 // the proxy belonged to the previous Activity's Window
        hexed::HLog("Activity captured");
    }
    if (!f_cached && !f_holder && !f_view) ResolveIds(env, act);
    pthread_mutex_unlock(&g_mu);
    ui::Init(env, act);                       // outside the lock: it calls back into this module
    return g_act != nullptr;
}

// Surface of the game's SurfaceView (local ref, caller deletes), or null.
static jobject GetSurfaceObj(JNIEnv* env)
{
    jobject holder = nullptr;
    if (f_cached) holder = env->GetObjectField(g_act, f_cached);
    if (!holder && f_holder) holder = env->GetObjectField(g_act, f_holder);
    if (!holder && f_view && m_getHolder) {
        jobject v = env->GetObjectField(g_act, f_view);
        if (v) { holder = env->CallObjectMethod(v, m_getHolder); env->DeleteLocalRef(v); }
    }
    ClearExc(env);
    if (!holder || !m_getSurface) return nullptr;
    jobject surf = env->CallObjectMethod(holder, m_getSurface);
    ClearExc(env);
    env->DeleteLocalRef(holder);
    return surf;
}

bool IsGameView(JNIEnv* env, jobject view)
{
    if (!env || !g_act || !f_view || !view) return false;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    bool same = v && env->IsSameObject(v, view);
    if (v) env->DeleteLocalRef(v);
    return same;
}

// `ev` is the copy Android made for the SurfaceView: its coordinates are already relative to the picture. The game normally
// gets the activity-level (window) event; we give Activity.onTouchEvent the picture-local one instead, scaled to the render size.
bool ForwardTouch(JNIEnv* env, jobject ev)
{
    static jclass mec = nullptr, matc = nullptr;
    static jmethodID mAct = nullptr, mObtain = nullptr, mTransform = nullptr, mRecycle = nullptr, mGetX = nullptr, mGetY = nullptr;
    static jmethodID mMatCtor = nullptr, mSetScale = nullptr;
    if (!env || !g_act || !ev || !m_actTouch) return false;
    if (!mec) {
        jclass a = env->FindClass("android/view/MotionEvent");                  ClearExc(env);
        jclass b = env->FindClass("android/graphics/Matrix");                   ClearExc(env);
        if (!a || !b) return false;
        mAct       = env->GetMethodID(a, "getActionMasked", "()I");             ClearExc(env);
        mObtain    = env->GetStaticMethodID(a, "obtain", "(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;"); ClearExc(env);
        mTransform = env->GetMethodID(a, "transform", "(Landroid/graphics/Matrix;)V"); ClearExc(env);
        mRecycle   = env->GetMethodID(a, "recycle", "()V");                     ClearExc(env);
        mGetX      = env->GetMethodID(a, "getX", "()F");                        ClearExc(env);
        mGetY      = env->GetMethodID(a, "getY", "()F");                        ClearExc(env);
        mMatCtor   = env->GetMethodID(b, "<init>", "()V");                      ClearExc(env);
        mSetScale  = env->GetMethodID(b, "setScale", "(FF)V");                  ClearExc(env);
        mec = (jclass)env->NewGlobalRef(a); matc = (jclass)env->NewGlobalRef(b);
    }
    const int action = mAct ? env->CallIntMethod(ev, mAct) : -1; ClearExc(env);
    if (action == 0) RefreshGeometry(env);                          // pointer down: re-read view size (and position)
    const int vw = g.nativeW.load(), vh = g.nativeH.load(), aw = g.activeW.load(), ah = g.activeH.load();
    const bool scale = g.overrideOn.load() && vw > 0 && vh > 0 && aw > 0 && ah > 0 && (aw != vw || ah != vh);
    jobject send = ev, copy = nullptr, mat = nullptr;
    if (scale && mObtain && mTransform && mMatCtor && mSetScale) {  // never modify Android's shared event: work on a copy
        copy = env->CallStaticObjectMethod(mec, mObtain, ev);         ClearExc(env);
        mat  = env->NewObject(matc, mMatCtor);                        ClearExc(env);
        if (copy && mat) {
            env->CallVoidMethod(mat, mSetScale, (jfloat)aw / (jfloat)vw, (jfloat)ah / (jfloat)vh); ClearExc(env);
            env->CallVoidMethod(copy, mTransform, mat);               ClearExc(env);
            send = copy;
        }
    }
    static std::atomic<int> logged{0};
    if (action == 0 && logged.fetch_add(1) < 12 && mGetX && mGetY) {
        float lx = env->CallFloatMethod(ev, mGetX), ly = env->CallFloatMethod(ev, mGetY); ClearExc(env);
        float gx = (send != ev) ? env->CallFloatMethod(send, mGetX) : lx, gy = (send != ev) ? env->CallFloatMethod(send, mGetY) : ly; ClearExc(env);
        hexed::HLog("gate touch picture-local (%.0f,%.0f) -> game (%.0f,%.0f)  view %dx%d game %dx%d", lx, ly, gx, gy, vw, vh, aw, ah);
    }
    g.mappedGesture++;
    env->CallBooleanMethod(g_act, m_actTouch, send);                  // virtual: reaches the game's own override
    g.mappedGesture--;
    ClearExc(env);
    if (copy) { if (mRecycle) env->CallVoidMethod(copy, mRecycle); ClearExc(env); env->DeleteLocalRef(copy); }
    if (mat) env->DeleteLocalRef(mat);
    return true;
}


// ===================================================================================================================
// Touch path (1.0.8, geometry 1.0.9): Window.Callback proxy.
//
// Facts (docs/NOTES.md): the game reads touches in GTASA.onTouchEvent(MotionEvent), which Android calls from
// Activity.dispatchTouchEvent after the view tree declined the event, and the coordinates are WINDOW coordinates. The picture is
// centered inside the window (padding from ApplyLayout), so the game's idea of "its screen" must be shifted by the picture's
// origin and scaled to the render size. Doing that on ONE view (the 1.0.7 gate) is fragile: it only works if that view gets the
// event. The Window.Callback is the single place every touch passes through, so the mapping is done there:
//   1. the view tree (Java overlays, dialogs, IME buttons) gets the event UNCHANGED in window coordinates, as always;
//   2. only what nobody consumed goes on to the game, as Activity.onTouchEvent(picture-local, render-size event);
//   3. a gesture that starts in the black bars is swallowed.
// The picture rectangle is read from the live SurfaceView on every pointer-down (same view that ApplyLayout centered).
// ===================================================================================================================
namespace cb {
static bool       ready = false;
static jclass     cClass, cProxy, cBoolean, cMotion, cMatrix, cWinCb, cActivity;
static jmethodID  getWindow, onUserInteraction, dispatch, onTouch;
static jmethodID  winGetCb, winSetCb, winSuper;
static jmethodID  clsGetMethod, clsGetLoader, mthGetName, mthInvoke, mthDecl;
static jmethodID  proxyNew, thrGetCause, boolValueOf;
static jmethodID  evAction, evObtain, evTransform, evRecycle, evGetX, evGetY;
static jmethodID  matInit, matSetTranslate, matPostScale;
static jclass     cInvTarget;

static jclass Global(JNIEnv* env, const char* name)
{
    jclass c = env->FindClass(name); ClearExc(env);
    if (!c) return nullptr;
    jclass g2 = (jclass)env->NewGlobalRef(c);
    env->DeleteLocalRef(c);
    return g2;
}

static bool Init(JNIEnv* env)
{
    if (ready) return true;
    cClass    = Global(env, "java/lang/Class");
    cProxy    = Global(env, "java/lang/reflect/Proxy");
    cBoolean  = Global(env, "java/lang/Boolean");
    cMotion   = Global(env, "android/view/MotionEvent");
    cMatrix   = Global(env, "android/graphics/Matrix");
    cWinCb    = Global(env, "android/view/Window$Callback");
    cActivity = Global(env, "android/app/Activity");
    cInvTarget= Global(env, "java/lang/reflect/InvocationTargetException");
    jclass cWin = env->FindClass("android/view/Window"); ClearExc(env);
    jclass cMth = env->FindClass("java/lang/reflect/Method"); ClearExc(env);
    jclass cThr = env->FindClass("java/lang/Throwable"); ClearExc(env);
    if (!cClass || !cProxy || !cBoolean || !cMotion || !cMatrix || !cWinCb || !cActivity || !cInvTarget || !cWin || !cMth || !cThr) {
        hexed::HLog("callback: a framework class is missing");
        return false;
    }
    getWindow         = env->GetMethodID(cActivity, "getWindow", "()Landroid/view/Window;");                         ClearExc(env);
    onUserInteraction = env->GetMethodID(cActivity, "onUserInteraction", "()V");                                     ClearExc(env);
    dispatch          = env->GetMethodID(cActivity, "dispatchTouchEvent", "(Landroid/view/MotionEvent;)Z");          ClearExc(env);
    onTouch           = env->GetMethodID(cActivity, "onTouchEvent", "(Landroid/view/MotionEvent;)Z");                ClearExc(env);
    winGetCb          = env->GetMethodID(cWin, "getCallback", "()Landroid/view/Window$Callback;");                   ClearExc(env);
    winSetCb          = env->GetMethodID(cWin, "setCallback", "(Landroid/view/Window$Callback;)V");                  ClearExc(env);
    winSuper          = env->GetMethodID(cWin, "superDispatchTouchEvent", "(Landroid/view/MotionEvent;)Z");          ClearExc(env);
    clsGetMethod      = env->GetMethodID(cClass, "getMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;"); ClearExc(env);
    clsGetLoader      = env->GetMethodID(cClass, "getClassLoader", "()Ljava/lang/ClassLoader;");                     ClearExc(env);
    mthGetName        = env->GetMethodID(cMth, "getName", "()Ljava/lang/String;");                                   ClearExc(env);
    mthInvoke         = env->GetMethodID(cMth, "invoke", "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;"); ClearExc(env);
    mthDecl           = env->GetMethodID(cMth, "getDeclaringClass", "()Ljava/lang/Class;");                          ClearExc(env);
    proxyNew          = env->GetStaticMethodID(cProxy, "newProxyInstance",
                            "(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;"); ClearExc(env);
    thrGetCause       = env->GetMethodID(cThr, "getCause", "()Ljava/lang/Throwable;");                               ClearExc(env);
    boolValueOf       = env->GetStaticMethodID(cBoolean, "valueOf", "(Z)Ljava/lang/Boolean;");                       ClearExc(env);
    evAction          = env->GetMethodID(cMotion, "getActionMasked", "()I");                                         ClearExc(env);
    evObtain          = env->GetStaticMethodID(cMotion, "obtain", "(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;"); ClearExc(env);
    evTransform       = env->GetMethodID(cMotion, "transform", "(Landroid/graphics/Matrix;)V");                      ClearExc(env);
    evRecycle         = env->GetMethodID(cMotion, "recycle", "()V");                                                 ClearExc(env);
    evGetX            = env->GetMethodID(cMotion, "getX", "()F");                                                    ClearExc(env);
    evGetY            = env->GetMethodID(cMotion, "getY", "()F");                                                    ClearExc(env);
    matInit           = env->GetMethodID(cMatrix, "<init>", "()V");                                                  ClearExc(env);
    matSetTranslate   = env->GetMethodID(cMatrix, "setTranslate", "(FF)V");                                          ClearExc(env);
    matPostScale      = env->GetMethodID(cMatrix, "postScale", "(FF)Z");                                             ClearExc(env);
    env->DeleteLocalRef(cWin); env->DeleteLocalRef(cMth); env->DeleteLocalRef(cThr);
    ready = getWindow && onUserInteraction && dispatch && onTouch && winGetCb && winSetCb && winSuper && clsGetMethod && clsGetLoader &&
            mthGetName && mthInvoke && mthDecl && proxyNew && thrGetCause && boolValueOf && evAction && evObtain && evTransform &&
            evRecycle && evGetX && evGetY && matInit && matSetTranslate && matPostScale;
    if (!ready) hexed::HLog("callback: a framework method id is missing");
    return ready;
}

// Does the game's Activity class declare its own dispatchTouchEvent? (Then the event the game sees comes from that override.)
static bool DetectDispatchOverride(JNIEnv* env, jobject act)
{
    jclass ac = env->GetObjectClass(act);
    jstring nm = env->NewStringUTF("dispatchTouchEvent");
    jobjectArray params = env->NewObjectArray(1, cClass, cMotion);
    jobject m = (ac && nm && params) ? env->CallObjectMethod(ac, clsGetMethod, nm, params) : nullptr;
    ClearExc(env);
    bool overridden = false;
    if (m) {
        jobject decl = env->CallObjectMethod(m, mthDecl); ClearExc(env);
        overridden = decl && !env->IsSameObject(decl, cActivity);
        if (decl) env->DeleteLocalRef(decl);
        env->DeleteLocalRef(m);
    }
    if (params) env->DeleteLocalRef(params);
    if (nm) env->DeleteLocalRef(nm);
    if (ac) env->DeleteLocalRef(ac);
    return overridden;
}
} // namespace cb

bool InstallCallback(JNIEnv* env)
{
    if (!env || !g_act || !ui::Handler() || !cb::Init(env)) return false;
    jobject win = env->CallObjectMethod(g_act, cb::getWindow); ClearExc(env);
    if (!win) return false;
    jobject cur = env->CallObjectMethod(win, cb::winGetCb); ClearExc(env);
    bool ok = false;
    if (cur && g_proxy && env->IsSameObject(cur, g_proxy)) {
        ok = true;                                                           // already ours (re-layout)
    } else if (cur) {
        RetireCurrentProxy(env);                                             // somebody replaced our callback (or first install)
        jobject handler = ui::Handler();
        jclass hc = env->GetObjectClass(handler);
        jobject loader = hc ? env->CallObjectMethod(hc, cb::clsGetLoader) : nullptr; ClearExc(env);
        jobjectArray itf = env->NewObjectArray(1, cb::cClass, cb::cWinCb);   ClearExc(env);
        jobject proxy = (loader && itf) ? env->CallStaticObjectMethod(cb::cProxy, cb::proxyNew, loader, itf, handler) : nullptr; ClearExc(env);
        if (proxy) {
            g_origCb = env->NewGlobalRef(cur);                               // set BEFORE the first callback can reach the handler
            g_proxy  = env->NewGlobalRef(proxy);
            env->CallVoidMethod(win, cb::winSetCb, g_proxy); ClearExc(env);
            jobject now = env->CallObjectMethod(win, cb::winGetCb); ClearExc(env);
            ok = now && env->IsSameObject(now, g_proxy);
            if (now) env->DeleteLocalRef(now);
            if (ok) {
                g_dispatchOverridden = cb::DetectDispatchOverride(env, g_act);
                g.proxyOn = 1;
                hexed::HLog("touch: Window.Callback proxy installed (Activity overrides dispatchTouchEvent: %d)", g_dispatchOverridden ? 1 : 0);
            } else { DropPair(env, &g_proxy, &g_origCb); g.proxyOn = 0; hexed::HLog("touch: setCallback did not stick"); }
            env->DeleteLocalRef(proxy);
        } else hexed::HLog("touch: Proxy.newProxyInstance failed");
        if (itf) env->DeleteLocalRef(itf);
        if (loader) env->DeleteLocalRef(loader);
        if (hc) env->DeleteLocalRef(hc);
    }
    if (cur) env->DeleteLocalRef(cur);
    env->DeleteLocalRef(win);
    return ok;
}

void RemoveCallback(JNIEnv* env)
{
    if (!env || !g_proxy) return;
    if (cb::ready && g_act) {
        jobject win = env->CallObjectMethod(g_act, cb::getWindow); ClearExc(env);
        if (win) {
            jobject cur = env->CallObjectMethod(win, cb::winGetCb); ClearExc(env);
            if (cur && env->IsSameObject(cur, g_proxy) && g_origCb) { env->CallVoidMethod(win, cb::winSetCb, g_origCb); ClearExc(env); }
            if (cur) env->DeleteLocalRef(cur);
            env->DeleteLocalRef(win);
        }
    }
    if (g_proxy) RetireCurrentProxy(env);              // if it could not be taken out (somebody wrapped it), it must keep forwarding
    g.proxyOn = 0;
    hexed::HLog("touch: Window.Callback proxy removed");
}

// UI thread. Cheap re-check (the layout is not touched): is our proxy still the window's callback? If not, put it back.
bool VerifyTouchPath(JNIEnv* env)
{
    if (!env || !g_act || !g.overrideOn.load() || !g.touchRemap.load() || !ui::Handler()) return false;
    if (!cb::ready && !cb::Init(env)) return false;
    jobject win = env->CallObjectMethod(g_act, cb::getWindow); ClearExc(env);
    if (!win) return false;
    jobject cur = env->CallObjectMethod(win, cb::winGetCb); ClearExc(env);
    const bool ours = cur && g_proxy && env->IsSameObject(cur, g_proxy);
    if (cur) env->DeleteLocalRef(cur);
    env->DeleteLocalRef(win);
    if (ours) { g.proxyOn = 1; return true; }
    hexed::HLog("touch: our Window.Callback proxy is not the active one - installing it again");
    const bool ok = InstallCallback(env);
    if (!ok) g.proxyOn = 0;
    return ok;
}

// Copy of `ev` moved into the game's coordinate space: window -> picture-local (minus the picture's origin) -> render size.
// Never touches Android's own event.
static jobject MapEvent(JNIEnv* env, jobject ev, int offX, int offY, int vw, int vh, int aw, int ah)
{
    jobject copy = env->CallStaticObjectMethod(cb::cMotion, cb::evObtain, ev); ClearExc(env);
    jobject mat  = env->NewObject(cb::cMatrix, cb::matInit);                   ClearExc(env);
    if (copy && mat) {
        env->CallVoidMethod(mat, cb::matSetTranslate, (jfloat)-offX, (jfloat)-offY); ClearExc(env);
        if (vw > 0 && vh > 0 && aw > 0 && ah > 0 && (aw != vw || ah != vh)) {
            env->CallBooleanMethod(mat, cb::matPostScale, (jfloat)aw / (jfloat)vw, (jfloat)ah / (jfloat)vh); ClearExc(env);
        }
        env->CallVoidMethod(copy, cb::evTransform, mat); ClearExc(env);
    }
    if (mat) env->DeleteLocalRef(mat);
    return copy;
}

static std::atomic<int> g_dropGesture{0};     // a gesture that started in a black bar is swallowed until it ends

static jboolean DispatchTouch(JNIEnv* env, jobject ev)
{
    const int action = env->CallIntMethod(ev, cb::evAction); ClearExc(env);
    const bool down = (action == 0);
    if (down) {
        RefreshGeometry(env);                                       // live picture rectangle: SurfaceView size + position in the window
        g_dropGesture = 0;
        env->CallVoidMethod(g_act, cb::onUserInteraction); ClearExc(env);
    }
    // 1. the view tree sees the event exactly as Android delivered it (this is what Activity.dispatchTouchEvent does first)
    if (!g_dispatchOverridden) {
        jobject win = env->CallObjectMethod(g_act, cb::getWindow); ClearExc(env);
        jboolean handled = win ? env->CallBooleanMethod(win, cb::winSuper, ev) : JNI_FALSE; ClearExc(env);
        if (win) env->DeleteLocalRef(win);
        if (handled) return JNI_TRUE;
    }
    // 2. nobody took it: it is for the game. Same picture rectangle ApplyLayout centered.
    const int offX = g.offX.load(), offY = g.offY.load(), vw = g.nativeW.load(), vh = g.nativeH.load();
    const int aw = g.activeW.load(), ah = g.activeH.load();
    if (down) {
        const float x = env->CallFloatMethod(ev, cb::evGetX), y = env->CallFloatMethod(ev, cb::evGetY); ClearExc(env);
        const bool inside = vw <= 0 || vh <= 0 || (x >= offX && y >= offY && x < offX + vw && y < offY + vh);
        g_dropGesture = inside ? 0 : 1;
        const float s = (vw > 0 && aw > 0) ? (float)aw / (float)vw : 1.0f, t = (vh > 0 && ah > 0) ? (float)ah / (float)vh : 1.0f;
        g.lastRawX = (int)x; g.lastRawY = (int)y; g.lastMapX = (int)((x - offX) * s); g.lastMapY = (int)((y - offY) * t);
        if (inside) g.mappedDowns++;
        static std::atomic<int> logged{0};
        if (logged.fetch_add(1) < 12)
            hexed::HLog("touch(cb) window (%.0f,%.0f) picture at (%d,%d) %dx%d game %dx%d -> (%.0f,%.0f) %s", x, y, offX, offY, vw, vh, aw, ah,
                        (x - offX) * s, (y - offY) * t, inside ? "GAME" : "BAR-ignored");
    }
    if (g_dropGesture.load()) {
        if (action == 1 || action == 3) g_dropGesture = 0;
        return JNI_TRUE;                                            // started in a black bar: not for the game
    }
    jobject copy = MapEvent(env, ev, offX, offY, vw, vh, aw, ah);
    jobject send = copy ? copy : ev;
    // the game's own entry point: its override if it has one, else Activity.onTouchEvent (virtual: reaches GTASA.onTouchEvent)
    g.mappedGesture++;                                              // the native touch hooks run inside this call: they must not map a second time
    jboolean r = env->CallBooleanMethod(g_act, g_dispatchOverridden ? cb::dispatch : cb::onTouch, send); ClearExc(env);
    g.mappedGesture--;
    if (copy) { env->CallVoidMethod(copy, cb::evRecycle); ClearExc(env); env->DeleteLocalRef(copy); }
    return r;
}

static jobject BoxBool(JNIEnv* env, jboolean z)
{
    jobject o = env->CallStaticObjectMethod(cb::cBoolean, cb::boolValueOf, z); ClearExc(env);
    return o;
}

// InvocationHandler.invoke for the Window.Callback proxy. Everything is forwarded to the original callback unchanged, except
// dispatchTouchEvent while a resolution override is active (and touch remap is ON).
jobject CallbackInvoke(JNIEnv* env, jobject proxy, jobject method, jobjectArray args)
{
    jobject orig = nullptr; bool current = false;                   // which proxy is calling? (see PxPair)
    if (g_proxy && proxy && env->IsSameObject(proxy, g_proxy)) { orig = g_origCb; current = true; }
    else if (proxy) for (auto& p : g_old) if (p.proxy && env->IsSameObject(proxy, p.proxy)) { orig = p.orig; break; }
    if (!orig) orig = g_origCb;
    if (!orig || !cb::ready) return nullptr;
    bool touch = false;
    jstring jn = (jstring)env->CallObjectMethod(method, cb::mthGetName); ClearExc(env);
    if (jn) {
        const char* nm = env->GetStringUTFChars(jn, nullptr);
        touch = nm && strcmp(nm, "dispatchTouchEvent") == 0;
        if (nm) env->ReleaseStringUTFChars(jn, nm);
        env->DeleteLocalRef(jn);
    }
    if (touch) g.proxyCalls++;
    if (current && touch && args && env->GetArrayLength(args) == 1 && g.overrideOn.load() && g.touchRemap.load()) {
        jobject ev = env->GetObjectArrayElement(args, 0);
        if (ev) {
            jboolean r = DispatchTouch(env, ev);
            env->DeleteLocalRef(ev);
            return BoxBool(env, r);
        }
    }
    jobject res = env->CallObjectMethod(method, cb::mthInvoke, orig, args);
    if (env->ExceptionCheck()) {                                    // Method.invoke wraps exceptions: rethrow the real one
        jthrowable ex = env->ExceptionOccurred();
        env->ExceptionClear();
        if (ex && env->IsInstanceOf(ex, cb::cInvTarget)) {
            jobject cause = env->CallObjectMethod(ex, cb::thrGetCause); ClearExc(env);
            if (cause) { env->Throw((jthrowable)cause); env->DeleteLocalRef(ex); return nullptr; }
        }
        if (ex) env->Throw(ex);
        return nullptr;
    }
    return res;
}

static bool LocationInWindow(JNIEnv* env, jobject view, int* x, int* y)
{
    if (!m_getLocWin || !view) return false;
    jintArray arr = env->NewIntArray(2);
    if (!arr) return false;
    env->CallVoidMethod(view, m_getLocWin, arr);
    jint xy[2] = { 0, 0 };
    env->GetIntArrayRegion(arr, 0, 2, xy);
    const bool ok = !env->ExceptionCheck();
    ClearExc(env);
    env->DeleteLocalRef(arr);
    if (ok) { *x = xy[0]; *y = xy[1]; }
    return ok;
}

static jobject ContentView(JNIEnv* env, jobject v);

// Touch events reach the game through NvEventQueueActivity.onTouchEvent, so their coordinates are WINDOW coordinates.
//
// The picture rectangle in that space is NOT read back from the SurfaceView (the cause of the "touch area at the top-left" reports:
// the touch origin came from a different source than the one that centered the picture). It is computed with the one centering rule,
// calc::CenterRect, from the same inputs ApplyLayout used: the content root's size and window position, and the wanted box.
// The SurfaceView position Android reports is only compared with it (diagnostic); only if the two disagree, i.e. the picture is
// not where the rule put it, the picture's real position wins so the touch area still lies on the picture.
static void RefreshImpl(JNIEnv* env, bool layoutSettled)
{
    if (!env || !g_act || !f_view || !m_getW || !m_getH) return;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    if (!v) return;
    jint vw = env->CallIntMethod(v, m_getW), vh = env->CallIntMethod(v, m_getH); ClearExc(env);
    int vx = 0, vy = 0;
    const bool haveLive = vw > 0 && vh > 0 && LocationInWindow(env, v, &vx, &vy);
    int cx = 0, cy = 0, cw = 0, ch = 0;
    jobject c = m_getParent ? ContentView(env, v) : nullptr;
    if (c) {
        cw = env->CallIntMethod(c, m_getW); ch = env->CallIntMethod(c, m_getH); ClearExc(env);
        if (!LocationInWindow(env, c, &cx, &cy)) { cx = 0; cy = 0; }
        env->DeleteLocalRef(c);
    }
    if (cw > 0 && ch > 0) {
        int px = 0, py = 0, pw = 0, ph = 0;
        calc::PictureRect(cx, cy, cw, ch, g.boxW.load(), g.boxH.load(), &px, &py, &pw, &ph);
        g.contentX = cx; g.contentY = cy;
        if (layoutSettled && haveLive && (abs(vx - px) > 2 || abs(vy - py) > 2 || abs((int)vw - pw) > 2 || abs((int)vh - ph) > 2)) {
            static std::atomic<int> logged{0};
            if (logged.fetch_add(1) < 6)
                hexed::HLog("geometry: the picture is at (%d,%d) %dx%d but the centering rule says (%d,%d) %dx%d - using the picture's real rectangle",
                            vx, vy, (int)vw, (int)vh, px, py, pw, ph);
            px = vx; py = vy; pw = vw; ph = vh;
        }
        g.offX = px; g.offY = py; g.nativeW = pw; g.nativeH = ph;
    } else if (haveLive) {                                              // content root unavailable: the live rectangle is all there is
        g.offX = vx; g.offY = vy; g.nativeW = vw; g.nativeH = vh;
    }
    if (haveLive) { g.liveX = vx; g.liveY = vy; }
    env->DeleteLocalRef(v);
}

void RefreshGeometry(JNIEnv* env) { RefreshImpl(env, true); }

bool ViewSize(int* w, int* h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_view || !m_getW || !m_getH) return false;
    jobject v = env->GetObjectField(g_act, f_view);
    ClearExc(env);
    if (!v) return false;
    jint vw = env->CallIntMethod(v, m_getW);
    jint vh = env->CallIntMethod(v, m_getH);
    ClearExc(env);
    env->DeleteLocalRef(v);
    if (vw <= 0 || vh <= 0) return false;
    *w = vw; *h = vh;
    return true;
}

// The "screen" for the game = android.R.id.content: the grandparent of the SurfaceView (view -> FrameLayout -> content).
// Both the game view AND every overlay added with addContentView (chat, buttons, voice, dialogs) live in it, so padding it
// shrinks all of them together. Its own size does not change when its padding does.
static jobject ContentView(JNIEnv* env, jobject v)
{
    jclass vc = env->FindClass("android/view/View"); ClearExc(env);
    jobject fl = env->CallObjectMethod(v, m_getParent); ClearExc(env);
    jobject content = nullptr;
    if (fl && vc && env->IsInstanceOf(fl, vc)) { content = env->CallObjectMethod(fl, m_getParent); ClearExc(env); }
    if (!content || !(vc && env->IsInstanceOf(content, vc))) {          // unexpected hierarchy: use the direct parent
        if (content) env->DeleteLocalRef(content);
        content = fl; fl = nullptr;
    }
    if (fl) env->DeleteLocalRef(fl);
    if (vc) env->DeleteLocalRef(vc);
    return content;
}

bool ParentSize(int* w, int* h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_view || !m_getParent || !m_getW || !m_getH) return false;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    if (!v) return false;
    jobject c = ContentView(env, v);
    env->DeleteLocalRef(v);
    if (!c) return false;
    jint pw = env->CallIntMethod(c, m_getW), ph = env->CallIntMethod(c, m_getH);
    ClearExc(env);
    env->DeleteLocalRef(c);
    if (pw <= 0 || ph <= 0) return false;
    *w = pw; *h = ph;
    return true;
}

// UI thread only. Everything is done the way Android itself resizes a game window, so the game, EGL, Java and every
// mod see ONE consistent size through the normal surfaceChanged -> setWindowSize path (no faked values):
//   1. padding on the content root  -> SurfaceView and all overlays share the centered box, bars are black
//   2. SurfaceHolder.setFixedSize   -> render resolution when it differs from the box (the game gets that size)
bool ApplyLayout(JNIEnv* env)
{
    if (!env || !g_act || !f_view || !m_getParent || !m_setPadding || !m_getHolder) return false;
    const int bw = g.boxW.load(), bh = g.boxH.load(), aw = g.activeW.load(), ah = g.activeH.load();
    const bool over = g.overrideOn.load() != 0;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    if (!v) return false;
    jobject c = ContentView(env, v);
    bool ok = false;
    if (c) {
        int cw = env->CallIntMethod(c, m_getW), ch = env->CallIntMethod(c, m_getH); ClearExc(env);
        if (cw > 0 && ch > 0) {
            int l = 0, t = 0, r = 0, b = 0;
            const bool box = calc::HasBox(bw, bh, cw, ch);                      // same test RefreshGeometry uses for the touch area
            if (box) calc::CenterRect(cw, ch, bw, bh, &l, &t, &r, &b);          // the one centering rule (touch uses the resulting view rect)
            env->CallVoidMethod(c, m_setPadding, l, t, r, b); ClearExc(env);
            if (box && m_setBgColor) { env->CallVoidMethod(c, m_setBgColor, (jint)0xFF000000); ClearExc(env); }
            const int tw = box ? bw : cw, th = box ? bh : ch;                       // size the SurfaceView gets from layout
            jobject holder = env->CallObjectMethod(v, m_getHolder); ClearExc(env);
            bool fixed = false;
            if (holder) {
                if (over && aw > 0 && ah > 0 && (aw != tw || ah != th) && m_setFixed) {
                    env->CallVoidMethod(holder, m_setFixed, aw, ah); fixed = true;
                } else if (m_setFromLay) {
                    env->CallVoidMethod(holder, m_setFromLay);
                }
                ClearExc(env);
                env->DeleteLocalRef(holder);
            }
            // Touch path. With any override active the game's touches must be mapped into the picture. Preferred: the Window.Callback
            // proxy (every touch passes there, window coordinates in, picture-local out). Fallback: the 1.0.7 View.OnTouchListener
            // gate. Last resort: the native hooks (they stand down whenever a Java path is active). All off again on reset.
            bool proxy = false;
            if (over && ui::Handler()) proxy = InstallCallback(env);
            else RemoveCallback(env);
            if (!proxy) g.proxyOn = 0;
            jobject gate = ui::Gate();
            const bool wantGate = over && !proxy && gate && m_setOTL && m_actTouch;
            if (m_setOTL) {
                env->CallVoidMethod(v, m_setOTL, wantGate ? gate : (jobject)nullptr); ClearExc(env);
                env->CallVoidMethod(c, m_setOTL, wantGate ? gate : (jobject)nullptr); ClearExc(env);
            }
            g.gateOn = (proxy || wantGate) ? 1 : 0;
            RefreshImpl(env, false);                                                // touch area = this rectangle, available before the first touch (view not measured yet)
            hexed::HLog("layout: content %dx%d pad L%d T%d R%d B%d | surface %s %dx%d | touch path %s", cw, ch, l, t, r, b,
                        fixed ? "FIXED" : "from layout", fixed ? aw : tw, fixed ? ah : th, proxy ? "callback" : (wantGate ? "gate" : "native hooks"));
            ok = true;
        } else hexed::HLog("layout: content view not laid out yet (%dx%d)", cw, ch);
        env->DeleteLocalRef(c);
    } else hexed::HLog("layout: content view not found");
    env->DeleteLocalRef(v);
    return ok;
}

bool SetBufferSize(int w, int h)
{
    JNIEnv* env = Env();
    if (!env || !g_act) { Err("no activity yet"); return false; }
    jobject surf = GetSurfaceObj(env);
    if (!surf) { Err("game surface not available"); return false; }
    ANativeWindow* win = ANativeWindow_fromSurface(env, surf);
    env->DeleteLocalRef(surf);
    if (!win) { Err("ANativeWindow_fromSurface failed"); return false; }
    // Buffer size only: the compositor scales it to the window. 0,0 restores the window size.
    int r = ANativeWindow_setBuffersGeometry(win, w, h, 0);
    ANativeWindow_release(win);
    g.bufferCalls++;
    if (r != 0) { Err("setBuffersGeometry(%d,%d) failed: %d", w, h, r); return false; }
    hexed::HLog("buffers geometry -> %dx%d", w, h);
    return true;
}

void SetJavaSurfaceFields(int w, int h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_surfW || !f_surfH) return;
    env->SetIntField(g_act, f_surfW, w);
    env->SetIntField(g_act, f_surfH, h);
    ClearExc(env);
}

bool FindActivityFallback()
{
    if (!AcquireVm()) { Err("JavaVM not found"); return false; }
    JNIEnv* env = Env();
    if (!env) { Err("no JNIEnv"); return false; }

    jclass at = env->FindClass("android/app/ActivityThread"); ClearExc(env);
    if (!at) return false;
    jmethodID cur = env->GetStaticMethodID(at, "currentActivityThread", "()Landroid/app/ActivityThread;"); ClearExc(env);
    jfieldID  fa  = env->GetFieldID(at, "mActivities", "Landroid/util/ArrayMap;");                          ClearExc(env);
    jclass mc = env->FindClass("android/util/ArrayMap");                                                    ClearExc(env);
    jclass rc = env->FindClass("android/app/ActivityThread$ActivityClientRecord");                          ClearExc(env);
    if (!cur || !fa || !mc || !rc) { Err("ActivityThread reflection unavailable"); return false; }
    jmethodID msize = env->GetMethodID(mc, "size", "()I");                              ClearExc(env);
    jmethodID mval  = env->GetMethodID(mc, "valueAt", "(I)Ljava/lang/Object;");         ClearExc(env);
    jfieldID  fact  = env->GetFieldID(rc, "activity", "Landroid/app/Activity;");        ClearExc(env);
    if (!msize || !mval || !fact) { Err("ActivityClientRecord layout unknown"); return false; }

    jobject thread = env->CallStaticObjectMethod(at, cur); ClearExc(env);
    jobject map = thread ? env->GetObjectField(thread, fa) : nullptr; ClearExc(env);
    bool found = false;
    if (map) {
        jint n = env->CallIntMethod(map, msize); ClearExc(env);
        for (jint i = 0; i < n && !found; ++i) {
            jobject rec = env->CallObjectMethod(map, mval, i); ClearExc(env);
            jobject act = rec ? env->GetObjectField(rec, fact) : nullptr; ClearExc(env);
            if (act) {
                jclass ac = env->GetObjectClass(act);
                jfieldID probe = ac ? env->GetFieldID(ac, "cachedSurfaceHolder", "Landroid/view/SurfaceHolder;") : nullptr;
                ClearExc(env);
                if (probe) found = Attach(env, act);
                if (ac) env->DeleteLocalRef(ac);
                env->DeleteLocalRef(act);
            }
            if (rec) env->DeleteLocalRef(rec);
        }
        env->DeleteLocalRef(map);
    }
    if (thread) env->DeleteLocalRef(thread);
    if (!found) Err("game activity not found");
    return found;
}

}} // namespace hexed::surface

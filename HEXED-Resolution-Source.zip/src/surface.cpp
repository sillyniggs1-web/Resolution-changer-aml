/*
 * HEXED surface module.
 *
 * Why this exists: the Nezuko/GTA:SA client creates its EGL window surface in Java
 * (NvEventQueueActivity.createEGLSurface). Changing the game's logical size alone leaves the
 * real surface at the screen size, so the picture only fills a corner and the rest shows stale
 * GPU memory. Here we change the size of the *buffers* of that surface instead
 * (ANativeWindow_setBuffersGeometry): the compositor then scales the smaller picture to the
 * whole screen, so the surface itself is the picture.
 *
 * Verified in the APK (classes.dex): NvEventQueueActivity has the fields
 *   SurfaceView view, SurfaceHolder cachedSurfaceHolder, SurfaceHolder holder, int surfaceWidth/Height.
 */
#include "state.h"
#include <mod/logger.h>
#include "hlog.h"

#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <atomic>
#include <dlfcn.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

namespace hexed { namespace surface {

static JavaVM*   g_vm         = nullptr;
static jobject   g_act        = nullptr;   // global ref: the NvEventQueueActivity instance
static jfieldID  f_cached     = nullptr;
static jfieldID  f_holder     = nullptr;
static jfieldID  f_view       = nullptr;
static jfieldID  f_surfW      = nullptr;
static jfieldID  f_surfH      = nullptr;
static jmethodID m_getHolder  = nullptr;   // SurfaceView.getHolder()
static jmethodID m_getSurface = nullptr;   // SurfaceHolder.getSurface()
static jmethodID m_getW       = nullptr;   // View.getWidth()
static jmethodID m_getH       = nullptr;   // View.getHeight()
static jmethodID m_getLP      = nullptr;   // View.getLayoutParams()
static jmethodID m_setLP      = nullptr;   // View.setLayoutParams()
static jmethodID m_getParent  = nullptr;   // View.getParent()
static jmethodID m_setBgColor = nullptr;   // View.setBackgroundColor(int)
static jmethodID m_setPadding = nullptr;   // View.setPadding(int,int,int,int)
static jmethodID m_getLocWin  = nullptr;   // View.getLocationInWindow(int[])
static jmethodID m_setOTL     = nullptr;   // View.setOnTouchListener(OnTouchListener)
static jmethodID m_actTouch   = nullptr;   // Activity.onTouchEvent(MotionEvent)
static jmethodID m_setFixed   = nullptr;   // SurfaceHolder.setFixedSize(int,int)
static jmethodID m_setFromLay = nullptr;   // SurfaceHolder.setSizeFromLayout()
static char      g_err[160]   = "";
static pthread_mutex_t g_mu   = PTHREAD_MUTEX_INITIALIZER;

static void Err(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(g_err, sizeof(g_err), fmt, ap);
    va_end(ap);
    hexed::HLog("%s", g_err);
}

static void ClearExc(JNIEnv* env) { if (env->ExceptionCheck()) env->ExceptionClear(); }

const char* LastError()   { return g_err; }
bool        HaveActivity(){ return g_act != nullptr; }
jobject     Activity()    { return g_act; }

typedef jint (*GetVMs_t)(JavaVM**, jsize, jsize*);

static bool AcquireVm()
{
    if (g_vm) return true;
    GetVMs_t fn = (GetVMs_t)dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs");
    if (!fn) {
        void* art = dlopen("libart.so", RTLD_NOW | RTLD_NOLOAD);
        if (art) fn = (GetVMs_t)dlsym(art, "JNI_GetCreatedJavaVMs");
    }
    if (!fn) return false;
    JavaVM* vm = nullptr; jsize n = 0;
    if (fn(&vm, 1, &n) != 0 || n < 1 || !vm) return false;
    g_vm = vm;
    return true;
}

JNIEnv* Env()
{
    if (!g_vm) return nullptr;
    JNIEnv* e = nullptr;
    jint r = g_vm->GetEnv((void**)&e, JNI_VERSION_1_6);
    if (r == JNI_OK) return e;
    if (r == JNI_EDETACHED && g_vm->AttachCurrentThread(&e, nullptr) == JNI_OK) return e;
    return nullptr;
}

static void ResolveIds(JNIEnv* env, jobject act)
{
    jclass ac = env->GetObjectClass(act);
    if (ac) {
        f_cached = env->GetFieldID(ac, "cachedSurfaceHolder", "Landroid/view/SurfaceHolder;"); ClearExc(env);
        f_holder = env->GetFieldID(ac, "holder",              "Landroid/view/SurfaceHolder;"); ClearExc(env);
        f_view   = env->GetFieldID(ac, "view",                "Landroid/view/SurfaceView;");   ClearExc(env);
        f_surfW  = env->GetFieldID(ac, "surfaceWidth",  "I"); ClearExc(env);
        f_surfH  = env->GetFieldID(ac, "surfaceHeight", "I"); ClearExc(env);
        env->DeleteLocalRef(ac);
    }
    jclass sv = env->FindClass("android/view/SurfaceView");
    if (sv) { m_getHolder = env->GetMethodID(sv, "getHolder", "()Landroid/view/SurfaceHolder;"); ClearExc(env); env->DeleteLocalRef(sv); }
    ClearExc(env);
    jclass vw = env->FindClass("android/view/View");
    if (vw) {
        m_getW = env->GetMethodID(vw, "getWidth",  "()I"); ClearExc(env);
        m_getH = env->GetMethodID(vw, "getHeight", "()I"); ClearExc(env);
        m_getLP      = env->GetMethodID(vw, "getLayoutParams", "()Landroid/view/ViewGroup$LayoutParams;"); ClearExc(env);
        m_setLP      = env->GetMethodID(vw, "setLayoutParams", "(Landroid/view/ViewGroup$LayoutParams;)V"); ClearExc(env);
        m_getParent  = env->GetMethodID(vw, "getParent", "()Landroid/view/ViewParent;");                    ClearExc(env);
        m_setBgColor = env->GetMethodID(vw, "setBackgroundColor", "(I)V");                                  ClearExc(env);
        m_setPadding = env->GetMethodID(vw, "setPadding", "(IIII)V");                                       ClearExc(env);
        m_getLocWin  = env->GetMethodID(vw, "getLocationInWindow", "([I)V");                                ClearExc(env);
        m_setOTL     = env->GetMethodID(vw, "setOnTouchListener", "(Landroid/view/View$OnTouchListener;)V");   ClearExc(env);
        env->DeleteLocalRef(vw);
    }
    ClearExc(env);
    jclass actc = env->FindClass("android/app/Activity");
    if (actc) { m_actTouch = env->GetMethodID(actc, "onTouchEvent", "(Landroid/view/MotionEvent;)Z"); ClearExc(env); env->DeleteLocalRef(actc); }
    ClearExc(env);
    jclass sh = env->FindClass("android/view/SurfaceHolder");
    if (sh) {
        m_getSurface = env->GetMethodID(sh, "getSurface", "()Landroid/view/Surface;"); ClearExc(env);
        m_setFixed   = env->GetMethodID(sh, "setFixedSize", "(II)V");                  ClearExc(env);
        m_setFromLay = env->GetMethodID(sh, "setSizeFromLayout", "()V");               ClearExc(env);
        env->DeleteLocalRef(sh);
    }
    ClearExc(env);
    hexed::HLog("layout ids: getLP=%d setLP=%d getParent=%d setBg=%d", m_getLP != 0, m_setLP != 0, m_getParent != 0, m_setBgColor != 0);
    hexed::HLog("surface ids: cached=%d holder=%d view=%d surfW=%d getHolder=%d getSurface=%d getW=%d",
                 f_cached != 0, f_holder != 0, f_view != 0, f_surfW != 0,
                 m_getHolder != 0, m_getSurface != 0, m_getW != 0);
}

bool Attach(JNIEnv* env, jobject act)
{
    if (!env || !act) return false;
    pthread_mutex_lock(&g_mu);
    if (!g_vm) env->GetJavaVM(&g_vm);
    if (!g_act || !env->IsSameObject(g_act, act)) {
        if (g_act) env->DeleteGlobalRef(g_act);
        g_act = env->NewGlobalRef(act);
        hexed::HLog("Activity captured");
    }
    if (!f_cached && !f_holder && !f_view) ResolveIds(env, act);
    pthread_mutex_unlock(&g_mu);
    ui::Init(env, act);                       // outside the lock: it calls back into this module
    return g_act != nullptr;
}

// Surface of the game's SurfaceView (local ref, caller deletes), or null.
static jobject GetSurfaceObj(JNIEnv* env)
{
    jobject holder = nullptr;
    if (f_cached) holder = env->GetObjectField(g_act, f_cached);
    if (!holder && f_holder) holder = env->GetObjectField(g_act, f_holder);
    if (!holder && f_view && m_getHolder) {
        jobject v = env->GetObjectField(g_act, f_view);
        if (v) { holder = env->CallObjectMethod(v, m_getHolder); env->DeleteLocalRef(v); }
    }
    ClearExc(env);
    if (!holder || !m_getSurface) return nullptr;
    jobject surf = env->CallObjectMethod(holder, m_getSurface);
    ClearExc(env);
    env->DeleteLocalRef(holder);
    return surf;
}

// Touch gate (content root). `ev` is relative to the content root, which is also the coordinate space of the box we laid out:
// the box starts at (padL, padT) and is boxW x boxH (or the whole content when there is no box). Everything used here was set by
// ApplyLayout itself, so nothing depends on querying the SurfaceView at touch time.
bool GateTouch(JNIEnv* env, jobject ev)
{
    static jclass mec = nullptr, matc = nullptr;
    static jmethodID mAct = nullptr, mObtain = nullptr, mTransform = nullptr, mRecycle = nullptr, mGetX = nullptr, mGetY = nullptr;
    static jmethodID mMatCtor = nullptr, mSetTranslate = nullptr, mPostScale = nullptr;
    static std::atomic<int> drop{0};
    if (!env || !g_act || !ev || !m_actTouch) return false;
    if (!mec) {
        jclass a = env->FindClass("android/view/MotionEvent");                  ClearExc(env);
        jclass b = env->FindClass("android/graphics/Matrix");                   ClearExc(env);
        if (!a || !b) return false;
        mAct       = env->GetMethodID(a, "getActionMasked", "()I");             ClearExc(env);
        mObtain    = env->GetStaticMethodID(a, "obtain", "(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;"); ClearExc(env);
        mTransform = env->GetMethodID(a, "transform", "(Landroid/graphics/Matrix;)V"); ClearExc(env);
        mRecycle   = env->GetMethodID(a, "recycle", "()V");                     ClearExc(env);
        mGetX      = env->GetMethodID(a, "getX", "()F");                        ClearExc(env);
        mGetY      = env->GetMethodID(a, "getY", "()F");                        ClearExc(env);
        mMatCtor   = env->GetMethodID(b, "<init>", "()V");                      ClearExc(env);
        mSetTranslate = env->GetMethodID(b, "setTranslate", "(FF)V");           ClearExc(env);
        mPostScale = env->GetMethodID(b, "postScale", "(FF)Z");                 ClearExc(env);
        mec = (jclass)env->NewGlobalRef(a); matc = (jclass)env->NewGlobalRef(b);
    }
    const int action = mAct ? env->CallIntMethod(ev, mAct) : -1; ClearExc(env);
    const bool box = g.boxW.load() > 0 && g.boxH.load() > 0;
    const int vw = box ? g.boxW.load() : g.screenW.load(), vh = box ? g.boxH.load() : g.screenH.load();
    const int px = box ? g.padL.load() : 0, py = box ? g.padT.load() : 0;
    const int aw = g.activeW.load(), ah = g.activeH.load();
    if (action == 0) {                                              // first pointer down: is it inside the picture?
        const float x = env->CallFloatMethod(ev, mGetX), y = env->CallFloatMethod(ev, mGetY); ClearExc(env);
        const bool inside = x >= px && y >= py && x < px + vw && y < py + vh;
        drop = inside ? 0 : 1;
        static std::atomic<int> logged{0};
        if (logged.fetch_add(1) < 12)
            hexed::HLog("gate touch content(%.0f,%.0f) box origin(%d,%d) size %dx%d game %dx%d -> %s", x, y, px, py, vw, vh, aw, ah,
                        inside ? "GAME" : "BAR-ignored");
    }
    if (drop.load()) { if (action == 1 || action == 3) drop = 0; return true; }

    const bool scale = g.overrideOn.load() && vw > 0 && vh > 0 && aw > 0 && ah > 0 && (aw != vw || ah != vh);
    jobject send = ev, copy = nullptr, mat = nullptr;
    if ((px || py || scale) && mObtain && mTransform && mMatCtor && mSetTranslate && mPostScale) {   // never modify Android's shared event
        copy = env->CallStaticObjectMethod(mec, mObtain, ev);         ClearExc(env);
        mat  = env->NewObject(matc, mMatCtor);                        ClearExc(env);
        if (copy && mat) {
            env->CallVoidMethod(mat, mSetTranslate, (jfloat)-px, (jfloat)-py);                       ClearExc(env);
            if (scale) { env->CallBooleanMethod(mat, mPostScale, (jfloat)aw / (jfloat)vw, (jfloat)ah / (jfloat)vh); ClearExc(env); }
            env->CallVoidMethod(copy, mTransform, mat);               ClearExc(env);
            send = copy;
        }
    }
    env->CallBooleanMethod(g_act, m_actTouch, send);                  // virtual: reaches the game's own override
    ClearExc(env);
    if (copy) { if (mRecycle) env->CallVoidMethod(copy, mRecycle); ClearExc(env); env->DeleteLocalRef(copy); }
    if (mat) env->DeleteLocalRef(mat);
    return true;
}

// Touch events reach the game through NvEventQueueActivity.onTouchEvent (the SurfaceView subclass has no touch handler), so
// their coordinates are WINDOW coordinates. The picture box starts at (offX, offY) in that space.
void RefreshGeometry(JNIEnv* env)
{
    if (!env || !g_act || !f_view || !m_getW || !m_getH) return;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    if (!v) return;
    jint vw = env->CallIntMethod(v, m_getW), vh = env->CallIntMethod(v, m_getH);
    if (vw > 0 && vh > 0) { g.nativeW = vw; g.nativeH = vh; }
    if (m_getLocWin) {
        jintArray arr = env->NewIntArray(2);
        if (arr) {
            env->CallVoidMethod(v, m_getLocWin, arr);
            jint xy[2] = { 0, 0 };
            env->GetIntArrayRegion(arr, 0, 2, xy);
            if (!env->ExceptionCheck()) { g.offX = xy[0]; g.offY = xy[1]; }
            env->DeleteLocalRef(arr);
        }
    }
    ClearExc(env);
    env->DeleteLocalRef(v);
}

bool ViewSize(int* w, int* h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_view || !m_getW || !m_getH) return false;
    jobject v = env->GetObjectField(g_act, f_view);
    ClearExc(env);
    if (!v) return false;
    jint vw = env->CallIntMethod(v, m_getW);
    jint vh = env->CallIntMethod(v, m_getH);
    ClearExc(env);
    env->DeleteLocalRef(v);
    if (vw <= 0 || vh <= 0) return false;
    *w = vw; *h = vh;
    return true;
}

// The "screen" for the game = android.R.id.content: the grandparent of the SurfaceView (view -> FrameLayout -> content).
// Both the game view AND every overlay added with addContentView (chat, buttons, voice, dialogs) live in it, so padding it
// shrinks all of them together. Its own size does not change when its padding does.
static jobject ContentView(JNIEnv* env, jobject v)
{
    jclass vc = env->FindClass("android/view/View"); ClearExc(env);
    jobject fl = env->CallObjectMethod(v, m_getParent); ClearExc(env);
    jobject content = nullptr;
    if (fl && vc && env->IsInstanceOf(fl, vc)) { content = env->CallObjectMethod(fl, m_getParent); ClearExc(env); }
    if (!content || !(vc && env->IsInstanceOf(content, vc))) {          // unexpected hierarchy: use the direct parent
        if (content) env->DeleteLocalRef(content);
        content = fl; fl = nullptr;
    }
    if (fl) env->DeleteLocalRef(fl);
    if (vc) env->DeleteLocalRef(vc);
    return content;
}

bool ParentSize(int* w, int* h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_view || !m_getParent || !m_getW || !m_getH) return false;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    if (!v) return false;
    jobject c = ContentView(env, v);
    env->DeleteLocalRef(v);
    if (!c) return false;
    jint pw = env->CallIntMethod(c, m_getW), ph = env->CallIntMethod(c, m_getH);
    ClearExc(env);
    env->DeleteLocalRef(c);
    if (pw <= 0 || ph <= 0) return false;
    *w = pw; *h = ph;
    return true;
}

// UI thread only. Everything is done the way Android itself resizes a game window, so the game, EGL, Java and every
// mod see ONE consistent size through the normal surfaceChanged -> setWindowSize path (no faked values):
//   1. padding on the content root  -> SurfaceView and all overlays share the centered box, bars are black
//   2. SurfaceHolder.setFixedSize   -> render resolution when it differs from the box (the game gets that size)
bool ApplyLayout(JNIEnv* env)
{
    if (!env || !g_act || !f_view || !m_getParent || !m_setPadding || !m_getHolder) return false;
    const int bw = g.boxW.load(), bh = g.boxH.load(), aw = g.activeW.load(), ah = g.activeH.load();
    const bool over = g.overrideOn.load() != 0;
    jobject v = env->GetObjectField(g_act, f_view); ClearExc(env);
    if (!v) return false;
    jobject c = ContentView(env, v);
    bool ok = false;
    if (c) {
        int cw = env->CallIntMethod(c, m_getW), ch = env->CallIntMethod(c, m_getH); ClearExc(env);
        if (cw > 0 && ch > 0) {
            int l = 0, t = 0, r = 0, b = 0;
            const bool box = bw > 0 && bh > 0 && bw < cw + 1 && bh < ch + 1;
            if (box) { l = (cw - bw) / 2; t = (ch - bh) / 2; r = cw - bw - l; b = ch - bh - t; }
            env->CallVoidMethod(c, m_setPadding, l, t, r, b); ClearExc(env);
            if (box && m_setBgColor) { env->CallVoidMethod(c, m_setBgColor, (jint)0xFF000000); ClearExc(env); }
            const int tw = box ? bw : cw, th = box ? bh : ch;                       // size the SurfaceView gets from layout
            jobject holder = env->CallObjectMethod(v, m_getHolder); ClearExc(env);
            bool fixed = false;
            if (holder) {
                if (over && aw > 0 && ah > 0 && (aw != tw || ah != th) && m_setFixed) {
                    env->CallVoidMethod(holder, m_setFixed, aw, ah); fixed = true;
                } else if (m_setFromLay) {
                    env->CallVoidMethod(holder, m_setFromLay);
                }
                ClearExc(env);
                env->DeleteLocalRef(holder);
            }
            // Touch gate: with any override active the game's touches come from our listener (picture-local coordinates);
            // the content root swallows whatever nobody took (the black bars). Off again on reset.
            jobject gate = ui::Gate();
            const bool wantGate = over && gate && m_setOTL && m_actTouch;
            g.padL = l; g.padT = t;                                                  // used by GateTouch
            if (m_setOTL) {
                env->CallVoidMethod(v, m_setOTL, (jobject)nullptr); ClearExc(env);   // (1.0.7 also set one on the SurfaceView: removed)
                env->CallVoidMethod(c, m_setOTL, wantGate ? gate : (jobject)nullptr); ClearExc(env);
            }
            g.gateOn = wantGate ? 1 : 0;
            hexed::HLog("layout: content %dx%d pad L%d T%d R%d B%d | surface %s %dx%d | touch gate %s", cw, ch, l, t, r, b,
                        fixed ? "FIXED" : "from layout", fixed ? aw : tw, fixed ? ah : th, wantGate ? "ON" : "off");
            ok = true;
        } else hexed::HLog("layout: content view not laid out yet (%dx%d)", cw, ch);
        env->DeleteLocalRef(c);
    } else hexed::HLog("layout: content view not found");
    env->DeleteLocalRef(v);
    return ok;
}

bool SetBufferSize(int w, int h)
{
    JNIEnv* env = Env();
    if (!env || !g_act) { Err("no activity yet"); return false; }
    jobject surf = GetSurfaceObj(env);
    if (!surf) { Err("game surface not available"); return false; }
    ANativeWindow* win = ANativeWindow_fromSurface(env, surf);
    env->DeleteLocalRef(surf);
    if (!win) { Err("ANativeWindow_fromSurface failed"); return false; }
    // Buffer size only: the compositor scales it to the window. 0,0 restores the window size.
    int r = ANativeWindow_setBuffersGeometry(win, w, h, 0);
    ANativeWindow_release(win);
    g.bufferCalls++;
    if (r != 0) { Err("setBuffersGeometry(%d,%d) failed: %d", w, h, r); return false; }
    hexed::HLog("buffers geometry -> %dx%d", w, h);
    return true;
}

void SetJavaSurfaceFields(int w, int h)
{
    JNIEnv* env = Env();
    if (!env || !g_act || !f_surfW || !f_surfH) return;
    env->SetIntField(g_act, f_surfW, w);
    env->SetIntField(g_act, f_surfH, h);
    ClearExc(env);
}

bool FindActivityFallback()
{
    if (!AcquireVm()) { Err("JavaVM not found"); return false; }
    JNIEnv* env = Env();
    if (!env) { Err("no JNIEnv"); return false; }

    jclass at = env->FindClass("android/app/ActivityThread"); ClearExc(env);
    if (!at) return false;
    jmethodID cur = env->GetStaticMethodID(at, "currentActivityThread", "()Landroid/app/ActivityThread;"); ClearExc(env);
    jfieldID  fa  = env->GetFieldID(at, "mActivities", "Landroid/util/ArrayMap;");                          ClearExc(env);
    jclass mc = env->FindClass("android/util/ArrayMap");                                                    ClearExc(env);
    jclass rc = env->FindClass("android/app/ActivityThread$ActivityClientRecord");                          ClearExc(env);
    if (!cur || !fa || !mc || !rc) { Err("ActivityThread reflection unavailable"); return false; }
    jmethodID msize = env->GetMethodID(mc, "size", "()I");                              ClearExc(env);
    jmethodID mval  = env->GetMethodID(mc, "valueAt", "(I)Ljava/lang/Object;");         ClearExc(env);
    jfieldID  fact  = env->GetFieldID(rc, "activity", "Landroid/app/Activity;");        ClearExc(env);
    if (!msize || !mval || !fact) { Err("ActivityClientRecord layout unknown"); return false; }

    jobject thread = env->CallStaticObjectMethod(at, cur); ClearExc(env);
    jobject map = thread ? env->GetObjectField(thread, fa) : nullptr; ClearExc(env);
    bool found = false;
    if (map) {
        jint n = env->CallIntMethod(map, msize); ClearExc(env);
        for (jint i = 0; i < n && !found; ++i) {
            jobject rec = env->CallObjectMethod(map, mval, i); ClearExc(env);
            jobject act = rec ? env->GetObjectField(rec, fact) : nullptr; ClearExc(env);
            if (act) {
                jclass ac = env->GetObjectClass(act);
                jfieldID probe = ac ? env->GetFieldID(ac, "cachedSurfaceHolder", "Landroid/view/SurfaceHolder;") : nullptr;
                ClearExc(env);
                if (probe) found = Attach(env, act);
                if (ac) env->DeleteLocalRef(ac);
                env->DeleteLocalRef(act);
            }
            if (rec) env->DeleteLocalRef(rec);
        }
        env->DeleteLocalRef(map);
    }
    if (thread) env->DeleteLocalRef(thread);
    if (!found) Err("game activity not found");
    return found;
}

}} // namespace hexed::surface

# HEXED Resolution — NDK application settings.
# Matches the AndroidModLoader / aml-psdk build conventions (AML 1.4.x).
#
# NOTE ON ABIs: GTA:SA Android builds exist as 32-bit (armeabi-v7a, game
# v2.00) and 64-bit (arm64-v8a, game v2.10). Both are built here so the
# archive can be dropped into any AML mods folder; Android loads only the
# ABI matching the installed game. If your client ships a single ABI you can
# trim this line to speed up builds.
APP_STL := c++_static
APP_ABI := armeabi-v7a arm64-v8a
APP_OPTIM := release
APP_PLATFORM := android-21
NDK_TOOLCHAIN_VERSION := clang
